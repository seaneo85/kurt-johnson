<?php
//********************************************
//	Custom meta boxes
//***********************************************************
function plugin_add_custom_boxes(){
	add_meta_box( "listing", __("Listing Tabs", "listings"), "listing_tabs", "listings", "normal", "core", null);
	add_meta_box( "gallery", __("Listing Options", "listings"), "gallery_images", "listings", "normal", "core", null);
}

function listing_tabs(){ 
	global $post, $lwp_options; ?>
    <div id="listing_tabs">
        
            <ul>
                <li><a href="#tabs-1"><?php _e("Vehicle Overview", "listings"); ?></a></li>
                <li data-action="options"><a href="#tabs-2"><?php _e("Features &amp; Options", "listings"); ?></a></li>
                <li><a href="#tabs-3"><?php _e("Technical Specifications", "listings"); ?></a></li>
                <li data-action="map"><a href="#tabs-4"><?php _e("Vehicle Location", "listings"); ?></a></li>
                <li><a href="#tabs-5"><?php _e("Other Comments", "listings"); ?></a></li>
            </ul>
        
            <div id="tabs-1">
            	<?php wp_editor( $post->post_content, "post_content", array("textarea_rows" => 22) ); ?>
            </div>
        
            <div id="tabs-2">
            
            </div>
        
            <div id="tabs-3">
            	<?php $technical_specifications = get_post_meta($post->ID, "technical_specifications", true); 
				wp_editor( $technical_specifications, "technical_specifications", array("media_buttons" => true, "textarea_rows" => 22) ); ?>
            </div>
        
            <div id="tabs-4">
                <i class='fa-info-circle info fa' data-title="<?php _e("Right click on the google map to store the coordinates of a location", "listings"); ?>!"></i>
				<?php $location = get_post_meta($post->ID, "location_map", true);

                if(empty($location)){
                    $location['latitude']  = (isset($lwp_options['default_value_lat']) && !empty($lwp_options['default_value_lat']) ? $lwp_options['default_value_lat'] : "");
                    $location['longitude'] = (isset($lwp_options['default_value_long']) && !empty($lwp_options['default_value_long']) ? $lwp_options['default_value_long'] : "");
                    $location['zoom']      = (isset($lwp_options['default_value_zoom']) && !empty($lwp_options['default_value_zoom']) ? $lwp_options['default_value_zoom'] : "");
                }

                ?>
                <table border='0'>
                    <tr><td><?php _e("Latitude", "listings"); ?>:  </td><td> <input type='text' name='location_map[latitude]' class='location_value' data-location='latitude' value='<?php echo (isset($location['latitude']) && !empty($location['latitude']) ? $location['latitude'] : "43.653226"); ?>' /></td></tr>
                    <tr><td><?php _e("Longitude", "listings"); ?>: </td><td> <input type='text' name='location_map[longitude]' class='location_value' data-location='longitude' value='<?php echo (isset($location['longitude']) && !empty($location['longitude']) ? $location['longitude'] : "-79.3831843"); ?>' /></td></tr>
                	<tr><td><?php _e("Zoom", "listings"); ?>: </td><td><span class='zoom_level_text'></span><input type='hidden' readonly="readonly" class='zoom_level' name='location_map[zoom]' value='<?php echo (isset($location['zoom']) && !empty($location['zoom']) ? $location['zoom'] : 10); ?>' /></td></tr>
                </table><br />
                
                <div id='google-map'<?php echo " data-latitude='" . (isset($location['latitude']) && !empty($location['latitude']) ? $location['latitude'] : "43.653226") . "'"; 
										  echo " data-longitude='" . (isset($location['longitude']) && !empty($location['longitude']) ? $location['longitude'] : "-79.3831843") . "'"; ?>></div>
                                          
                <div id="slider-vertical" style="height: 400px;" data-value="<?php echo (isset($location['zoom']) && !empty($location['zoom']) ? $location['zoom'] : 10); ?>"></div>
            </div>
        
            <div id="tabs-5">
                <?php $other_comments = get_post_meta($post->ID, "other_comments", true); 
				wp_editor( $other_comments, "other_comments", array("media_buttons" => true, "textarea_rows" => 22) ); ?>
            </div>        
    </div>

<?php 	
}

function gallery_images(){ 
	global $post, $lwp_options;
	
	$saved_images   = get_post_meta($post->ID, 'gallery_images');
	if(isset($saved_images[0])/* && is_array($saved_images[0])*/){
		$gallery_images = array_values(array_filter($saved_images));
		$gallery_images = $gallery_images[0];
	}

	//D($gallery_images);
		
	$post_options = get_post_meta($post->ID, "listing_options");
	$options      = @unserialize($post_options[0]); ?>
	<div id="meta_tabs">
    
    	<ul>
        	<li><a href="#tab-1"><?php _e("Gallery Images", "listings"); ?></a></li>
            <li><a href="#tab-2"><?php _e("Details", "listings"); ?></a></li>
            <li><a href="#tab-3"><?php _e("Video", "listings"); ?></a></li>
            <li><a href="#tab-4"><?php _e("Listing Categories", "listings"); ?></a></li>
        </ul>
    
    	<div id="tab-1">
            <table id="gallery_images">
                <?php 
                if(isset($gallery_images) && !empty($gallery_images)){                    				
					global $slider_thumbnails;
					
					$width  = $slider_thumbnails['width'];
					$height = $slider_thumbnails['height'];
					
                    $i = 1;
                    echo "<tbody>";
                    foreach($gallery_images as $gallery_image){
                        echo "<tr><td><div class='top_header'>" . __('Image', 'listings') . " #{$i}</div>";
						echo "<div class='image_preview'>" . auto_image($gallery_image, "auto_thumb") . "</div>";
                        echo "<div class='buttons'><span class='button add_image_gallery' data-id='" . $i . "'>" . __( 'Change image', 'listings' ) . "</span> ";
                        echo "<span class='button make_default_image" . ($i == 1 ? " active_image" : "") . "'>" . __( 'Set default image', 'listings' ) . "</span> ";
                        echo "<span class='button delete_image'>" . __( 'Delete image', 'listings' ) . "</span> ";
                        echo "<span class='button move_image'>" . __( 'Move Image', 'listings' ) . "</span></div>";
                        echo "<input type='hidden' name='gallery_images[]' value='" . $gallery_image . "'>";
                        echo "</td></tr>";
                        $i++;
                    }
                    echo "</tbody>";
                    wp_nonce_field('gallery_images', 'gallery_nonce');
                } else { 
                    /*<tr><td>1</td><td> <button class='button add_image_gallery'><?php _e( 'Set image', 'listings' ); ?></button></td></tr>*/ ?>
                    <tr><td><div class="top_header"><?php _e("Image", "listings"); ?> #1</div><div class="image_preview"><?php _e("No Image", "listings"); ?></div><div class="buttons"><span class="button add_image_gallery" data-id="1"><?php _e("Change image", "listings"); ?></span> </div></td></tr>
                    <?php wp_nonce_field('gallery_images', 'gallery_nonce'); ?>
                <?php } ?>
            </table>
            <button class='add_image button button-primary'><?php _e("Add Image", "listings"); ?></button>
            
            <div class='clear'></div>
        </div>
        
        <div id="tab-2">
            	<?php	
				global $other_options, $lwp_options;
			
				foreach($other_options as $key => $option){					
					$term    = strtolower(str_replace(" ", "_", $option));
					$low_tax = "display " . strtolower($option);

					$name  = "options[" . str_replace(" ", "_", strtolower($option)) . "]";

					$display_name = $name . "[display]";
					$text_name    = $name . "[text]";
					$value_name   = $name . "[value]";

                    // check 
                    $label = (isset($options[$term]['text']) ? $options[$term]['text'] : "");

                    if(empty($label)){
                        $label = (isset($lwp_options['default_value_' . $key]) && !empty($lwp_options['default_value_' . $key]) ? $lwp_options['default_value_' . $key] : "");
                    }

					echo "<table style='margin-bottom: 15px;'>";

					echo "<tr><td colspan='2'><h2 class='detail_heading'>" . ($key == "price" ? __("Current", "listings") . " " : "") . ucwords($option) . "</h2></td></tr>";
					echo "<tr><td>" . __("Label", "listings") . ": </td><td><input type='text' name='" . $text_name . "' value='" . $label . "' /></td></tr>";
					echo "<tr><td>" . __("Value", "listings") . ": </td><td><input type='text' name='" . $value_name . "' value='" . (isset($options[$term]['value']) ? $options[$term]['value'] : "") . "' class='info " . $term . "' data-placement='right' data-trigger='focus' data-title=\"<img src='" . THUMBNAIL_URL . "widget_slider/example-" . $term . ".png' style='opactiy: 1'>\" data-html='true' /></td></tr>";

					echo "</table>";

                    if($key == "price"){
                        echo "<table style='margin-bottom: 15px;'>";

                        echo "<tr><td colspan='2'><h2 class='detail_heading'>" . __("Original Price", "listings") . "</h2></td></tr>";
                        echo "<tr><td>" . __("Value", "listings") . ": </td><td><input type='text' name='" . $name . "[original]' value='" . (isset($options[$term]['original']) ? $options[$term]['original'] : "") . "' class='info " . $term . "' data-placement='right' data-trigger='focus' data-title=\"<img src='" . THUMBNAIL_URL . "widget_slider/example-" . $term . ".png' style='opactiy: 1'>\" data-html='true' /></td></tr>";

                        echo "</table>";
                    }
				}
				?>

            <hr>

            <h2 class="no_bottom_margin"><?php _e("Listing Badge", "listings"); ?></h2>

            <table>
            	<tr><td><?php _e("Badge Text", "listings"); ?>: </td><td> <input type="text" name="options[badge_text]"<?php echo (isset($options['badge_text']) ? " value='" . $options['badge_text'] . "'" : ""); ?> class="info" data-placement='right' data-trigger="focus" data-title="<img src='<?php echo THUMBNAIL_URL; ?>widget_slider/example-badge.png' width='211' height='200' style='opactiy: 1'>" data-html='true' ></td></tr>
            	<tr><td><?php _e("Color", "listings"); ?>: </td><td> <select name="options[badge_color]" class="badge_color">
            		<?php $colors = array("theme color", "red", "orange", "yellow", "green", "blue", "indigo", "violet", "black", "custom");

            		$options['badge_color'] = (!isset($options['badge_color']) && empty($options['badge_color']) ? "theme color" : $options['badge_color']);

            		foreach($colors as $color){
            			echo "<option value='" . $color . "' " . selected($color, $options['badge_color']) . ">" . sprintf( __("%s", "listings"), $color ) . "</option>";
            		} ?>
		        	</select></td></tr>
            </table>
			
			<div class="badge_hint" style='<?php echo (isset($options['badge_color']) && $options['badge_color'] == "custom" ? "" : " display: none;"); ?>margin-top:15px;font-size:12px;'>
				<?php _e("Add this code to your CSS and replace the bolded text with your color", "listings"); ?>: <br>
				.angled_badge.custom:before { border-color: rgba(0, 0, 0, 0) #<b>FFFFFF</b> rgba(0, 0, 0, 0); }
			</div>

            <hr>
            
            <h2 class="no_bottom_margin"><?php _e("Other Details", "listings"); ?></h2>
            
            <table>
	            <?php 
				$checked = get_post_meta($post->ID, "verified", true);
				echo "<tr><td><label for='verified'>" . __("Show vehicle history report image", "listings") . ":</label></td><td><input type='checkbox' name='verified' value='yes' id='verified'" . ((isset($checked) && !empty($checked)) || is_edit_page('new') ? " checked='checked'" : "") . "></td></tr>";			
				
				$additional_categories = (isset($lwp_options['additional_categories']) && !empty($lwp_options['additional_categories']) ? $lwp_options['additional_categories'] : "");
				if(!empty($additional_categories)){
					foreach($additional_categories as $category){
						$safe_handle = str_replace(" ", "_", strtolower($category));
						$current_val = get_post_meta($post->ID, $safe_handle, true);

						echo "<tr><td><label for='" . $safe_handle . "'>" . $category . ":</label></td><td><input type='checkbox' name='additional_categories[" . $safe_handle . "]' id='" . $safe_handle . "' value='1'" . ($current_val == 1 ? "checked='checked'" : "") . "></td></tr>";
					}
				}

				?>
			</table>
            
            <br />
            
            <br />
            
            <?php _e("Short Description For Vehicle Slider Widget", "listings"); ?>:<br />
            <input type='text' name='options[short_desc]'<?php echo (isset($options['short_desc']) && !empty($options['short_desc']) ? " value='" . $options['short_desc'] . "'" : ""); ?> class='info' data-placement='right' data-trigger="focus" data-title="<img src='<?php echo THUMBNAIL_URL; ?>widget_slider/example.png' width='183' height='201' style='opactiy: 1'>" data-html='true' />            
  			
            
            
        </div>
        
        <div id="tab-3">
        	<?php _e("YouTube/Vimeo link", "listings"); ?>: <input type='text' name='options[video]' id='listing_video_input' style='width: 500px;'<?php echo (isset($options['video']) && !empty($options['video']) ? " value='" . $options['video'] . "'" : ""); ?> />
            
            <div id='listing_video'>
            <?php if(isset($options['video']) && !empty($options['video'])){ 
            	$url = parse_url($options['video']);
				
				if($url['host'] == "www.youtube.com" || $url['host'] == "youtube.com"){
					$video_id = str_replace("v=", "", $url['query']);
					
					echo "<br><br><iframe width=\"644\" height=\"400\" src=\"http://www.youtube.com/embed/" . $video_id . "\" frameborder=\"0\" allowfullscreen></iframe>";
				} elseif($url['host'] == "www.vimeo.com" || $url['host'] == "vimeo.com"){
					$video_id = $url['path'];
					
					echo "<br><br><iframe width=\"644\" height=\"400\" src=\"http://player.vimeo.com/video" . $video_id . "\" frameborder=\"0\" allowfullscreen></iframe>";
				} else {
					echo __("Not a valid YouTube/Vimeo link", "listings") . "...";
				}
            } ?>
            </div>
        </div>

        <div id="tab-4">
        	<table style="width: 100%;">
        		<?php
        			$listing_categories = get_listing_categories();

        			foreach($listing_categories as $category){
						$name = str_replace(" ", "_", strtolower($category['singular']));
						$category['link_value'] = (isset($category['link_value']) && !empty($category['link_value']) ? $category['link_value'] : "");

						// link value
						if(empty($category['link_value']) || $category['link_value'] == "none"){
	        				echo "<tr><td>" . $category['singular'] . ": </td><td>"; 

	        				if(!isset($category['compare_value']) || (isset($category['compare_value']) && $category['compare_value'] == "=")){
	        					echo "<select name='" . $name . "' style='width: 100%;' id='" . $name . "'>";
		        				echo "<option value='" . __("None", "listings") . "'>" . __("None", "listings") . "</option>";

		        				// sort
		        				asort($category['terms']);

		        				foreach($category['terms'] as $term){
		        					echo "<option value='" . ($term) . "' " . selected(htmlspecialchars_decode(stripslashes($term), ENT_QUOTES), stripslashes(get_post_meta( $post->ID, $name, true )), false) . ">" . stripslashes($term) . "</option>";
		        				}

		        				echo "</select>";
		        			} else {
		        				$text_value = get_post_meta($post->ID, str_replace(" ", "_", strtolower($category['singular'])), true);
		        				echo "<input type='text' name='" . $name . "' value='" . htmlspecialchars(stripslashes($text_value), ENT_QUOTES) . "'>";
		        			}
	        				echo "</td><td style='text-align: right; width: 350px; max-width: 350px;'> <a href='#' class='hide-if-no-js add_new_name' data-id='" . $name . "'>+ " . __("Add New Category", "listings") . "</a>";
	        				echo '<div class="add_new_content ' . $name . '_sh" style="display: none;">
						    	<input class="' . $name . '" type="text" style="margin-left: 0;" />
						        <button class="button submit_new_name" data-type="' . $name . '">' . __("Add New Category", "listings") . '</button>
						    </div>';
	        				echo "</td></tr>";
	        			}
        			}
        		?>
        	</table>
        </div>
        
    </div>
<?php
}

add_action( 'add_meta_boxes', 'plugin_add_custom_boxes' );

function plugin_add_after_editor(){
	global $post, $wp_meta_boxes;
	
	do_meta_boxes(get_current_screen(), 'advanced', $post);
	
	$post_types = get_post_types();
	
	foreach($post_types as $post_type){
		unset($wp_meta_boxes[$post_type]['advanced']);
	}
}

add_action("edit_form_after_title", "plugin_add_after_editor");

function plugin_secondary_title(){
	global $post;
	
	$secondary_title = get_post_meta($post->ID, "secondary_title", true);
	echo "<input type='text' value='" . $secondary_title . "' name='secondary_title' style='width:100%;'/>";
}

//********************************************
//	Custom meta boxes for custom categories
//***********************************************************
function plugin_add_custom_meta_boxes(){					
	add_meta_box( "options", __("Options", "listings"), "plugin_make_meta_box", "listings", "side", "core", array("name" => "options"));
		
	$listing_categories = get_listing_categories();
	
	foreach($listing_categories as $category){	
			
		$sfield = str_replace(" ", "_", strtolower($category['singular']));
				
		$field = $name = $category['singular'];

		if($category['filterable'] == 1){
			$field = $field . " (" . __("Filterable", "listings") . ")";
		}
	}
}

function plugin_make_meta_box($post, $metabox){
	$name  = $metabox['args']['name'];
	$lower = str_replace(" ", "_", strtolower($name));
	
	$sname  = str_replace(" ", "_", strtolower($name));

	$single_category = get_single_listing_category($lower);
	$options         = (isset($single_category['terms']) && !empty($single_category['terms']) ? $single_category['terms'] : "");

	$selected = get_post_meta($post->ID, $lower, true);

    /* Default Options */
    $default_options = get_option("options_default_auto");
	
	echo "<select style='width: 100%;' id='" . $lower . "' name='" . ($name == "options" ? "multi_options[]" : $lower) . "' " . ($name == "options" ? "multiple " : "") . "" . ($name == "options" ? " class='chosen-dropdown'" : "") . ">";
	echo ($name != "options" ? "<option value='none'>" . __("None", "listings") . "</option>" : "");
		
	if($name == "options"){
		$multi_options = get_post_meta($post->ID, "multi_options", true);
				
		foreach($options as $option){
			echo "<option value='" . $option . "'" . ((in_array($option, $multi_options)) || (is_edit_page('new') && in_array($option, $default_options)) ? " selected='selected'" : "") . ">" . $option . "</option>";
		}
	} else { 
		if(!empty($options)){
			foreach($options as $option){
				echo "<option value='" . $option . "'" . selected($option, $selected) . ">" . $option . "</option>";
			}
		}
	}

	echo "</select>"; ?>    
    
	<h4 style="margin-bottom: 5px;"><a href="#" class="hide-if-no-js add_new_name" data-id="<?php echo $sname; ?>">+ <?php _e("Add New Category", "listings"); ?></a></h4>
    
    <div class='add_new_content <?php echo $sname; ?>_sh' style="display: none;">
    	<input class='<?php echo $sname; ?>' type='text' style="width: 100%; margin-left: 0;" />
        <button class='button submit_new_name' data-type='<?php echo $sname; ?>'><?php _e("Add New Category", "listings"); ?></button>
    </div>
<?php	
}

function plugin_register_menu_pages(){	
	add_submenu_page( 'edit.php?post_type=listings', "Options", "Options", 'manage_options', 'options', 'plugin_my_custom_submenu_page_callback');	

	$listing_categories = get_listing_categories();
	
	foreach($listing_categories as $field){
		$sfield = str_replace(" ", "_", strtolower($field['plural']));
		
		add_submenu_page( 'edit.php?post_type=listings', $field['plural'], $field['plural'], 'manage_options', str_replace(" ", "_", strtolower($field['singular'])), 'plugin_my_custom_submenu_page_callback' ); 
			
	}
} 


function plugin_my_custom_submenu_page_callback() {	
	$value  = $_GET['page']; 
	$svalue = str_replace(" ", "_", strtolower($value));

    $is_options = false;

	$listing_categories = get_listing_categories();
	
	if($value == "options"){
		$label      = __("Options", "listings");
        $is_options = true;

        $default    = get_option("options_default_auto");
	} else {		
		$label      = ucwords(str_replace("_", " ", $_GET['page']));
	} 

    $category = get_single_listing_category($svalue);
	?>
    <style type="text/css"> .delete_name { cursor: pointer } </style>
	<div class='wrap nosubsub'>
    	<div id="icon-edit" class="icon32 icon32-posts-post"><br></div>
        <h2 style="margin-bottom:25px;"><?php echo ucwords($label); ?></h2>
        
        <div id='col-container'> 
            <div id='col-left' style='display: inline-block; width: auto; vertical-align: top;'>
            	<strong style="display: block;"><?php _e("Add New", "listings"); ?> <?php echo ucwords($label); ?></strong><br />
            	<form method="POST" action="">
                	<table border='0'>
                		<tr><td><?php _e("Value", "listings"); ?>: </td><td> <?php echo (isset($category['compare_value']) && !empty($category['compare_value']) && $category['compare_value'] != "=" ? $category['compare_value'] : ""); ?> <input type='text' name='new_name' /></td></tr>
                    	<tr><td colspan="2"><input type='submit' class='button-primary' name='add_new_name' value='<?php _e("Add", "listings"); ?>' /></td></tr>
                    </table>
                </form>
            </div>
            
            <div id='col-right' style='display: inline-block; float: none;'>
                <form method="POST" action="">
                	<table border='0' class='wp-list-table widefat fixed tags listing_table'>
                    	<thead>
                        	<tr>
                                <th><?php _e("Value", "listings"); ?></th>
                                <th><?php _e("Posts", "listings"); ?></th>
                                <th><?php _e("Delete", "listings"); ?></th>
                                <?php echo ($is_options ? "<th>" . __("Default Selection", "listings") . "</th>": ""); ?>
                            </tr>
                        </thead>
                        
                        <tbody>
                        	<?php
    						$options = (isset($category['terms']) && !empty($category['terms']) ? $category['terms'] : "");
    						$i       = 0;
    						if(empty($options)){
    							echo "<tr><td colspan='3'>" . __("No terms yet", "listings") . "</td></tr>";
    						} else {
    							foreach($options as $key => $option){
    								echo "<tr" . ($i %2 == 0 ? " class='alt'" : "") . " id='t_" . $i . "'><td>" . $option . "</td><td>" . get_total_meta($svalue, $option) . "</td><td><span class='delete_name button-primary' data-id='" . $key . "' data-type='" . $svalue . "' data-row='" . $i . "'>" . __("Delete", "listings") . "</span></td>";
    								
                                    if($is_options){
                                        echo "<td><input type='checkbox' name='default[]' value='" . $option . "' " . (!empty($default) && in_array($option, $default) ? " checked='checked'" : "") . "></td>";
                                    }

                                    echo "</tr>";
                                    $i++;
    							}
    						}
    						?>
                        </tbody>
                    </table>

                    <input type="submit" name="submit" value="Save Default" class="button button-primary" style="margin-top: 15px;">

                </form>
            </div>
        </div>
    </div>
    <script type="application/javascript">
		jQuery(function($){
			$(".delete_name").click( function(){
				var id   = $(this).data('id');
				var type = $(this).data('type');
				var row  = $(this).data('row');
				
				jQuery.ajax({
				   type : "post",
				   url : myAjax.ajaxurl,
				   data : {action: "delete_name", id: id, type: type},
				   success: function(response) {
					  var table = $("#t_" + row).closest("table");
					  
					  $("#t_" + row).closest("tr").fadeOut(400, function(){
						  $(this).remove();
					  
						  table.find("tr").each( function( index ){
							  $(this).removeClass("alt");
							  $(this).addClass((index%2 != 0 ? "alt" : ""));
						  });
					  });
				   }
				});
			});
		});
	</script>    
<?php	
}

// deleting
function plugin_delete_name(){
	$id   = $_POST['id'];
	$type = $_POST['type'];
	
	$listing_categories = get_listing_categories(true);
	$current_category   = (isset($listing_categories[$type]) && !empty($listing_categories[$type]) ? $listing_categories[$type] : "");

	// update the var
	$listing_categories[$type] = $current_category;
	
	unset($listing_categories[$type]['terms'][$id]);
	
	update_option('listing_categories', $listing_categories);
	
	die;
}

add_action("wp_ajax_delete_name", "plugin_delete_name");
add_action("wp_ajax_nopriv_delete_name", "plugin_delete_name");

// ajax save
function plugin_add_name() {
	$name = $_POST['value'];
	$type = $_POST['type'];

	$listing_categories = get_listing_categories(true);
	$listing_categories[$type]['terms'][] = htmlspecialchars($name, ENT_QUOTES);

	update_option("listing_categories", $listing_categories);

	die;
}

add_action("wp_ajax_add_name", "plugin_add_name");
add_action("wp_ajax_nopriv_add_name", "plugin_add_name");

// saving
function plugin_save_new_custom_meta(){
	if(isset($_POST['add_new_name'])){
		$name = $_POST['new_name'];
		$type = str_replace(" ", "_", strtolower($_GET['page']));

	    $listing_categories = get_listing_categories(true);
		$current_category   = (isset($listing_categories[$type]) && !empty($listing_categories[$type]) ? $listing_categories[$type] : "");

		if(!empty($current_category['terms'])){
			$current_category['terms'][] = $name;
		} else {
			$current_category['terms'] = array($name);
		}

		// update the var
		$listing_categories[$type] = $current_category;

		update_option( 'listing_categories', $listing_categories );
	}

    if(isset($_POST['default']) && !empty($_POST['default'])){

        update_option("options_default_auto", $_POST['default']);

    }
}

add_action( 'init', 'plugin_save_new_custom_meta' );
add_action( 'admin_menu', 'plugin_register_menu_pages' );
add_action( 'add_meta_boxes', 'plugin_add_custom_meta_boxes' );
?>