<?php get_header(); ?>
	
    <?php listing_template("boxed_left"); ?>

<?php get_footer(); ?>