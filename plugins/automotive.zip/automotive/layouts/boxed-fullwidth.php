<?php get_header(); ?>
	
    <?php listing_template("boxed_fullwidth"); ?>

<?php get_footer(); ?>