<?php
///// start session
if (!session_id()) {
    session_start();
}

///// register page
function register_csv_menu_item() {
    add_submenu_page( 'edit.php?post_type=listings', __('Automotive Listings Import', 'listings'), __('File Import', 'listings'), 'manage_options', 'file-import', 'automotive_file_import' ); 
}
add_action('admin_menu', 'register_csv_menu_item');


/* errors
/* * * * */
function admin_errors_auto(){
    $error = (isset($_GET['error']) && !empty($_GET['error']) ? sanitize_text_field($_GET['error']) : "");

    if(!empty($error)){
        echo "<div class='error'><span class='error_text'>";

        if($error == "file"){
            _e("The file uploaded wasn't a valid XML or CSV file, please try again.", "listings");
        } elseif($error == "url"){
            _e("The URL submitted wasn't a valid URL, please try again.", "listings");
        }

        echo "</span></div>";
    }
}
add_action( 'admin_notices', 'admin_errors_auto' );

function file_type_check_auto() {

    if(isset($_POST['import_submit'])){
        
        $uploaded_file  = $_FILES['import_upload'];
        $file_location  = $uploaded_file['name'];
        $file_type      = pathinfo($file_location, PATHINFO_EXTENSION);

        if(isset($file_type) && ($file_type != "csv" && $file_type != "xml")) {
            header("Location: " . admin_url( 'edit.php?post_type=listings&page=file-import&error=file' ));
        }


    } elseif(isset($_POST['url'])){
        $url = sanitize_text_field( $_POST['url'] );

        if(filter_var($url, FILTER_VALIDATE_URL)){
            $file_content = wp_remote_get( $url );
            $file_type    = $file_content['headers']['content-type'];

            $file_content = $file_content['body'];
            $file_type    = substr($file_type, -3);

            // generate temp file to process
            $temp_file  = tmpfile();
            fwrite($temp_file, $file_content);
            fseek($temp_file, 0);

            // grab file location
            $meta           = stream_get_meta_data($temp_file);
            $file_location  = $meta['uri'];

            if(isset($file_type) && ($file_type != "csv" && $file_type != "xml")) {
                header("Location: " . admin_url( 'edit.php?post_type=listings&page=file-import&error=file' ));
            }
        } else {
                header("Location: " . admin_url( 'edit.php?post_type=listings&page=file-import&error=url' ));
        }
    }

}
add_action( 'init', 'file_type_check_auto' );

function automotive_file_import() { 
    $is_xml = $load_csv = false;

    if(isset($_POST['import_submit'])){
        
        $uploaded_file  = $_FILES['import_upload'];
        $file_location  = $uploaded_file['name'];
        $file_type      = pathinfo($file_location, PATHINFO_EXTENSION);

        if(isset($file_type) && $file_type == "csv"){
            $rows = parse_csv_local($uploaded_file['tmp_name']);

            $load_csv = true;
        } elseif(isset($file_type) && $file_type == "xml") {
            $rows = parse_xml_local($uploaded_file['tmp_name']);

            $is_xml = true;
            //die;
        }


    } elseif(isset($_POST['url'])){
        $url = sanitize_text_field( $_POST['url'] );

        if(filter_var($url, FILTER_VALIDATE_URL)){
            $file_content = wp_remote_get( $url );
            $file_type    = $file_content['headers']['content-type'];

            $file_content = $file_content['body'];
            $file_type    = substr($file_type, -3);

            // generate temp file to process
            $temp_file  = tmpfile();
            fwrite($temp_file, $file_content);
            fseek($temp_file, 0);

            // grab file location
            $meta           = stream_get_meta_data($temp_file);
            $file_location  = $meta['uri'];

            if(isset($file_type) && $file_type == "csv"){
                $rows = parse_csv_local($file_location);

                $load_csv = true;
            } elseif(isset($file_type) && $file_type == "xml") {
                $rows = parse_xml_local($file_location);

                $is_xml = true;
            } else {
                header("Location: " . admin_url( 'edit.php?post_type=listings&page=file-import&error=file' ));
            }
        } else {
            echo __("Please submit a valid URL.", "listings");
        }
    }

    // xml parse
    if(isset($_SESSION['auto_xml']['file_contents']) && isset($_GET['xml'])){
        $xml = $_SESSION['auto_xml']['file_contents'];

        $load_xml    = true;
        $xml_start   = key_get_parents($_GET['xml'], $xml);
        $xml_start[] = (isset($_GET['xml']) && !empty($_GET['xml']) ? sanitize_text_field($_GET['xml']) : "");
            
        $items       = $xml;

        foreach($xml_start as $ndx){
            $items = $items[$ndx];
        }

        $rows          = $items;
        $return_result = insert_listings($rows);
    }

    // csv parse 
    if(isset($_SESSION['auto_csv']['file_contents']) && isset($_POST['csv']) && $_POST['csv']){
        $rows = $_SESSION['auto_csv']['file_contents'];

        $return_result = insert_listings($rows);
    }

    ?>
    
    <div class="wrap auto_import">
        <h2 style="display: inline-block;"><?php _e("File Import", "listings"); ?></h2> 

        <?php echo ((isset($_POST['file']) && !empty($_POST['file']) && $_POST['file'] == "uploaded" && ( isset($load_csv) && $load_csv || isset($load_xml))) || isset($load_xml) && $load_xml && isset($_GET['xml']) && !empty($_GET['xml']) ? '<button class="submit_csv button button-primary" style="vertical-align: super">' . __("Import Listings", "listings") . '</button>' : ""); ?>

        <br><br>

        <?php 
        if(isset($return_result) && !empty($return_result)){
            echo $return_result;

            // clear sesh
            if(isset($_SESSION['auto_csv']['file_contents']) && !empty($_SESSION['auto_csv']['file_contents'])){
                unset($_SESSION['auto_csv']['file_contents']);
            }

            if(isset($_SESSION['auto_xml']['file_contents']) && !empty($_SESSION['auto_xml']['file_contents'])){
                unset($_SESSION['auto_xml']['file_contents']);
            }
        } elseif($is_xml){ 
            $xml_options = multiarray_keys($rows); ?>
            
            <div class="upload-plugin">

                <p class="install-help"><?php _e("Choose which XML node contains each listings information.", "listings"); ?></p>

                <form method="get" class="wp-upload-form" action="">
                    <input type="hidden" name="post_type" value="listings">
                    <input type="hidden" name="page" value="file-import">

                    <select name='xml'>
                    <?php
                    foreach($xml_options as $option){
                        echo "<option value='" . $option . "'>" . $option . "</option>";
                    } ?>
                    </select>

                    <button onclick="jQuery(this).closest('form').submit()" class="button"><?php _e("Import Now", "listings"); ?></button>  
                </form>

            </div>

        <?php } elseif(!isset($_POST['file']) && !isset($load_xml)){ ?>
            <div class="upload-plugin">
                <p class="install-help"><?php _e("If you have a listing data in a .csv or .xml file format, you may import it by uploading it here.", "listings"); ?></p>

                <form method="post" enctype="multipart/form-data" class="wp-upload-form" action="<?php echo remove_query_arg( "error" ); ?>" name="import_upload">
                    <input type="hidden" name="post_type" value="listings">
                    <input type="hidden" name="page" value="file-import">
                    <input type="hidden" name="file" value="uploaded">

                    <label class="screen-reader-text" for="import_upload"><?php _e("Listing file", "listings"); ?></label>
                    <input type="file" id="import_upload" name="import_upload">
                    <input type="submit" name="import_submit" id="install-plugin-submit" class="button" value="<?php _e("Import Now", "listings"); ?>" disabled="">
                </form>
            </div>


            <div class="upload-plugin">
                <p class="install-help"><?php _e("If you have a link to a .csv or .xml file, you may import it by pasting the URL it here.", "listings"); ?></p>

                <form method="post" class="wp-upload-form" action="<?php echo remove_query_arg( "error" ); ?>" name="import_url">
                    <input type="hidden" name="post_type" value="listings">
                    <input type="hidden" name="page" value="file-import">
                    <input type="hidden" name="file" value="uploaded">

                    <label class="screen-reader-text" for="pluginzip"><?php _e("Listing file", "listings"); ?></label>
                    <input type="text" name="url" placeholder="<?php _e("URL to xml or csv", "listings"); ?>" style="width: 70%;">
                    <button onclick="jQuery(this).closest('form').submit()" class="button"><?php _e("Import Now", "listings"); ?></button>                
                </form>
            </div>
        <?php } elseif((isset($_POST['file']) && !empty($_POST['file']) && $_POST['file'] == "uploaded") || $load_xml){ ?>

            <?php if(count($rows) > 100){ ?>
            <div class="error">
                <span class="error_text"><?php _e("Please consider breaking the import file into multiple files, large imports may not import fully depending on your server's settings.", "listings"); ?></span>
            </div>
            <?php } ?>

            <ul id="csv_items" class="connectedSortable">
                <?php

                function recursive_sortable($loop, $rows){
                    foreach($loop as $key => $row){
                        if(!is_array($row)){
                            echo "<li class='ui-state-default'><input type='hidden' name='csv[" . (is_null(key_get_parents($key, $rows)) ? $key : implode("|", key_get_parents($key, $rows)) . "|" . $key ) . "]' > " . $key . "</li>";
                        } else {
                            recursive_sortable($row, $rows);
                        }
                    }
                }

                recursive_sortable($rows[0], $rows[0]); ?>
            </ul>

            <form method="post" id="csv_import">
            
                <?php foreach(get_listing_categories() as $key => $option){ ?>
                    <fieldset class="category">
                        <legend><?php echo $option['singular']; ?></legend>

                        <ul class="listing_category connectedSortable" data-limit="1" data-name="<?php echo $key; ?>"></ul>
                    </fieldset>
                <?php } 

                // extra spots
                $extra_spots = array(__("Title", "listings") => 1, __("Vehicle Overview", "listings") => 0, __("Technical Specifications", "listings") => 0, __("Other Comments", "listings") => 0, __("Gallery Images", "listings") => 0, __("Price", "listings") => 1, __("Original Price", "listings") => 1, __("City MPG", "listings") => 1, __("Highway MPG", "listings") => 1, __("Video", "listings") => 1);
                foreach($extra_spots as $key => $option){ ?>
                    <fieldset class="category">
                        <legend><?php echo $key . ($option == 0 ? " <i class='fa fa-bars'></i>" : ""); ?></legend>

                        <ul class="listing_category connectedSortable" data-limit="<?php echo $option; ?>" data-name="<?php echo str_replace(" ", "_", strtolower($key)); ?>"></ul>
                    </fieldset>
                <?php } ?>

                <br><br>

                <?php _e("Check for duplicate listings using", "listings"); ?>: 
                <select name="duplicate_check">
                    <option value="none"><?php _e("None", "listings"); ?></option>
                    <option value="title"><?php _e("Title", "listings"); ?></option>
                    <?php
                    foreach(get_listing_categories() as $key => $option){
                        echo "<option value='" . str_replace(" ", "_", strtolower($option['singular'])) . "'>" . $option['singular'] . "</option>";
                    } ?>
                </select>

                <br><br>

                * <i class="fa fa-bars"></i> <?php _e("Categories with this symbol can contain multiple values", "listings"); ?>

            </form>
        <?php } ?>

    </div>

    <script>
    jQuery(document).ready( function($){
        $( "#csv_items, .listing_category" ).sortable({
            connectWith: ".connectedSortable",
            placeholder: "ui-state-highlight",
            forcePlaceholderSize: true,
            start: function(e, ui){
                ui.placeholder.height(ui.item.height());
            },
            receive: function(event, ui) {
                var $this = $(this);
                if ($this.data("limit") == 1 && $this.children('li').length > 1 && $this.attr('id') != "csv_items") {
                    alert('<?php _e("Only one per list!", "listings"); ?>');
                    $(ui.sender).sortable('cancel');
                }

                // set val
                var name = $this.data('name');
                ui.item.find('input[type="hidden"]').val(name);
            },
            stop: function (event, ui){
                var $this = $(this);
            }
        }).disableSelection();

        $(".submit_csv").click( function(){
            $("#csv_import").submit();
        });
    });
    </script>

    <style>
    .wrap.auto_import ul {
        list-style: disc;
        padding-left: 40px;
    }

    #csv_import {
        width: 80%;
        float: right;
    }

    #csv_items, .wrap.auto_import ul.listing_category {
        width: 150px;
        min-height: 20px;
        list-style-type: none;
        margin: 0;
        padding: 5px 0 10px 0;
        float: left;
        margin-right: 10px;
    }

    #csv_items {
        width: 19%;
    }

    #csv_items li, ul.listing_category li {
        margin: 0 5px 5px 5px;
        padding: 5px;
        font-size: 1.2em;
        width: 128px;
        cursor: move;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    #csv_items li:hover, .listing_category li:hover {
        overflow: visible;
        text-overflow: clip;
    }

    li.no_value {
        border: 1px solid #F00;
    }

    fieldset.category {
        border: 1px solid #CCC;
        display: inline-block;
        margin-right: 10px;
        margin-bottom: 10px;
    }

    .error_text {
        padding: 10px 0;
        display: block;
    }
    </style>
<?php } 

function array_remove_empty($haystack) {
    foreach ($haystack as $key => $value) {
        if (is_array($value)) {
            $haystack[$key] = array_remove_empty($haystack[$key]);
        }

        if (empty($haystack[$key])) {
            unset($haystack[$key]);
        }
    }

    return $haystack;
}

function get_upload_image($image_url){
    $image = $image_url;
    $get   = wp_remote_get( $image );
    $type  = wp_remote_retrieve_header( $get, 'content-type' );

    if (!$type)
        return false;

    $mirror = wp_upload_bits( basename( $image ), '', wp_remote_retrieve_body( $get ) );

    $attachment = array(
        'post_title'=> basename( $image ),
        'post_mime_type' => $type
    );

    if(isset($mirror) && !empty($mirror)){
        $attach_id = wp_insert_attachment( $attachment, $mirror['file'] );

        require_once(ABSPATH . 'wp-admin/includes/image.php');

        $attach_data = wp_generate_attachment_metadata( $attach_id, $mirror['file'] );

        wp_update_attachment_metadata( $attach_id, $attach_data );
    } else {
        $attach_id = "";
    }

    return $attach_id;
}

function key_get_parents($subject, $array){

    foreach ($array as $key => $value){

        if (is_array($value)){
            if (in_array($subject, array_keys($value), true)){
                return array($key);
            } else {
                $chain = key_get_parents($subject, $value);

                if (!is_null($chain)){
                    return array_merge(array($key), $chain);
                }
            }
        }
    }

  return null;
}

function parse_xml_local($file_location){
    $xml    = simplexml_load_file($file_location);
    $json   = json_encode($xml);
    $rows   = json_decode($json, TRUE);

    $_SESSION['auto_xml']['file_contents'] = $rows;

    return $rows;
}

function multiarray_keys($ar) { 
            
    foreach($ar as $k => $v) { 
        if(is_array($v)){
            $keys[] = $k; 
        }

        if (is_array($ar[$k]) && is_array(multiarray_keys($ar[$k]))) {
            $keys = array_merge($keys, multiarray_keys($ar[$k])); 
        }
    } 
    return (isset($keys) && !empty($keys) ? $keys : ""); 
} 

function parse_csv_local($file_location){
    include(LISTING_HOME . "/classes/" . "parsecsv.lib.php"); 

    // parse CSV
    $csv  = new parseCSV($file_location);
    $rows = array_values(array_remove_empty($csv->data));

    $_SESSION['auto_csv']['file_contents'] = $rows;

    return $rows;
}

function search_array_keys($array, $term, $references){
    $count  = array_count_values($references);
    $return = "";

    // if variable has more than a single value
    if(isset($count[$term]) && $count[$term] > 2){
        $keys = array_keys($references, $term);

        foreach($keys as $key){
            if(strpos($key, "|") !== false){
                $paths = explode("|", $key); 
                $items = $array;

                foreach($paths as $ndx){
                    $items = $items[$ndx];
                }

                $return .= $items . "<br>";        
            } else {
                $return .= (isset($array[$key]) && !empty($array[$key]) ? $array[$key] : "") . "<br>";
            }
        }
    } else {
        $key = array_search($term, $references);

        if(strpos($key, "|") !== false){
            $paths = explode("|", $key); 
            $items = $array;

            foreach($paths as $ndx){
                $items = $items[$ndx];
            }

            $return .= $items;        
        } else {
            $return .= (isset($array[array_search($term, $references)]) && !empty($array[array_search($term, $references)]) ? $array[array_search($term, $references)] : "");
        }
    }

    return $return;
}

function insert_listings($rows){

     // if form submitted
    if(isset($_POST['csv']) && !empty($_POST['csv'])){

        $csv                     = (isset($_POST['csv']) && !empty($_POST['csv']) ? $_POST['csv'] : "");
        $duplicate_check         = (isset($_POST['duplicate_check']) && !empty($_POST['duplicate_check']) ? $_POST['duplicate_check'] : "");
        $listing_categories_safe = $listing_categories = get_listing_categories(true);

        $imported_listings       = array();

        if(!empty($csv)){
            //D($rows);
            foreach($rows as $key => $row){
                $post_title     = search_array_keys($row, "title", $csv);
                $post_content   = search_array_keys($row, "vehicle_overview", $csv);

                $insert_info    = array(
                                    'post_type'     => "listings",
                                    'post_title'    => $post_title,
                                    'post_content'  => $post_content,
                                    'post_status'   => "publish"
                                );

                //D($insert_info);

                // duplicate check
                $current_listings = get_posts( array( "post_type" => "listings", "posts_per_page" => -1 ) );

                if($duplicate_check == "none"){
                    $no_check = true;
                } elseif($duplicate_check != "title"){
                    $current_check = array();
                    $i = 0;

                    foreach($current_listings as $listing){
                        $post_meta       = get_metadata("post", $listing->ID);

                        $current_check[$i] = (isset($post_meta[$duplicate_check]) && !empty($post_meta[$duplicate_check]) ? $post_meta[$duplicate_check] : "");
                        $i++;
                    }
                    $search_value  = search_array_keys($row, $duplicate_check, $csv);
                } else {
                    $current_check = wp_list_pluck( $current_listings, "post_title" );
                    $search_value  = $post_title;
                }

                if(isset($current_check) && !empty($current_check) && !in_array($post_title, $current_check) || (isset($no_check) && $no_check)){
                    $insert_id      = wp_insert_post( $insert_info );

                    /* Record inserted posts */
                    $imported_listings[$insert_id] = $post_title;

                    // listing categories
                    $listing_categories['Technical Specifications'] = array("multiple" => true);
                    $listing_categories['Other Comments']           = array("multiple" => true);

                    foreach($listing_categories as $key => $option){
                        if(isset($option['multiple'])){
                            // contains multiple values, concatanate them
                            $key   = str_replace(" ", "_", strtolower($key));
                            $value = search_array_keys($row, $key, $csv);
                        } else {
                            $value = search_array_keys($row, $key, $csv);

                            // add value if not already added
                            $terms = $listing_categories_safe[$key]['terms'];
                            if(!in_array($value, $terms) && !empty($value)){
                                $listing_categories_safe[$key]['terms'][] = $value;
                            }
                        }
                        
                        update_post_meta( $insert_id, $key, $value );
                    }

                    // gallery images
                    $values         = search_array_keys($row, "gallery_images", $csv);
                    $gallery_images = array();

                    if(!empty($values)){
                        $values = explode("<br>", $values);

                        foreach($values as $val){
                            if(filter_var($val, FILTER_VALIDATE_URL)){
                                $gallery_images[] = get_upload_image($val);
                            }
                        }
                    }
                    
                    if(!empty($gallery_images)){
                        update_post_meta($insert_id, "gallery_images", $gallery_images);
                    }

                    global $lwp_options;

                    // post options (city, hwy, video)
                    $post_options = array(
                        "video" => search_array_keys($row, "video", $csv),
                        "price" => array(
                            "text"  => (isset($lwp_options['default_value_price']) && !empty($lwp_options['default_value_price']) ? $lwp_options['default_value_price'] : __("Price", "listings")),
                            "value" => preg_replace('/\D/', '', search_array_keys($row, "price", $csv))
                        ),
                        "city_mpg" => array(
                            "text"  => (isset($lwp_options['default_value_city']) && !empty($lwp_options['default_value_city']) ? $lwp_options['default_value_city'] : __("City MPG", "listings")),
                            "value" => preg_replace('/\D/', '', search_array_keys($row, "city_mpg", $csv))
                        ),
                        "highway_mpg" => array(
                            "text"  => (isset($lwp_options['default_value_hwy']) && !empty($lwp_options['default_value_hwy']) ? $lwp_options['default_value_hwy'] : __("Highway MPG", "listings")),
                            "value" => preg_replace('/\D/', '', search_array_keys($row, "highway_mpg", $csv))
                        )
                    );
                    
                    update_post_meta($insert_id, "listing_options", serialize($post_options));
                } else {
                    $imported_listings['duplicate'][] = $post_title;
                }

                update_option( 'listing_categories', $listing_categories_safe );
            }

            $return = "";

            $duplicates = (isset($imported_listings['duplicate']) && !empty($imported_listings['duplicate']) ? $imported_listings['duplicate'] : "");
            unset($imported_listings['duplicate']);

            if(!empty($imported_listings)){
                $return .= "<br>";
                $return .= __("Successfully imported these listings", "listings") . ":<br>";

                $return .= "<ul>";
                foreach($imported_listings as $key => $listing){
                    if($key != "duplicate"){
                        $return .= "<li><a href='" . get_permalink($key) . "'>" . $listing . "</a></li>";
                    }
                }
                $return .= "</ul>";
            }

            if(!empty($duplicates)){
                $return .= "<br>";
                $return .= __("These listings weren't imported because a duplicate listing was detected", "listings") . ":<br>";

                $return .= "<ul>";
                foreach($duplicates as $listing){
                    $return .= "<li>" . $listing . "</li>";
                }
                $return .= "</ul>";            
            }

            $return .= "<a href='" . admin_url("edit.php?post_type=listings&page=file-import") . "'><button class='button button-primary'>" . __("Import more listings", "listings") . "</button></a>";

            return $return;
        }
    } 
}


function automotive_import_scripts() {
    wp_enqueue_script( 'jquery-ui' );
    wp_enqueue_script( 'jquery-ui-sortable' );
}

add_action( 'wp_enqueue_scripts', 'automotive_import_scripts' ); ?>