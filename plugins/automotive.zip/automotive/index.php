<?php
/**
 * Plugin Name: Automotive Listings
 * Plugin URI: http://demo.themesuite.com/index.php?plugin=Automotive
 * Description: A well-designed inventory management system that is a breeze to setup and customize for your vehicle inventory. It also includes a completely customizable, filterable, and sortable Inventory Search to search your Vehicle Listings, as well as a complete Inventory Management System and Loan Calculator. Guaranteed compatibility with the <a href='http://themeforest.net/item/automotive-car-dealership-business-wordpress-theme/9210971?ref=themesuite' target='_blank'>Automotive Theme</a>
 * Version: 1.9
 * Author: Theme Suite
 * Author URI: http://www.themesuite.com
 * Text Domain: listings
 * Domain Path: /languages/
 */

// translation my (friend||péngyou||vriend||ven||ami||freund||dost||amico||jingu||prijátel||amigo||arkadas)
function automotive_load_textdomain() {
	load_plugin_textdomain('listings', false, basename( dirname( __FILE__ ) ) . '/languages/' );
}
add_action( 'plugins_loaded', 'automotive_load_textdomain', 99 );

$icons			   = array("facebook", "twitter", "youtube", "vimeo", "linkedin", "rss", "flickr", "skype", "google", "pinterest");
$other_options     = array("price" => __("Price", "listings"), "city" => __("City MPG", "listings"), "hwy" => __("Highway MPG", "listings"));
$slider_thumbnails = array('width'    => 167, 
						   'height'   => 119,
						   'slider'   => array('width'  => 762,
						   					 'height' => 456
									     ),
							'listing' => array('width'  => 200,
											   'height' => 150
									     )
						   );
$lwp_options       = get_option("listing_wp");

// image sizes
add_image_size("related_portfolio", 270, 140, true);


//********************************************
//	Constant Paths
//***********************************************************
if( !defined("LISTING_HOME") ){
	define("LISTING_HOME", plugin_dir_path( __FILE__ ));
}

if( !defined('LISTING_DIR') ){
	define( 'LISTING_DIR', plugins_url() . '/automotive/' );
}

if( !defined('LISTING_ADMIN_DIR') ){
	define( 'LISTING_ADMIN_DIR', LISTING_DIR . 'admin/' );
}

if( !defined("ICON_DIR") ){
	define("ICON_DIR", LISTING_DIR . "images/icons/");
}

if( !defined("JS_DIR") ){
	define("JS_DIR", LISTING_DIR . "js/");
}

if( !defined("CSS_DIR") ){
	define("CSS_DIR", LISTING_DIR . "css/");
}

if( !defined("THUMBNAIL_DIR") ){
	define("THUMBNAIL_DIR", LISTING_HOME . "images/thumbnails/");
}

if( !defined("THUMBNAIL_URL") ){
	define("THUMBNAIL_URL", LISTING_DIR . "images/thumbnails/");
}

// include files
include_once("functions.php");
include_once("the_widgets.php");
include_once("styling.php");
include_once("post-type.php");
include_once("portfolio.php");
include_once("shortcodes.php");
include_once("listing_categories.php");
include_once("file_import.php");
include_once("meta_boxes.php");
include_once("save.php");
include_once("page-templates.php");
include_once("resize.php");

include(LISTING_HOME . "ReduxFramework/loader.php");
	
// Redux Admin Panel
if ( !class_exists( 'ReduxFramework' ) && file_exists( LISTING_HOME . 'ReduxFramework/ReduxCore/framework.php' ) ) {
    require_once( LISTING_HOME . 'ReduxFramework/ReduxCore/framework.php' );
}
if ( !isset( $redux_demo ) && file_exists( LISTING_HOME . 'ReduxFramework/options/options.php' ) ) {
    require_once( LISTING_HOME . 'ReduxFramework/options/options.php' );
} ?>