<?php
if ( !class_exists( "ReduxFramework" ) ) {
	return;
}

if ( !class_exists( "Redux_Framework_automotive_wp_d2140d599153a83f21d2718" ) ) {
	class Redux_Framework_automotive_wp_d2140d599153a83f21d2718 {
		public function __construct( ) {

			// Your base config file for Redux
			add_action( 'after_setup_theme', array($this, 'loadConfig') );
			
			// Data migration
			add_action("after_switch_theme", array($this, "migrate_old_data"), 10 ,  2);	
			
		}

		public function loadConfig() {

			$sections = array (
		array (
			'title' => __('Automotive Settings', 'listings'),
			'fields' => array (
				array (
					'desc' => __('Name of service used for vehicle history reports', 'listings'),
					'id' => 'vehicle_history_label',
					'type' => 'text',
					'title' => __('Vehicle History Report', 'listings'),
					'default' => 'Carfax',
				),
				array (
					'desc' => __('Logo used for vehicle history reports', 'listings'),
					'id' => 'vehicle_history',
					'type' => 'media',
					'url' => true,
				),
				array (
					'desc' => __('The image used to display a vehicles fuel efficiency rating', 'listings'),
					'id' => 'fuel_efficiency_image',
					'type' => 'media',
					'title' => __('Fuel Efficiency Rating Image', 'listings')
				), 
				array (
					'id' => 'inventory_primary_title',
					'type' => 'text',
					'desc' => __('This title shows up in the header section of all listings posted.', 'listings'),
					'title' => __('Inventory Listing Titles', 'listings'),
					'default' => __('Inventory Listing', 'listings'),
				),
				array (
					'id' => 'inventory_secondary_title',
					'type' => 'text',
					'desc' => __('This secondary title displays under previous title in the header', 'listings'),
					'default' => __('Powerful Inventory Marketing, Fully Integrated', 'listings'),
				),
				array (
					'id' => 'inventory_page',
					'type' => 'select',
					'title' => __('Inventory Page', 'listings'),
					'desc' => __('Select the inventory page that will be highlighted in the menu', 'listings'),
					'data' => 'pages'
				),
				array (
					'id' => 'comparison_page',
					'type' => 'select',
					'title' => __('Comparison Page', 'listings'),
					'desc' => __('Select the comparison page that will be used', 'listings'),
					'data' => 'pages'
				),
				/*array (
					'id' => 'introduction_3',
					'icon' => true,
					'type' => 'info',
					'raw' => '<h3 style="margin: 0 0 10px;">' . __('Additional Parameters', 'listings') . ': </h3>
							' . __('These parameters do not show up on the inventory listings page, however they do while comparing vehicles and while viewing a single vehicle listing', 'listings') . '.',
				),*/
				array (
					'desc' => __('The amount of listings being displayed on the inventory page', 'listings'),
					'id' => 'listings_amount',
					'step' => '1',
					'max' => '100',
					'type' => 'slider',
					'title' => __('Number of listings', 'listings'),
				),
				array(
					'id' => 'sale_value',
					'title' => 'Sale Prefix',
					'type' => 'text',
					'desc' => __('This text gets prefixed to the "Price:" if listing is on sale (i.e. reduced, sale)', 'listings'),
				),
				array (
					'desc' => __('Toggle the functionality of the listing views', 'listings'),
					'id' => 'inventory_listing_toggle',
					'type' => 'switch',
					'default' => '1',
				),
				array (
					'id' => 'additional_categories',
				    'type' => 'multi_text',
				    'title' => __('Additional Categories', 'listings'),
				    'desc' => __('These categories will show up under the search box widget and are on each listing edit page.', 'listings'),
				    'default' => array(
				    	__('Certified', 'listings'),
				    	__('CARFAX Verified', 'listings'),
				    	__('Brand New', 'listings'),
				    )
				)
			),
			'icon' => 'fa fa-car',
		),
		array (
			'title' => __('Currency Settings', 'listings'),
			'fields' => array (
				array (
					'desc' => __('Enter in your symbol used for currency', 'listings'),
					'type' => 'text',
					'id' => 'currency_symbol',
					'title' => __('Currency Symbol', 'listings'),
				),
				array (
					'desc' => __('Change the position of the currency symbol', 'listings'),
					'type' => 'switch',
					'id' => 'currency_placement',
					'title' => __('Currency Symbol Placement', 'listings'),
					'off' => __('After Value', 'listings'),
					'on'  => __('Before Value', 'listings'),
					'default' => true
				),
				array (
					'desc' => __('Enter in a separator for large currency amounts', 'listings'),
					'type' => 'text',
					'id' => 'currency_separator',
					'title' => __('Currency Separator', 'listings'),
				),
			),
			'icon' => 'fa fa-usd',
		),
		array (
			'title' => __('Email Templates', 'listings'),
			'fields' => array (
				array (
					'desc' => __('Display this message when an email is successfully sent.', 'listings'),
					'id' => 'email_success',
					'type' => 'text',
					'title' => __('Email was sent', 'listings'),
					'default' => __('The email was sent.', 'listings'),
				),
				array (
					'desc' => __('Display this message when an email isn\'t successfully sent.', 'listings'),
					'id' => 'email_failure',
					'type' => 'text',
					'title' => __('Email failed to send', 'listings'),
					'default' => __('The email was not sent.', 'listings'),
				),
				array (
					'desc' => __('Display this message if the email is being marked by', 'listings') . ' <a href=\'http://akismet.com/\' target=\'_blank\'>Akismet.com</a>.',
					'id' => 'email_spam',
					'type' => 'text',
					'title' => __('Email is spam', 'listings'),
					'default' => __('The email you are trying to send is considered spam.', 'listings'),
				),
				array (
					'desc' => __('Edit the subject of the email that is used to tell friends about vehicles. You can use the variable', 'listings') . ' {name}',
					'id' => 'friend_subject',
					'type' => 'text',
					'title' => __('Email to a Friend', 'listings'),
					'default' => '{name} ' . __('wants you to check this vehicle out', 'listings'),
				),
				array (
					'desc' => __('Edit the layout of the email. HTML is allowed and some variables you can use are', 'listings') . ': <br><br> {name}, {table} ' . __('and', 'listings') . ' {message}',
					'id' => 'friend_layout',
					'type' => 'textarea',
					'default' => __('I want you check this vehicle out', 'listings') . ' {table} Message: {message}',
				),
				array (
					'desc' => __('Change the email that recieves the emails', 'listings'),
					'id' => 'drive_to',
					'type' => 'text',
					'title' => __('Schedule a Test Drive', 'listings'),
				),
				array (
					'desc' => __('Edit the subject of the email that is used to schedule test drives.', 'listings'),
					'id' => 'drive_subject',
					'type' => 'text',
					'default' => __('Scheduled Test Drive Request', 'listings'),
				),
				array (
					'desc' => __('Edit the layout of the email. HTML is allowed and some variables you can use are', 'listings') . ': <br><br> {name}, {contact_method}, {email}, {phone}, {best_day}, {best_time}, {table} ' . __('and', 'listings') . ' {link}',
					'id' => 'drive_layout',
					'type' => 'textarea',
					'default' => __('Information', 'listings') . '
	
	{table}
	
	Vehicle: {link}',
				),
				array (
					'desc' => __('Change the email that recieves the emails', 'listings'),
					'id' => 'info_to',
					'type' => 'text',
					'title' => __('Request More Info', 'listings'),
				),
				array (
					'desc' => __('Edit the subject of the email that is used to request more info.', 'listings'),
					'id' => 'info_subject',
					'type' => 'text',
					'default' => __('Information Request', 'listings'),
				),
				array (
					'desc' => __('Edit the layout of the email. HTML is allowed and some variables you can use are', 'listings') . ': <br><br> {name}, {contact_method}, {email}, {phone}, {table} ' . __('and', 'listings') . ' {link}',
					'id' => 'info_layout',
					'type' => 'textarea',
					'default' => __('Request Information', 'listings') . '
	
	{table}
	
	Vehicle: {link}',
				),
				array (
					'desc' => __('Change the email that recieves the emails', 'listings'),
					'id' => 'trade_to',
					'type' => 'text',
					'title' => __('Trade-In Appraisal', 'listings'),
				),
				array (
					'desc' => __('Edit the subject of the email that is used.', 'listings'),
					'id' => 'trade_subject',
					'type' => 'text',
					'default' => __('Trade-In Appraisal', 'listings'),
				),
				array (
					'desc' => __('Edit the layout of the email. HTML is allowed and some variables you can use are', 'listings') . ': <br><br> {table} ' . __('and', 'listings') . ' {link}',
					'id' => 'trade_layout',
					'type' => 'textarea',
					'default' => '{table}
	
	Vehicle: {link}',
				),
				array (
					'desc' => __('Change the email that recieves the emails', 'listings'),
					'id' => 'offer_to',
					'type' => 'text',
					'title' => 'Make an Offer',
				),
				array (
					'desc' => __('Edit the subject of the email that is used.', 'listings'),
					'id' => 'offer_subject',
					'type' => 'text',
					'default' => __('Offer', 'listings'),
				),
				array (
					'desc' => __('Edit the layout of the email. HTML is allowed and some variables you can use are', 'listings') . ': <br><br> {name}, {contact_method}, {email}, {phone}, {offered_price}, {financing_required}, {other_comments}, {table} ' . __('and', 'listings') . ' {link}',
					'id' => 'offer_layout',
					'type' => 'textarea',
					'default' => '{table}
	
	Vehicle: {link}',
				),
			),
			'icon' => 'fa fa-envelope-o',
		),
		array (
			'title' => __('Custom Forms', 'listings'),
			'fields' => array (
				array (
					'desc' => 'Using <a href=\'https://wordpress.org/plugins/contact-form-7/\' target=\'_blank\'>Contact Form 7</a> you can replace any of the following forms by pasting a shortcode of the form in the corresponding text box. If left blank the default form will show',
					'id' => 'request_info_form_shortcode',
					'type' => 'text',
					'title' => __('Request More Info Form', 'listings'),
				),
				array (
					'id' => 'schedule_test_drive_form_shortcode',
					'type' => 'text',
					'title' => __('Schedule Test Drive Form', 'listings'),
				),
				array (
					'id' => 'make_offer_form_shortcode',
					'type' => 'text',
					'title' => __('Make an Offer Form', 'listings'),
				),
				array (
					'id' => 'tradein_form_shortcode',
					'type' => 'text',
					'title' => __('Trade-In Appraisal Form', 'listings'),
				),
				array (
					'id' => 'email_friend_form_shortcode',
					'type' => 'text',
					'title' => __('Email to a Friend Form', 'listings'),
				),
				array(
					'id'       => 'section-start',
					'type'     => 'section',
					'title'    => __('Google reCAPTCHA API', 'listings'),
					'subtitle' => 'You can get a Google reCAPTCHA API from <a href="http://www.google.com/recaptcha/intro/" target="_blank">here</a>',
					'indent'   => true 
				),
				array(
				    'id'       => 'recaptcha_enabled',
				    'type'     => 'switch', 
				    'title'    => __('ReCAPTCHA enabled', 'listings'),
				    'default'  => true,
				),
				array(
					'id'       => 'recaptcha_public_key',
				    'type'     => 'text',
				    'title'    => __('Public Key', 'listings'),
				),
				array(
					'id'       => 'recaptcha_private_key',
				    'type'     => 'text',
				    'title'    => __('Private Key', 'listings'),
				),
				array(
				    'id'     => 'section-end',
				    'type'   => 'section',
				    'indent' => false,
				)
			),
			'icon' => 'fa fa-bars',
		),
		array(
			'title' => __('Widget Settings', 'listings'),
			'fields' => array(
				array (
					'desc' => __('Paste your mailchimp API key here to let users subscribe from your site', 'listings'),
					'id' => 'mailchimp_api_key',
					'type' => 'text',
					'title' => __('MailChimp API', 'listings'),
				),
				array (
					'desc' => __('Turn on to enable widget twitter feeds', 'listings') . '.<br><br><a href=\'http://dev.twitter.com/apps\' target=\'_blank\'>' . __('Create a Twitter application here', 'listings') . '</a>',
					'id' => 'twitter_switch',
					'type' => 'switch',
					'title' => __('Twitter Widget Feed', 'listings'),
				),
				array (
					'id' => 'consumer_key',
					'type' => 'text',
					'title' => __('API Key', 'listings'),
					'required' => array (
						0 => 'twitter_switch',
						1 => '=',
						2 => 1,
					),
				),
				array (
					'id' => 'secret_consumer_key',
					'type' => 'text',
					'title' => __('API Secret Key', 'listings'),
					'required' => array (
						0 => 'twitter_switch',
						1 => '=',
						2 => 1,
					),
				),
				array (
					'id' => 'access_token',
					'type' => 'text',
					'title' => __('Access Token', 'listings'),
					'required' => array (
						0 => 'twitter_switch',
						1 => '=',
						2 => 1,
					),
				),
				array (
					'id' => 'secret_access_token',
					'type' => 'text',
					'title' => __('Access Token Secret', 'listings'),
					'required' => array (
						0 => 'twitter_switch',
						1 => '=',
						2 => 1,
					),
				),
			),
			'icon' => 'fa fa-gear'
		),
		array(
			'title' => __('Inventory Page', 'listings'),
			'fields' => array(
				array(
					'desc' => __('Show or hide the fuel efficiency box on the inventory page', 'listings'),
					'id' => 'fuel_efficiency_show',
					'type' => 'switch',
					'title' => __('Fuel Efficiency', 'listings'),
					'on' => 'Show',
					'off' => 'Hide',
					'default' => true
				),
				array(
					'desc' => __('The text displayed in the fuel efficiency box', 'listings'),
					'id' => 'fuel_efficiency_text',
					'type' => 'textarea',
					'default' => 'Actual rating will vary with options, driving conditions, driving habits and vehicle condition.',
					'required' => array('fuel_efficiency_show', 'equals', 1)
				),
				array(
					'desc' => __('Show or hide the social icons', 'listings'),
					'id' => 'social_icons_show',
					'type' => 'switch',
					'title' => __('Social Icons', 'listings'),
					'on' => 'Show',
					'off' => 'Hide',
					'default' => true
				),
				array(
					'desc' => __('Show or hide the financing calculator', 'listings'),
					'id' => 'calculator_show',
					'type' => 'switch',
					'title' => __('Financing Calculator', 'listings'),
					'on' => 'Show',
					'off' => 'Hide',
					'default' => true
				),
				array(
					'desc' => __('Control the annual interest rate for the finance calculator', 'listings'),
					'id' => 'calculator_rate',
					'type' => 'text',
					'validate' => 'numeric',
					'title' => __('Financing Calculator Rate', 'listings'),
					'default' => 7,
					'required' => array('calculator_show', '=', true)
				),
				array(
					'desc' => __('Show or hide the recent vehicles', 'listings'),
					'id' => 'recent_vehicles_show',
					'type' => 'switch',
					'title' => __('Recent Vehicles', 'listings'),
					'on' => 'Show',
					'off' => 'Hide',
					'default' => true
				),
				array(
				    'id'     => 'section-end',
				    'type'   => 'section',
				    'indent' => false,
				),
				array(
					'id'       => 'section-start',
					'type'     => 'section',
					'title'    => __('Top buttons', 'listings'),
					'subtitle' => __('Show or hide the top buttons found on the inventory listing page.', 'listings'),
					'indent'   => true 
				),
				array(
					'title' => __('Previous Vehicle', 'listings'),
					'id' => 'previous_vehicle_show',
					'type' => 'switch',
					'on' => 'Show',
					'off' => 'Hide',
					'default' => true
				),
				array(
					'title' => __('Request More Info', 'listings'),
					'id' => 'request_more_show',
					'type' => 'switch',
					'on' => 'Show',
					'off' => 'Hide',
					'default' => true
				),
				array(
					'title' => __('Schedule Test Drive', 'listings'),
					'id' => 'schedule_test_show',
					'type' => 'switch',
					'on' => 'Show',
					'off' => 'Hide',
					'default' => true
				),
				array(
					'title' => __('Make an Offer', 'listings'),
					'id' => 'make_offer_show',
					'type' => 'switch',
					'on' => 'Show',
					'off' => 'Hide',
					'default' => true
				),
				array(
					'title' => __('Trade-In Appraisal', 'listings'),
					'id' => 'tradein_show',
					'type' => 'switch',
					'on' => 'Show',
					'off' => 'Hide',
					'default' => true
				),
				array(
					'title' => __('PDF Brochure', 'listings'),
					'id' => 'pdf_brochure_show',
					'type' => 'switch',
					'on' => 'Show',
					'off' => 'Hide',
					'default' => true
				),
				array(
					'title' => __('Print this Vehicle', 'listings'),
					'id' => 'print_vehicle_show',
					'type' => 'switch',
					'on' => 'Show',
					'off' => 'Hide',
					'default' => true
				),
				array(
					'title' => __('Email to a Friend', 'listings'),
					'id' => 'email_friend_show',
					'type' => 'switch',
					'on' => 'Show',
					'off' => 'Hide',
					'default' => true
				),
				array(
					'title' => __('Next Vehicle', 'listings'),
					'id' => 'next_vehicle_show',
					'type' => 'switch',
					'on' => 'Show',
					'off' => 'Hide',
					'default' => true
				),
				array(
				    'id'     => 'section-end',
				    'type'   => 'section',
				    'indent' => false,
				),
				array(
					'id'       => 'section-start',
					'type'     => 'section',
					'title'    => __('Content Tabs', 'listings'),
					'subtitle' => __('Edit the names of the tabs displayed under the slideshow.', 'listings'),
					'indent'   => true 
				),
				array(
					'title' => __('First Tab', 'listings'),
					'desc' => __('Default text: Vehicle Overview', 'listings'),
					'id' => 'first_tab',
					'type' => 'text',
					'default' => 'Vehicle Overview'
				),
				array(
					'title' => __('Second Tab', 'listings'),
					'desc' => __('Default text: Features & Options', 'listings'),
					'id' => 'second_tab',
					'type' => 'text',
					'default' => 'Features & Options'
				),
				array(
					'title' => __('Third Tab', 'listings'),
					'desc' => __('Default text: Technical Specifications', 'listings'),
					'id' => 'third_tab',
					'type' => 'text',
					'default' => 'Technical Specifications'
				),
				array(
					'title' => __('Fourth Tab', 'listings'),
					'desc' => __('Default text: Vehicle Location', 'listings'),
					'id' => 'fourth_tab',
					'type' => 'text',
					'default' => 'Vehicle Location'
				),
				array(
					'title' => __('Fifth Tab', 'listings'),
					'desc' => __('Default text: Other Comments', 'listings'),
					'id' => 'fifth_tab',
					'type' => 'text',
					'default' => 'Other Comments'
				),
				array(
				    'id'     => 'section-end',
				    'type'   => 'section',
				    'indent' => false,
				),
			),
			'icon' => 'fa fa-file-o'
		),
		array(
			'title' => __("Portfolio Page", "listings"),
			'fields' => array(				
				array(
					'title' => __('Job Description Title', 'listings'),
					'id' => 'job_description_title',
					'type' => 'text',
					'default' => 'Job Description'
				),
				array(
					'title' => __('Project Details Title', 'listings'),
					'id' => 'project_details_title',
					'type' => 'text',
					'default' => 'Projects Details'
				),
				array(
					'title' => __('Related Projects Title', 'listings'),
					'id' => 'related_projects_title',
					'type' => 'text',
					'default' => 'Related Projects'
				),
			),
			'icon' => 'fa fa-folder-o'
		),
		array(
			'title' => __('Default Values', 'listings'),
			'fields' => array(
				array(
					'id'       => 'section-start',
					'type'     => 'section',
					'title'    => __('Default location', 'listings'),
					'subtitle' => __('This location will be the default used while creating new listings', 'listings'),
					'indent'   => true 
				),
				array(
					'title' => __('Latitude', 'listings'),
					'desc' => __('The default latitude.', 'listings'),
					'id' => 'default_value_lat',
					'type' => 'text',
					'default' => '43.653226'
				),
				array(
					'title' => __('Longitude', 'listings'),
					'desc' => __('The default longitde.', 'listings'),
					'id' => 'default_value_long',
					'type' => 'text',
					'default' => '-79.3831843'
				),
				array(
					'title' => __('Zoom', 'listings'),
					'desc' => __('The default zoom level.', 'listings'),
					'id' => 'default_value_zoom',
					'type' => 'slider',
					'default' => '10',
					'min' => 0,
					'max' => 19,
					'step' => 1,
					'display_value' => 'text'
				),
				array(
				    'id'     => 'section-end',
				    'type'   => 'section',
				    'indent' => false,
				),
				array(
					'id'       => 'section-start',
					'type'     => 'section',
					'title'    => __('Default Details', 'listings'),
					'subtitle' => __('Control the default values for the details of new listings.', 'listings'),
					'indent'   => true 
				),
				array(
					'title' => __('Price Label', 'listings'),
					'desc' => __('The default label for price.', 'listings'),
					'id' => 'default_value_price',
					'type' => 'text',
					'default' => 'Price'
				),
				array(
					'title' => __('City MPG Label', 'listings'),
					'desc' => __('The default label for city MPG.', 'listings'),
					'id' => 'default_value_city',
					'type' => 'text',
					'default' => 'City'
				),
				array(
					'title' => __('Highway MPG Label', 'listings'),
					'desc' => __('The default label for highway MPG.', 'listings'),
					'id' => 'default_value_hwy',
					'type' => 'text',
					'default' => 'Highway'
				),
				array(
				    'id'     => 'section-end',
				    'type'   => 'section',
				    'indent' => false,
				),
			),
			'icon' => 'fa fa-pencil-square-o'
		),
		array(
			'title' => __("Import / Export", "listings"),
			'class' => 'custom_import',
			'fields'    => array(
			    array(
			        'id'            => 'opt-import-export',
			        'type'          => 'import_export',
			        'title'         => __('Import Export', 'listings'),
			        'subtitle'      => __('Save and restore your Redux options', 'listings'),
			        'full_width'    => true,
			    ),
			),
			'icon' => 'el-icon-refresh'
		)
	);	

			// import listing categories
			$show_listing_categories = (get_option('show_listing_categories') ? get_option('show_listing_categories') : "show");

			if($show_listing_categories != "hide"){
			    $sections[8]['fields'][] = array(
				    'id'       => 'import-demo-listing-categories',
				    'type'     => 'custom_import',
				    'title'    => __('Import Demo Listing Categories', 'listings'),
				    'desc'     => "<span class='remove_option_categories'>" . __('Click here to permanently remove this option from view.', 'listings') . "</span>",
				    'options' => array(
				        '1' => __('Import', 'listings')
				     ),
				    'class'    => 'import_listing_categories',
				    'default' => 1
				);
			}

			$listing_categories = get_filterable_listing_categories();

			$widths = array( 
				array (
					'id' => 'introduction_2',
					'icon' => true,
					'type' => 'info',
					'raw' => '<h3 style="margin: 0 0 10px;">' . __('Filterable Parameters', 'listings') . '.</h3>
							' . __('You can use these parameters on the inventory listing page to sort the results', 'listings') . '.',
				));

			if(!empty($listing_categories)){
				foreach($listing_categories as $category){
					$safe_label = str_replace(" ", "_", strtolower($category['singular']));

					$widths[] = array(
						'id'    => $safe_label . '_width',
						'step'  => '1',
						'max'   => '150',
						'type'  => 'slider',
						'title' => $category['plural'] . ' ' . __('Dropdown Width', 'listings'),
					);
				}

				// widths
				$sections[0]['fields'] = array_merge($sections[0]['fields'], $widths);
			}



			// Change your opt_name to match where you want the data saved.
			$args = array(
				"opt_name"=>"listing_wp", // Where your data is stored. Use a different name or use the same name as your current theme. Must match the $database_newName variable in the converter code.
				"menu_title" => __("Listing Options", 'listings'), // Title for your menu item
				"page_slug" => "listing_wp", // Make this the same as your opt_name unless you care otherwise
				"global_variable" => "listing_wp", // By default Redux sets your global variable to be the opt_name you set above. This is what the newest SMOF uses as it's variable name. You can change, but you may need to update your files.
				//"intro_text" => "<p>This theme is now using Redux</p>" // Extra header info
				//"google_api_key" => "", // You must acquire a Google Web Fonts API key if you want Google Fonts to work
			);
			// Use this section if this is for a theme. Replace with plugin specific data if it is for a plugin.
			$theme = wp_get_theme();
			$args["display_name"] = $theme->get("Name");
			$args["display_version"] = $theme->get("Version");

			$ReduxFramework = new ReduxFramework($sections, $args);
						
		}

		function migrate_old_data($oldname, $oldtheme=false) {
			$database_newName = "automotive_wp"; // Where your data will now be saved. Must match your opt_name in the ReduxFramework $args array.
			$this->convertDataClass = new SMOF2Redux_Data();
			$this->convertDataClass->init();
			update_option($database_newName, $this->convertDataClass->converted_data); // Update the database				
		}
				
	}
	new Redux_Framework_automotive_wp_d2140d599153a83f21d2718();
}




if( !class_exists( 'SMOF2Redux_Data' ) ) {
	class SMOF2Redux_Data {

		protected $converter;
		public $version;
		public $database;
		public $data;
		public $converted_data;
		public $sections = array();
		public $framework = "SMOF";

		public function __construct() {

			//add_action('init', array( $this, 'init' ), 0 );

		}

		public function init() {
			// Find the version
			if (defined('SMOF_VERSION')) {
				$this->version = SMOF_VERSION;
			} else {
				$this->version = '1.3';
			}

			// Get the saved data
			if ( $this->version <= "1.5" ) {
				// Get the old data values
				global $data;
				$this->data = $data;

				if ( defined( 'OPTIONS' ) ) {
					$this->database = OPTIONS;	
				}
			} else {
				global $smof_data;
				$this->data = $smof_data;
			}			

			$this->getSections();
			
			if (!empty($this->sections)) {
				foreach($this->sections as $section) {
					if (isset($section['fields']) && !empty($section['fields'])) {
						foreach($section['fields'] as $field) {
							if (isset($this->data[$field['id']])) {
								$this->converted_data[$field['id']] = $this->convertValue($this->data[$field['id']], $field['type']);
							}
						}
					}
				}
			}

		}

		public function getSections($withWarnings = true) {
			global $of_options;

			$sections = array();
			$section = array();
			$fields = array();	
			
			if(!empty($of_options)){
				foreach($of_options as $key=>$value) {
					foreach ($value as $k=>$v) {
						if (empty($v)) {
							unset($value[$k]);
						}
					}
					
					if (isset($value['name'])) {
						$value['title'] = $value['name'];
						unset($value['name']); 
					}
	
					if (isset($value['std'])) {
						$value['default'] = $value['std'];
						unset($value['std']);
					}
	
					if (isset($value['fold'])) {
						$value['required'] = array($value['fold'], '=' , 1);
						unset($value['fold']);
					}
					if (isset($value['folds'])) {
						unset($value['folds']);
					}	    
					if (!isset($value['type'])) {
						continue;
					}
					switch ($value['type']) {
						case 'heading':
							if (isset($value['icon']) && !empty($value['icon']) ) {
								//$value['icon_type'] = "image";
							}
							if (!empty($fields)) {
								$section['fields'] = $fields;
								$fields = array();
							}
							if (!empty($section)) {
								$section['icon'] = "el-icon-cog";
								$sections[] = $section;
								$section = array();
							} 
							unset($value['type']);
							$section = $value;
							unset($value);
							break;
						case "text":
							if(isset($value['mod'])) {
								unset($value['mod']);
							}
							break;
						case "select":
							if(isset($value['mod'])) {
								unset($value['mod']);
							}
							break;
						case "textarea":
							if(isset($value['cols'])) {
								unset($value['cols']);
							}
							break;
						case "radio":
							break;
						case "checkbox":
							break;
						case "multicheck":
							$value['type'] = "checkbox";
							break;
						case "color":
							break;
						case "select_google_font":	
							if (isset($value['preview'])) {
								unset($value['preview']);
							}
							if (isset($value['options'])) {
								$value['fonts'] = $value['options'];
	
								unset($value['options']);
							}
							if (isset($value['default'])) {
								unset($value['default']);
							}
							$value['type'] = "typography";
							break;
						case "typography":
							if (isset($value['preview'])) {
								unset($value['preview']);
							}
							if (isset($value['options'])) {
								$value['fonts'] = $value['options'];
								unset($value['options']);
							}
							break;
						case "border":    			    		
							break;
						case "info":
							if (isset($value['title'])) {
								unset($value['title']);
							}
							if (isset($value['default'])) {
								$value['raw'] = $value['default'];
								unset($value['default']);
							}
							break;
						case "switch":
							break;
						case "images":
							$value['type'] = "image_select";
							if (strpos(strtolower($value['title']),'pattern') !== false) {
								$value['tiles'] = true;
							}
							break;
						case "image":
							$value['type'] = "info";
							$value['raw_html'] = true;
							break;
						case "slider":
							$value['type'] = "slides";
							break;
						case "sorter":
							if (isset($value['default'])) {
								$value['options'] = $value['default'];
								unset($value['default']);
							}
							break;
						case "tiles":
							$value['type'] = "image_select";
							$value['tiles'] = true;
							break;
						case "backup":
						case "transfer":
							unset($value);
							if ($of_options[($key-1)]['type'] == "heading") {
								if (strpos(strtolower($of_options[($key-1)]['name']),'backup') !== false) {
									$section = array();	
								}
							}
							break;
						case "sliderui":
							$value['type'] = "slider";
							break;	    			    			    			    			    		
						case "upload":
						case "media":
							$value['type'] = "media";
							if (isset($value['mod']) && $value['mod'] == "min") {
								unset($value['mod']);
							} else {
								$value['url'] = true;
							}
							break;
	
						default:
							if ($withWarnings) {
								$content = "<h3 style='color: red;'>Found a field with an unknown type!</h3> <p>Perhaps this was a custom field and will need to be remade for use within Redux. This was the field's configuration:</p>";
								$content .= "<pre style='overflow:auto;border: 2px dashed #eee;padding: 2px 5px; width: 100%;'>";
								ob_start();
								var_dump($value);
								$content .= ob_get_clean();
								$content .= "</pre>";
								$value['desc'] = $content;
								$value['type'] = "info";
								$value['raw_html'] = true;			    			
							}
							
						//unset($value); // Can't do custom types. Must be fixed manually.
							# code...
							break;
					}
					if (isset($value['default']) && !empty($value['default'])) {
						$value['default'] = $this->convertValue($value['default'], $value['type']);
					}
	
					if (!empty($value)) {
						$fields[] = $value;	
					}
					
				}
			}
			if (!empty($fields)) {
				$section['fields'] = $fields;
				$fields = array();
			}
			if (!empty($section)) {

				$sections[] = $section;
				$section = array();
			}		
			$this->sections = $sections;

		}

		function get_attachment_id_by_url( $url ) {
			// Split the $url into two parts with the wp-content directory as the separator.
			$parse_url  = explode( parse_url( WP_CONTENT_URL, PHP_URL_PATH ), $url );
		 	
			// Get the host of the current site and the host of the $url, ignoring www.
			$this_host = str_ireplace( 'www.', '', parse_url( home_url(), PHP_URL_HOST ) );
			$file_host = str_ireplace( 'www.', '', parse_url( $url, PHP_URL_HOST ) );
		 
			// Return nothing if there aren't any $url parts or if the current host and $url host do not match.
			if ( ! isset( $parse_url[1] ) || empty( $parse_url[1] ) || ( $this_host != $file_host ) )
				return;
		 
			// Now we're going to quickly search the DB for any attachment GUID with a partial path match.
			// Example: /uploads/2013/05/test-image.jpg
			global $wpdb;
		 
			$prefix     = $wpdb->prefix;
			$attachment = $wpdb->get_col( $wpdb->prepare( "SELECT ID FROM " . $prefix . "posts WHERE guid RLIKE %s;", $parse_url[1] ) );
		 
			// Returns null if no attachment is found.
			return $attachment[0];
		}		

		function convertValue($value, $type) {
		    switch ($type) {
				case "text":
					if (!is_array($value)) {
						$value = stripcslashes($value); // Not sure why this happens. Huh.
					}
		    		break;
		    	case "typography":
					$default = array();
					if (isset($value['size'])) {
						$default['font-size'] = $value['size'];
						$px = filter_var($default['font-size'], FILTER_SANITIZE_NUMBER_INT);
						$default['units'] = str_replace($px, "", $default['font-size']);
					}
					if (isset($value['color'])) {
						$default['color'] = $value['color'];
					}
					if (isset($value['face'])) {
						$fonts = array(
							"Arial, Helvetica, sans-serif",
							"'Arial Black', Gadget, sans-serif",
							"'Bookman Old Style', serif",
							"'Comic Sans MS', cursive",
							"Courier, monospace",
							"Garamond, serif",
							"Georgia, serif",
							"Impact, Charcoal, sans-serif",
							"'Lucida Console', Monaco, monospace",
							"'Lucida Sans Unicode', 'Lucida Grande', sans-serif",
							"'MS Sans Serif', Geneva, sans-serif",
							"'MS Serif', 'New York', sans-serif",
							"'Palatino Linotype', 'Book Antiqua', Palatino, serif",
							"Tahoma, Geneva, sans-serif",
							"'Times New Roman', Times, serif",
							"'Trebuchet MS', Helvetica, sans-serif",
							"Verdana, Geneva, sans-serif",
		                );
		                foreach($fonts as $font) {
		                	if (strpos(strtolower($font),strtolower($value['face'])) !== false) {
								$default['font-family'] = $font;
							}
		                }
					}
					if (isset($value['style'])) {
						if (strpos(strtolower($value['style']),'bold') !== false) {
							$default['font-weight'] = "bold";
						}
						if (strpos(strtolower($value['style']),'italic') !== false) {
							$default['font-style'] = "italic";
						}
					} 			
					$value = $default;
		    		break;
		    	case "border":
		    		if (isset($value['width'])) {
		    			$value['border-width'] = $value['width']."px";
		    			$value['units'] = "px";
		    			unset($value['width']);
		    		}
					if (isset($value['color'])) {
		    			$value['border-color'] = $value['color'];
		    			unset($value['color']);
		    		}
					if (isset($value['style']) && !empty($value['style'])) {
		    			$value['border-style'] = $value['style'];
		    			unset($value['style']);
		    		}
		    		break;			    			    			    			    		
		    	case "upload":
		    	case "image":
				case "media":
					if ( isset( $value ) && !empty( $value ) ) {
						$value = array('url'=>$value);	
					}
		    		break;    	
		    	default:
		    		break;
		    }
			return $value;			
		}	
	}

}

/*
1.5
	SMOF_VERSION
	define( 'OPTIONS', $theme_name.'_options' );
	$data = of_get_options();
	$smof_data = of_get_options();


1.4.3
	define( 'OPTIONS', $theme_name.'_options' );

        if( is_child_theme() ) {
                $temp_obj = wp_get_theme();
                $theme_obj = wp_get_theme( $temp_obj->get('Template') );
        } else {
                $theme_obj = wp_get_theme();    
        }

        define( 'OPTIONS', $theme_name.'_options' );

        SMOF_VERSION -> Version

1.4
	SMOF_VERSION -> Version
	DEFINE: OPTIONS
	$data => values
	$data = get_option(OPTIONS);	

1.3
	DEFINE: OPTIONS
	$of_options => Options
	$data => values
	$data = get_option(OPTIONS);

v1.2


v1.1 13/11/11
	DEFINE: OPTIONS
	$of_options => Options
	$data => values
	$data = get_option(OPTIONS);
 */
 ?>