<?php

function register_listing_post_type() {
	//********************************************
	//	Register the post type
	//***********************************************************

	$labels = array(
	  'name'          	    => __('Listings', 'listings'),
	  'singular_name'		=> __('Listing', 'listings'),
	  'add_new'			 	=> __('Add New', 'listings'),
	  'add_new_item'		=> __('Add New Listing', 'listings'),
	  'edit_item'			=> __('Edit Listing', 'listings'),
	  'new_item'			=> __('New Listing', 'listings'),
	  'all_items'			=> __('All Listings', 'listings'),
	  'view_item' 		 	=> __('View Listing', 'listings'),
	  'search_items'		=> __('Search Listings', 'listings'),
	  'not_found'          	=> __('No listings found', 'listings'),
	  'not_found_in_trash' 	=> __('No listings found in Trash',  'listings'),
	  'menu_name'			=> __('Listings', 'listings')
	);
  
	$args = array(
	  'labels'              => $labels,
	  'public'              => true,
	  'publicly_queryable' 	=> true,
	  'show_ui'            	=> true, 
	  'show_in_menu' 	    => true, 
	  'query_var'          	=> true,
	  'rewrite' 	        => array( 'slug' => 'listings' ),
	  'capability_type'    	=> 'post',
	  'has_archive'        	=> true, 
	  'hierarchical'       	=> false,
	  'taxonomies' 			=> array('listing_category'), 
	  'menu_position'      	=> null
	); 
  
	register_post_type( 'listings', $args );
  
}

add_action( 'init', 'register_listing_post_type' );

?>