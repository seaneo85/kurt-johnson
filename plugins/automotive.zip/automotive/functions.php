<?php

add_action('get_header', 'my_filter_head');

  function my_filter_head() {
    remove_action('wp_head', '_admin_bar_bump_cb');
  }	

// image sizes
add_image_size("auto_thumb", $slider_thumbnails['width'], $slider_thumbnails['height'], true);
add_image_size("auto_slider", $slider_thumbnails['slider']['width'], $slider_thumbnails['slider']['height'], true);
add_image_size("auto_listing", $slider_thumbnails['listing']['width'], $slider_thumbnails['listing']['height'], true);

function auto_image($id, $size, $url = false){
	$return = ($url == true ? wp_get_attachment_image_src( $id, $size ) : wp_get_attachment_image( $id, $size ));

	return ($url == true ? $return[0] : $return);
}		

// category functions
function get_listing_categories($multi_options = false){
	$current_categories = get_option( 'listing_categories' );
	if($current_categories == false){
		$current_categories = array();
	}

	if($multi_options == false){
		unset($current_categories['options']);
	}

	return $current_categories;
}

function get_single_listing_category($category){
	$current_categories = get_option( 'listing_categories' );
	if(!isset($current_categories[$category]) && empty($current_categories[$category])){
		$return = array();
	} else {
		$return = $current_categories[$category];
	}

	return $return;	
}

function get_filterable_listing_categories(){	
	$current_categories = get_option( 'listing_categories' );
	$filterable_categories = array();

	if($current_categories == false){
		$current_categories = array();
	} else {
		foreach($current_categories as $category){
			if(isset($category['filterable']) && $category['filterable'] == 1){
				$filterable_categories[$category['singular']] = $category;
			}
		}
	}

	return $filterable_categories;
}

function get_use_on_listing_categories(){	
	$use_on_categories = array();

	$current_categories = get_option( 'listing_categories' );
	if($current_categories == false){
		$current_categories = array();
	} else {
		foreach($current_categories as $category){
			if(isset($category['use_on_listing']) && $category['use_on_listing'] == 1){
				$use_on_categories[$category['singular']] = $category;
			}
		}
	}

	return $use_on_categories;
}

function get_category_correct_case($category, $value){
	$category      = str_replace(array("-", " "), "_", strtolower($category));

	$list_category = get_single_listing_category($category);
	$return        = false;

	$value 		   = str_replace("--", "-", $value);

	if(!empty($list_category['terms'])){
		foreach($list_category['terms'] as $term){
			if(str_replace(" ", "-", strtolower($term)) == $value){
				$return = $term;
			}
		}
	}

	return $return;
}

function automotive_plugin_editor_styles() {
    add_editor_style( CSS_DIR . 'wp.css' );
    //add_editor_style( CSS_DIR . 'bootstrap.css' );
    add_editor_style( CSS_DIR . 'bootstrap.min.css' );
}
add_action( 'init', 'automotive_plugin_editor_styles' );

//********************************************
//	Register Sidebar
//***********************************************************
$args = array(
	'name'          => __( 'Listings Sidebar', 'listings' ),
	'id'            => 'listing_sidebar',
	'description'   => '',
    'class'         => '',
	'before_widget' => '<div class="side-widget padding-bottom-50">',
	'after_widget' => '</div>',
	'before_title' => '<h3 class="side-widget-title margin-bottom-25">',
	'after_title' => '</h3>' );

register_sidebar( $args );

//********************************************
//	Get Table Prefix
//***********************************************************
if(!function_exists("get_table_prefix")){
	function get_table_prefix() {
		global $wpdb;
		return $wpdb->prefix;
	}
}

//********************************************
//	Inventory Listing
//***********************************************************
if(!function_exists("inventory_listing")){
	function inventory_listing($id, $layout = "fullwidth"){ 
		global $lwp_options;

		ob_start(); 
		
		$listing   = get_post($id);	
		$post_meta = get_post_meta_all($id);
		
		$listing_options = unserialize(unserialize($post_meta['listing_options']));
		
		if($layout == "boxed_fullwidth"){
			echo "<div class=\"col-lg-3 col-md-4 col-sm-6 col-xs-12\">";
		} elseif($layout == "boxed_left"){
			echo "<div class=\"col-lg-4 col-md-6 col-sm-6 col-xs-12\">";
		} elseif($layout == "boxed_right"){
			echo "<div class=\"col-lg-4 col-md-6 col-sm-6 col-xs-12\">";
		}
		
		// determine image
		$gallery_images = unserialize((isset($post_meta['gallery_images']) && !empty($post_meta['gallery_images']) ? $post_meta['gallery_images'] : ""));
		
		//D($gallery_images);
		
		if(isset($gallery_images) && !empty($gallery_images) && isset($gallery_images[0])){
			$image_src = auto_image($gallery_images[0], "auto_listing", true);
		} else {
			$image_src = "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7";
		}
		
		// get youtube id
		if(isset($listing_options['video']) && !empty($listing_options['video'])){
			parse_str( parse_url( $listing_options['video'], PHP_URL_QUERY ), $vars );
			$youtube_id = $vars['v'];  
		}
		
		// determine if checked
		if(isset($_COOKIE['compare_vehicles']) && !empty($_COOKIE['compare_vehicles'])){
			$compare_vehicles = explode(",", urldecode($_COOKIE['compare_vehicles']));
		} ?>
	    
	    <div class="inventory clearfix margin-bottom-20 styled_input"> 
	        <input type="checkbox" class="checkbox compare_vehicle" id="vehicle_<?php echo $id; ?>" data-id="<?php echo $id; ?>"<?php echo (isset($compare_vehicles) && in_array($id, $compare_vehicles) ? " checked='checked'" : ""); ?> />
	        <label for="vehicle_<?php echo $id; ?>"></label>

	        <?php if(isset($listing_options['badge_text']) && !empty($listing_options['badge_text'])){ ?>
		        <div class="angled_badge <?php echo str_replace(" ", "_", $listing_options['badge_color']); ?>">
		        	<span<?php echo (strlen($listing_options['badge_text']) >= 10 ? " class='smaller'" : ""); ?>><?php echo $listing_options['badge_text']; ?></span>
		        </div>
	        <?php } ?>

	        <a class="inventory<?php echo (isset($listing_options['badge_text']) && !empty($listing_options['badge_text']) ? " has_badge" : ""); ?>" href="<?php echo get_permalink($id); ?>">
	            <div class="title"><?php echo $listing->post_title; ?></div>
	            <img src="<?php echo $image_src; ?>" class="preview" alt="<?php _e("preview", "listings"); ?>">

	            <?php $listing_details = get_use_on_listing_categories(); 

	            if(count($listing_details) > 5){
	            	$first_details  = array_slice($listing_details, 0, 5, true);
	            	$second_details = array_slice($listing_details, 5, count($listing_details), true);
	            } else {
	            	$single_table  = true;
	            	$first_details = $listing_details;
	            }

	            echo "<table class='options-primary'>";
	            foreach($first_details as $detail){
	            	$safe_handle = str_replace(" ", "_", strtolower($detail['singular']));
	            	$value       = (isset($post_meta[$safe_handle]) && !empty($post_meta[$safe_handle]) ? $post_meta[$safe_handle] : "");

	            	if(empty($value) && isset($detail['compare_value']) && $detail['compare_value'] != "="){
						$value = 0;
					} elseif(empty($value)) {
						$value = __("None", "listings");
					}

	            	echo "<tr>";
	            		echo "<td class='option primary'>" . $detail['singular'] . ": </td>";
	            		echo "<td class='spec'>" . $value . "</td>";
	            	echo "</tr>";
	            }
	            echo "</table>";

	            if(!isset($single_table)){
	            	echo "<table class='options-secondary'>";
		            foreach($second_details as $detail){
		            	$safe_handle = str_replace(" ", "_", strtolower($detail['singular']));
		            	$value       = (isset($post_meta[$safe_handle]) && !empty($post_meta[$safe_handle]) ? $post_meta[$safe_handle] : "");

		            	if(empty($value) && isset($detail['compare_value']) && $detail['compare_value'] != "="){
							$value = 0;
						} elseif(empty($value)) {
							$value = __("None", "listings");
						}

		            	echo "<tr>";
		            		echo "<td class='option secondary'>" . $detail['singular'] . ": </td>";
		            		echo "<td class='spec'>" . $value . "</td>";
		            	echo "</tr>";
		            }
		            echo "</table>";
	            }

	            ?>
	            <?php  if(isset($lwp_options['vehicle_history']) && !empty($lwp_options['vehicle_history']) && isset($post_meta['verified'])){ ?>
	            <img src="<?php echo $lwp_options['vehicle_history']['url']; ?>" alt="<?php echo (isset($lwp_options['vehicle_history_label']) && !empty($lwp_options['vehicle_history_label']) ? $lwp_options['vehicle_history_label'] : ""); ?>" class="carfax" />
				<?php } ?>

				<?php if(isset($listing_options['price']['value']) && !empty($listing_options['price']['value'])){
					$original = (isset($listing_options['price']['original']) && !empty($listing_options['price']['original']) ? $listing_options['price']['original'] : ""); ?>

		            <div class="price"><b><?php echo (!empty($original) ? $lwp_options['sale_value'] : "") . (isset($listing_options['price']['text']) ? $listing_options['price']['text'] :  __("Price", "listings")); ?>:</b><br>
		                <div class="figure"><?php echo format_currency($listing_options['price']['value']); ?><br></div>
		                <div class="tax"><?php _e("Plus Sales Tax", "listings"); ?></div> 
		            </div>      
	            <?php } ?>

	            <div class="view-details gradient_button"><i class='fa fa-plus-circle'></i> <?php _e("View Details", "listings"); ?> </div>
	            <div class="clearfix"></div>
	        </a>
	        <?php if(isset($youtube_id) && !empty($youtube_id)){ ?>
	        <div class="view-video gradient_button" data-youtube-id="<?php echo $youtube_id; ?>"><i class="fa fa-video-camera"></i> <?php _e("View Video", "listings"); ?></div>
	        <?php } ?>
	    </div>
	    
	<?php 
		
		if($layout == "boxed_fullwidth" || $layout == "boxed_left" || $layout == "boxed_right"){
			echo "</div>";
		}
		
		return ob_get_clean();
	}
}

function car_listing_container($layout){
	$return = array();
	
	if($layout == "boxed_fullwidth"){
		$return['start'] = '<div class="inventory_box car_listings boxed boxed_full">';
		$return['end']   = '</div>';
	} elseif($layout == "wide_fullwidth"){
		$return['start'] = '<div class="content-wrap car_listings row">';
		$return['end']   = '</div>';
	} elseif($layout == "boxed_left"){		
		$return['start'] = '<div class="car_listings boxed boxed_left col-md-9 col-lg-push-3 col-md-push-3">';
		$return['end']   = '</div>';
	} elseif($layout == "boxed_right"){
		$return['start'] = '<div class="car_listings boxed boxed_right col-md-9">';
		$return['end']   = '</div>';
	} elseif($layout == "wide_left"){
		$return['start'] = '<div class="inventory-wide-sidebar-left col-md-9  col-lg-push-3 col-md-push-3 car_listings"><div class="sidebar">';
		$return['end']   = '</div></div>';
	} elseif($layout == "wide_right"){
		$return['start'] = '<div class="inventory-wide-sidebar-right car_listings col-md-9 padding-right-15"><div class="sidebar">';
		$return['end']   = '</div></div>';
	} else {		
		$return['start'] = '<div class="inventory_box car_listings">';
		$return['end']   = '</div>';
	}
	
	return $return;
}

function listing_youtube_video(){
	return '<div id="youtube_video">
		<iframe width="560" height="315" src="" allowfullscreen style="width: 560px; height: 315px; border: 0;"></iframe>
	</div>';
}

function listing_template($layout, $is_ajax = false, $ajax_array = false){ 
	if($is_ajax == false) { ?>
		<div class="inner-page row">
			<?php
	}
	        global $lwp_options;
							
			$args     = ($is_ajax == false ? listing_args($_GET) : listing_args($_GET, false, $ajax_array));
	        $listings = get_posts($args[0]);
			
			if($is_ajax == false){
				listing_view($layout);
	        	listing_filter_sort();
			}
			
	        $container = car_listing_container($layout);
	        
	        echo "<div class='row generate_new'>" . $container['start'];
	        foreach($listings as $listing){
	            echo inventory_listing($listing->ID, $layout);
	        }
			echo "<div class=\"clearfix\"></div>";
	        echo $container['end'];
			
			if($layout == "boxed_left"){
				echo "<div class=\" col-md-3 col-sm-12 col-lg-pull-9 col-md-pull-9 left-sidebar side-content listing-sidebar\">";
				dynamic_sidebar("listing_sidebar");
				echo "</div>";
			} elseif($layout == "boxed_right"){
				echo "<div class=\"inventory-sidebar col-md-3 side-content listing-sidebar\">";
				dynamic_sidebar("listing_sidebar");
				echo "</div>";
			} elseif($layout == "wide_left"){
				echo "<div class=\" col-md-3 col-lg-pull-9 col-md-pull-9 left-sidebar side-content listing-sidebar\">";
				dynamic_sidebar("listing_sidebar");
				echo "</div>";
			} elseif($layout == "wide_right"){
				echo "<div class=\"inventory-sidebar col-md-3 side-content listing-sidebar\">";
				dynamic_sidebar("listing_sidebar");
				echo "</div>";
			}
			
			if($is_ajax == false){
				echo bottom_page_box($layout);
				echo "</div>"; 
			}
			
			echo "</div>"; 
    		echo listing_youtube_video();
}

function listing_view($layout){
	global $lwp_options;
	
	$listings = listing_args($_GET, true);
	$listings = count(query_posts($listings[0]));
	
	echo '<div class="listing-view margin-bottom-20">';
        echo '<div class="row">';
            echo '<div class="col-lg-8 col-md-6 col-sm-6 col-xs-12 padding-none"> <span class="ribbon"><strong><span class="number_of_listings">' . $listings . '</span> <span class="listings_grammar">' . ($listings == 1 ? __('Vehicle', 'listings') : __('Vehicles', 'listings')) . '</span> ' . __('Matching', 'listings') . ':</strong></span> <ul class="ribbon-item filter margin-bottom-none">';
			
			//check for filter vars
			$filters = "";
			$filterable = get_filterable_listing_categories();

			foreach($filterable as $filter){
				$get_var = str_replace(" ", "-", strtolower($filter['singular']));

				if(strtolower($filter['singular']) == "year"){
					$get_var = "yr";
				}
				
				if(isset($_GET[$get_var]) && !empty($_GET[$get_var]) && is_array($_GET[$get_var]) && isset($_GET[$get_var][0]) && !empty($_GET[$get_var][0]) && isset($_GET[$get_var][1]) && !empty($_GET[$get_var][1])){
					$min = $min_label = $_GET[$get_var][0];
					$max = $max_label = $_GET[$get_var][1];

					// currency 
					if(isset($filter['currency']) && !empty($filter['currency'])){
						$min_label = format_currency($min_label);
						$max_label = format_currency($max_label);
					}

					$filters .= (isset($_GET[$get_var]) && !empty($_GET[$get_var]) ? "<li data-type='" . $get_var . "[]' data-min='" . $min . "' data-max='" . $max . "'><a href=''><i class='fa fa-times-circle'></i> " . $filter['singular'] . ": <span> " . $min_label . " - " . $max_label . "</span></a></li>" : "");
				} elseif(isset($_GET[$get_var]) && !empty($_GET[$get_var]) && is_array($_GET[$get_var]) && isset($_GET[$get_var][0]) && !empty($_GET[$get_var][0]) && empty($_GET[$get_var][1])){
					$filters .= (isset($_GET[$get_var][0]) && !empty($_GET[$get_var][0]) ? "<li data-type='" . $get_var . "'><a href=''><i class='fa fa-times-circle'></i> " . $filter['singular'] . ": <span>" . ($filter['compare_value'] != "=" ? $filter['compare_value'] . " " : "") . get_category_correct_case($filter['singular'], $_GET[$get_var][0]) . "</span></a></li>" : "");
				} else {
					// year workaround, bad wordpress >:| ...
					$get_var  = (strtolower($filter['singular']) == "year" ? "yr" : $get_var);
					$filters .= (isset($_GET[$get_var]) && !empty($_GET[$get_var]) ? "<li data-type='" . $get_var . "'><a href=''><i class='fa fa-times-circle'></i> " . $filter['singular'] . ": <span>" . ($filter['compare_value'] != "=" ? $filter['compare_value'] . " " : "") . get_category_correct_case($filter['singular'], $_GET[$get_var]) . "</span></a></li>" : "");
				}
			}

			// additional categories
			if(!empty($lwp_options['additional_categories']) && !empty($lwp_options['additional_categories'])){
				foreach($lwp_options['additional_categories'] as $additional_category){
					$check_handle = str_replace(" ", "_", strtolower($additional_category));

					// in url
					if(isset($_GET[$check_handle]) && !empty($_GET[$check_handle])){
						$filters .= (isset($_GET[$check_handle]) && !empty($_GET[$check_handle]) ? "<li data-type='" . $check_handle . "'><a href=''><i class='fa fa-times-circle'></i> " . $additional_category . ": <span>" . __("Yes", "listings") . "</span></a></li>" : "");
					}
				}
			}

			// keyword
			if(isset($_GET['keywords']) && !empty($_GET['keywords'])){
				$filters .= "<li data-type='keywords'><a href=''><i class='fa fa-times-circle'></i> " . __("Keywords", "listings") . ": <span>" . sanitize_text_field($_GET['keywords']) . "</span></a></li>";
			}
			
			// if none set then show all listings
			echo (!empty($filters) ? $filters : "<li data-type='All' data-filter='All'>" . __("All Listings", "listings") . "</li>");
			
			echo '</ul></div>';
            echo '<div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 pull-right select_view padding-none">';
				if($lwp_options['inventory_listing_toggle'] == 1){
					echo ' <span class="align-right">' . __('Select View', 'listings') . ':</span><ul class="page-view nav nav-tabs">';
						
						$buttons = array("wide_fullwidth", "wide_left", "wide_right", "boxed_fullwidth", "boxed_left", "boxed_right");
					
						foreach($buttons as $button){
							echo "<li" . ($button == $layout ? " class='active'" : "") . " data-layout='" . $button . "'><a href=\"#\"><i class=\"fa\"></i></a></li>";
						}
					echo '</ul>';
				}
            echo '</div>';
        echo '</div>';
    echo '</div>';
}

// create new inventory listings for select view buttons
function generate_new_view(){
	$layout = $_POST['layout'];
	$page   = sanitize_text_field((isset($_POST['page']) && !empty($_POST['page']) ? $_POST['page'] : 1));
	$params = json_decode(stripslashes($_POST['params']), true);
	
	ob_start();
	listing_template($layout, true, $params);
	$html = ob_get_clean();

	echo json_encode(array(
		"html"        => $html,
	    "top_page"    => page_of_box($page),
	    "bottom_page" => bottom_page_box(false, $page),
	));

	die;
}
add_action("wp_ajax_generate_new_view", "generate_new_view");
add_action("wp_ajax_nopriv_generate_new_view", "generate_new_view");

function listing_dropdown_terms($name, $comparison = true, $encode_terms = false){
	$name   = str_replace(" ", "_", strtolower($name));
	$key    = get_single_listing_category($name);
	$return = "";

	if(!empty($key['terms'])){

		asort($key['terms']);

        foreach($key['terms'] as $key => $term){
			$on_select = $term;

            if(isset($key['currency']) && $key['currency'] == 1){
            	$on_select = format_currency($on_select);
            } 

            if(isset($key['compare_value']) && $key['compare_value'] != "=" && $comparison === true){
            	$on_select = $key['compare_value'] . " " . $on_select;
            }

            $check = (isset($_GET[str_replace(" ", "-", strtolower($key['singular']))]) && !empty($_GET[str_replace(" ", "-", strtolower($key['singular']))]) ? $_GET[str_replace(" ", "-", strtolower($key['singular']))] : "");

        	$return .= "<option value='" . ($encode_terms === true ? str_replace(" ", "-", strtolower($term)) : $term) . "'" . selected($check, str_replace(" ", "-", strtolower($term)), false ) . " data-key='" . $key . "'>" . $on_select . "</option>";
        }
    } else {
    	$return .= "<option>" . __("No options", "listings") . "</option>";
    }

    return $return;
}

function listing_dropdown_width($name){
	global $lwp_options;
	
	$name = str_replace(" ", "_", strtolower($name));
	
	return (isset($lwp_options[$name . '_width']) && !empty($lwp_options[$name . '_width']) ? $lwp_options[$name . '_width'] . "px" : "");
}

function listing_filter_sort(){ ?>
	
    <div class="clearfix"></div>
        <form method="post" action="#" class="listing_sort">
            <div class="select-wrapper listing_select clearfix margin-bottom-15">
            	<?php 				
				$filterable_categories = get_filterable_listing_categories();

				foreach($filterable_categories as $key){ 
					$meta    = str_replace("_", "-", strtolower($key['singular']));
					$text    = str_replace("_", " ", $key['plural']);
					$width   = listing_dropdown_width($key['singular']); ?>
                        <div class="my-dropdown <?php echo $meta; ?>-dropdown"<?php echo (!empty($width) ? " style='width: " . $width . "'" : ""); ?>>
                            <select name="<?php echo (strtolower($key['singular']) == "year" ? "yr" : str_replace(" ", "_", strtolower($key['singular']))); ?>" class="listing_filter" data-sort="<?php echo strtolower($key['singular']); ?>" tabindex="1" <?php echo ($key['compare_value'] != "=" ? " data-compare-value='" . $key['compare_value'] . "' " : ""); ?> <?php echo (isset($key['dependancy']) && !empty($key['dependancy']) ? " data-dependancy='" . $key['dependancy'] . "'" : ""); ?>>
                                
                            	<?php if(isset($key['dependancy']) && !empty($key['dependancy']) && strtolower($key['dependancy']) != "none"){ 
                            		echo "<option>" . __("Choose a", "listings") . " " . (str_replace("_", " ", $key['dependancy'])) . "</option>"; 
                            	} else { ?>
	                                <option value=""><?php _e("All", "listings"); ?> <?php echo ucwords($text); ?></option>
	                                <?php if(!empty($key['terms'])){

										asort($key['terms']);

										$singular = $key['singular'];
										
		                                foreach($key['terms'] as $key => $term){
											$on_select  = $term;

											$get_select = (strtolower($singular) == "year" ? "yr" : str_replace(" ", "-", strtolower($singular)));

											$get_value  = (isset($_GET[$get_select]) && !empty($_GET[$get_select]) ? $_GET[$get_select] : "");

											// dashes
											$get_value  = str_replace("--", "-", $get_value);

	                                        if(isset($key['currency']) && $key['currency'] == 1){
	                                        	$on_select = format_currency($on_select);
	                                        } 

	                                        if(isset($key['compare_value']) && $key['compare_value'] != "="){
	                                        	$on_select = $key['compare_value'] . " " . $on_select;
	                                        }

		                                	echo "<option value='" . $term . "'" . selected( $get_value, str_replace(" ", "-", strtolower($term)), false ) . " data-key='" . $key . "'>" . $on_select . "</option>";
		                                }
		                            } else {
		                            	echo "<option>" . __("No options", "listings") . "</option>";
		                            }
		                        }
                                ?>
                            </select>
                        </div>
				<?php } ?>
            </div>
            <div class="select-wrapper pagination clearfix margin-bottom-15">
                <div class="row">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12 sort-by-menu"> <span class="sort-by"><?php _e("Sort By", "listings"); ?>:</span>
                        <div class="my-dropdown price-ascending-dropdown">
                        	<?php 
                        	$order = (isset($_GET['order']) && !empty($_GET['order']) ? $_GET['order'] : ""); 
							$listing_orderby = listing_orderby(); ?>
                            <select name="price_order" class="listing_filter" tabindex="1" >
                                <option value=""><?php echo $listing_orderby['label']; ?></option>
                                <?php if(!empty($listing_orderby['key'])){ ?>
                                <option value="ASC" <?php echo selected($order, "asc"); ?>><?php _e("Ascending", "listings"); ?></option>
                                <option value="DESC" <?php echo selected($order, "desc"); ?>><?php _e("Descending", "listings"); ?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>
                    <?php $paged = (get_query_var('paged')) ? get_query_var('paged') : 1; 					
					global $lwp_options; ?>
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12 col-lg-offset-1">                        
                        <?php echo page_of_box(); ?>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 pull-right">
                        <ul class="form-links top_buttons">
                            <li><a href="#" class="gradient_button reset"><?php _e("Reset Filters", "listings"); ?></a></li>
                            <li><a href="#" class="gradient_button deselect"><?php _e("Deselect All", "listings"); ?></a></li>
                            <li><a href="#" class="gradient_button compare"><?php echo sprintf(__("Compare <span class='number_of_vehicles'>%s</span> Vehicles", "listings"), (isset($_COOKIE['compare_vehicles']) && !empty($_COOKIE['compare_vehicles']) ? count(explode(",", urldecode($_COOKIE['compare_vehicles']))) : 0)); ?></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </form>
    
<?php 
}

function listing_content(){
	global $post, $lwp_options;

	wp_enqueue_script( 'google-maps' );
	wp_enqueue_script( 'bxslider' );

	wp_enqueue_style( 'social-likes' );

	$post_meta       = get_post_meta_all($post->ID);
	$listing_options = unserialize(unserialize($post_meta['listing_options'])); 
	$location        = (isset($post_meta['location_map']) && !empty($post_meta['location_map']) ? unserialize($post_meta['location_map']) : ""); 
	$options         = unserialize(unserialize($post_meta['listing_options'])); 

	$gallery_images  = get_post_meta($post->ID, "gallery_images");
	$gallery_images  = $gallery_images[0]; 

	$multi_text      = "";
	$multi_pdf       = "";
	if(isset($post_meta['multi_options']) && !empty($post_meta['multi_options'])){
		$multi_options = unserialize($post_meta['multi_options']);
		
		foreach($multi_options as $option){
			$multi_text .= "<li><i class=\"fa-li fa fa-check\"></i> " . $option . "</li>";

			$multi_pdf  .= $option . ", ";
		}

		$multi_pdf = rtrim($multi_pdf, ", ");
	} else {
		$text = __("There are no features available", "listings");

		$multi_text .= "<li>" . $text . "</li>";
		$multi_pdf  .= $text;
	}
	?>

	<div class="inner-page inventory-listing">
        <div class="inventory-heading margin-bottom-10 clearfix">
            <div class="row">
                <div class="col-lg-10 col-md-10 col-sm-10 col-xs-12">
                    <h2><?php the_title(); ?></h2>
                    <?php echo (isset($post_meta['secondary_title']) && !empty($post_meta['secondary_title']) ? "<span class='margin-top-10'>" . $post_meta['secondary_title'] . "</span>" : ""); ?>
                </div>
                <div class="col-lg-2 col-md-2 col-sm-2 text-right">
                	<?php 
                	if(isset($listing_options['price']['value']) && !empty($listing_options['price']['value'])){ 
                		$original = (isset($listing_options['price']['original']) && !empty($listing_options['price']['original']) ? $listing_options['price']['original'] : "");

                		echo (!empty($original) ? "<h2 class='strikeout original_price'>" . format_currency($original) . "</h2>" : "");

	                    echo '<h2>' . format_currency($listing_options['price']['value']) . '</h2>';
	                    echo '<em>' . __("Plus Taxes &amp; Licensing", "listings") . '</em>'; 
                    } ?>
                </div>
            </div>
        </div>
        <div class="content-nav margin-bottom-30">
            <ul>
            	<?php $next_link = (get_permalink(get_adjacent_post(false,'',false)) == get_permalink() ? "#" : get_permalink(get_adjacent_post(false,'',false)));
					  $prev_link = (get_permalink(get_adjacent_post(false,'',true)) == get_permalink() ? "#" : get_permalink(get_adjacent_post(false,'',true))); ?>


                <?php if(isset($lwp_options['previous_vehicle_show']) && !empty($lwp_options['previous_vehicle_show']) && $lwp_options['previous_vehicle_show'] == 1){ ?>                
                	<li class="prev1 gradient_button"><a href="<?php echo $prev_link; ?>"><?php _e("Prev Vehicle", "listings"); ?></a></li>
                <?php } ?>
                
                <?php if(isset($lwp_options['request_more_show']) && !empty($lwp_options['request_more_show']) && $lwp_options['request_more_show'] == 1){ ?>
                	<li class="request gradient_button"><a href="#request_fancybox_form" class="fancybox_div"><?php _e("Request More Info", "listings"); ?></a></li>
                <?php } ?>
                
                <?php if(isset($lwp_options['schedule_test_show']) && !empty($lwp_options['schedule_test_show']) && $lwp_options['schedule_test_show'] == 1){ ?>
                	<li class="schedule gradient_button"><a href="#schedule_fancybox_form" class="fancybox_div"><?php _e("Schedule Test Drive", "listings"); ?></a></li>
                <?php } ?>
                
                <?php if(isset($lwp_options['make_offer_show']) && !empty($lwp_options['make_offer_show']) && $lwp_options['make_offer_show'] == 1){ ?>
                	<li class="offer gradient_button"><a href="#offer_fancybox_form" class="fancybox_div"><?php _e("Make an Offer", "listings"); ?></a></li>
                <?php } ?>
                
                <?php if(isset($lwp_options['tradein_show']) && !empty($lwp_options['tradein_show']) && $lwp_options['tradein_show'] == 1){ ?>
                	<li class="trade gradient_button"><a href="#trade_fancybox_form" class="fancybox_div"><?php _e("Trade-In Appraisal", "listings"); ?></a></li>
                <?php } ?>
                
                <?php if(isset($lwp_options['pdf_brochure_show']) && !empty($lwp_options['pdf_brochure_show']) && $lwp_options['pdf_brochure_show'] == 1){ ?>
                	<li class="pdf gradient_button"><a href="" class="generate_pdf"><?php _e("PDF Brochure", "listings"); ?></a></li>
                <?php } ?>
                
                <?php if(isset($lwp_options['print_vehicle_show']) && !empty($lwp_options['print_vehicle_show']) && $lwp_options['print_vehicle_show'] == 1){ ?>
                	<li class="print gradient_button"><a class="print_page"><?php _e("Print This Vehicle", "listings"); ?></a></li>
                <?php } ?>
                
                <?php if(isset($lwp_options['email_friend_show']) && !empty($lwp_options['email_friend_show']) && $lwp_options['email_friend_show'] == 1){ ?>                
                	<li class="email gradient_button"><a href="#email_fancybox_form" class="fancybox_div"><?php _e("Email to a Friend", "listings"); ?></a></li>
                <?php } ?>
                
                <?php if(isset($lwp_options['next_vehicle_show']) && !empty($lwp_options['next_vehicle_show']) && $lwp_options['next_vehicle_show'] == 1){ ?>
                	<li class="next1 gradient_button"><a href="<?php echo $next_link; ?>"><?php _e("Next Vehicle", "listings"); ?></a></li>
                <?php } ?>
                
            </ul> 
        </div>
        <div class="row">
            <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12 left-content padding-left-none"> 
                <!--OPEN OF SLIDER-->
				<?php 
                if(!empty($gallery_images)){	
					$full_images  = "";
					$thumb_images = "";
					
					foreach($gallery_images as $gallery_image){
						$gallery_thumb  = auto_image($gallery_image, "auto_thumb", true);
						$gallery_slider = auto_image($gallery_image, "auto_slider", true);
						$full 			= wp_get_attachment_image_src($gallery_image, "full");
						$full 			= $full[0];

						$full_images  .= "<li data-thumb=\"" . $gallery_thumb . "\"> <img src=\"" . $gallery_slider . "\" alt=\"\" data-full-image=\"" . $full . "\" /> </li>\n";
						$thumb_images .= "<li data-thumb=\"" . $gallery_thumb . "\"> <a href=\"#\"><img src=\"" . $gallery_thumb . "\" alt=\"\" /></a> </li>\n";
					}
                } ?>
                <div class="listing-slider">
                    <section class="slider home-banner">
                        <div class="flexslider loading" id="home-slider-canvas">
                            <ul class="slides">
                            	<?php echo (!empty($full_images) ? $full_images : ""); ?>
                            </ul>
                        </div>
                    </section>
                    <section class="home-slider-thumbs"> 
                        <div class="flexslider" id="home-slider-thumbs">
                            <ul class="slides">
                            	<?php echo (!empty($thumb_images) ? $thumb_images : ""); ?>
                            </ul>
                        </div>
                    </section>
                </div>
                <!--CLOSE OF SLIDER--> 
                <!--Slider End-->
                <div class="clearfix"></div>
                <div class="bs-example bs-example-tabs example-tabs margin-top-50">
                    <ul id="myTab" class="nav nav-tabs">
                    	<?php 
                    	$first_tab 	= (isset($lwp_options['first_tab']) && !empty($lwp_options['first_tab']) ? $lwp_options['first_tab'] : "" );
                    	$second_tab = (isset($lwp_options['second_tab']) && !empty($lwp_options['second_tab']) ? $lwp_options['second_tab'] : "" );
                    	$third_tab 	= (isset($lwp_options['third_tab']) && !empty($lwp_options['third_tab']) ? $lwp_options['third_tab'] : "" );
                    	$fourth_tab = (isset($lwp_options['fourth_tab']) && !empty($lwp_options['fourth_tab']) ? $lwp_options['fourth_tab'] : "" );
                    	$fifth_tab 	= (isset($lwp_options['fifth_tab']) && !empty($lwp_options['fifth_tab']) ? $lwp_options['fifth_tab'] : "" ); ?>

                        <?php echo (!empty($first_tab) ? '<li class="active"><a href="#vehicle" data-toggle="tab">' . $first_tab . '</a></li>' : ''); ?>
                        <?php echo (!empty($second_tab) ? '<li><a href="#features" data-toggle="tab">' . $second_tab . '</a></li>' : ''); ?>
                        <?php echo (!empty($third_tab) ? '<li><a href="#technical" data-toggle="tab">' . $third_tab . '</a></li>' : ''); ?>
                        <?php echo (!empty($fourth_tab) ? '<li><a href="#location" data-toggle="tab">' . $fourth_tab . '</a></li>' : ''); ?>
                        <?php echo (!empty($fifth_tab) ? '<li><a href="#comments" data-toggle="tab">' . $fifth_tab . '</a></li>' : ''); ?>
                    </ul>
                    <div id="myTabContent" class="tab-content margin-top-15 margin-bottom-20">
                        <div class="tab-pane fade in active" id="vehicle">                                    
                                <?php the_content(); ?>
                        </div>
                        <div class="tab-pane fade" id="features">
                            <ul class="fa-ul" data-list="<?php echo $multi_pdf; ?>">
                            	<?php echo $multi_text; ?>
                            </ul>
                        </div>
                        <div class="tab-pane fade" id="technical">
                        	<?php echo wpautop($post_meta['technical_specifications']); ?>
                        </div>
                        <div class="tab-pane fade" id="location">
                        	<?php 
							$latitude  = (isset($location['latitude']) && !empty($location['latitude']) ? $location['latitude'] : "");
							$longitude = (isset($location['longitude']) && !empty($location['longitude']) ? $location['longitude'] : "");
							$zoom      = (isset($location['zoom']) && !empty($location['zoom']) ? $location['zoom'] : 11);
							
							if(!empty($latitude) && !empty($longitude)){ ?>
                            	<div id='google-map-listing' class="contact" data-longitude='<?php echo $longitude; ?>' data-latitude='<?php echo $latitude; ?>' data-zoom='<?php echo $zoom; ?>' data-scroll="false" style="height: 350px;" data-parallax="false"></div>
                            <?php } else { ?>
                            	<?php _e("No location available", "listings"); ?>
                            <?php } ?>
                        </div>
                        <div class="tab-pane fade" id="comments">
                            <p><?php echo wpautop($post_meta['other_comments']); ?></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4 right-content padding-right-none">
                <div class="side-content margin-bottom-50">
                    <div class="car-info margin-bottom-50">
                        <div class="table-responsive">
                            <table class="table">
                                <tbody>
                                	<?php 
                                    $listing_categories = get_listing_categories();

                                    foreach($listing_categories as $category){
                                        $safe_handle = str_replace(" ", "_", strtolower($category['singular']));
                                        $value       = (isset($post_meta[$safe_handle]) && !empty($post_meta[$safe_handle]) ? $post_meta[$safe_handle] : "");

                                        if(empty($post_meta[$safe_handle]) && isset($category['compare_value']) && $category['compare_value'] != "="){
											$post_meta[$safe_handle] = 0;
										} elseif(empty($post_meta[$safe_handle])) {
											$post_meta[$safe_handle] = __("None", "listings");
										}

                                        // price 
                                        if(isset($category['currency']) && $category['currency'] == 1){
                                        	$value = format_currency($value);
                                        }

                                        echo "<tr><td>" . $category['singular'] . ": </td><td>" . $value . "</td></tr>";
                                    } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <?php if(isset($lwp_options['fuel_efficiency_show']) && $lwp_options['fuel_efficiency_show'] == 1){ ?>
                    <div class="efficiency-rating text-center padding-vertical-15 margin-bottom-40">
                        <h3><?php _e("Fuel Efficiency Rating", "listings"); ?></h3>
                        <ul>
                        	<?php $fuel_icon = (isset($lwp_options['fuel_efficiency_image']) && !empty($lwp_options['fuel_efficiency_image']) ? $lwp_options['fuel_efficiency_image']['url'] : ICON_DIR . "fuel_pump.png"); ?>
                            <li class="city_mpg"><small><?php echo (isset($listing_options['city_mpg']['text']) && !empty($listing_options['city_mpg']['text']) ? $listing_options['city_mpg']['text'] : ""); ?>:</small> <strong><?php echo (isset($listing_options['city_mpg']['value']) && !empty($listing_options['city_mpg']['value']) ? $listing_options['city_mpg']['value'] : __("N/A", "listings")); ?></strong></li>
                            <li class="fuel"><img src="<?php echo $fuel_icon; ?>" alt="" class="aligncenter"></li>
                            <li class="hwy_mpg"><small><?php echo (isset($listing_options['highway_mpg']['text']) && !empty($listing_options['highway_mpg']['text']) ? $listing_options['highway_mpg']['text'] : ""); ?>:</small> <strong><?php echo (isset($listing_options['highway_mpg']['value']) && !empty($listing_options['highway_mpg']['value']) ? $listing_options['highway_mpg']['value'] : __("N/A", "listings")); ?></strong></li>
                        </ul>
                        <p><?php echo (isset($lwp_options['fuel_efficiency_text']) ? $lwp_options['fuel_efficiency_text'] : ""); ?></p>
                    </div>
                    <?php } ?>
                    
                    <?php if(isset($lwp_options['social_icons_show']) && $lwp_options['social_icons_show'] == 1){ ?>
                    <ul class="social-likes pull-right listing_share" data-url="<?php echo get_permalink(); ?>" data-title="<?php the_title(); ?>">
                        <li class="facebook" title="<?php _e("Share link on Facebook", "listings"); ?>"></li>
                        <li class="plusone" title="<?php _e("Share link on Google+", "listings"); ?>"></li>
                        <li class="pinterest" title="<?php _e("Share image on Pinterest", "listings"); ?>"></li>
                        <li class="twitter" title="<?php _e("Share link on Twitter", "listings"); ?>"></li>
                    </ul>
                    <?php } ?>
                    
                    <div class="clearfix"></div>
                    <?php if(isset($lwp_options['calculator_show']) && $lwp_options['calculator_show'] == 1){ 
						if( class_exists("Loan_Calculator") ){
							the_widget("Loan_Calculator", array("rate" => $lwp_options['calculator_rate'], "price" => $listing_options['price']['value']), array('before_widget' => '<div class="widget loan_calculator margin-top-40">', 'before_title' => '<h3 class="side-widget-title margin-bottom-25">', 'after_title' => '</h3>')); 
						}
					} ?>
                </div>
                    
                <div class="clearfix"></div>
            </div>
        <div class="clearfix"></div>

        <?php if(isset($lwp_options['recent_vehicles_show']) && $lwp_options['recent_vehicles_show'] == 1){
            	echo vehicle_scroller(__("Recent Vehicles", "listings"), __("Browse through the vast selection of vehicles that have recently been added to our inventory.", "listings"), "newest");
            } ?>
        </div>
    </div>

<div id="email_fancybox_form" class="fancybox_form">
	<?php if(!isset($lwp_options['email_friend_form_shortcode']) || empty($lwp_options['email_friend_form_shortcode'])){ ?>
    <h3><?php _e("Email to a Friend", "listings"); ?></h3>

    <form name="email_friend" method="post" class="ajax_form">
        <table>
            <tr><td><?php _e("Name", "listings"); ?>: </td> <td> <input type="text" name="name"></td></tr>
            <tr><td><?php _e("Email", "listings"); ?>: </td> <td> <input type="text" name="email"></td></tr>
            <tr><td><?php _e("Friends Email", "listings"); ?>: </td> <td> <input type="text" name="friends_email"></td></tr>
            <tr><td colspan="2"><?php _e("Message", "listings"); ?>:<br>
                <textarea name="message" class="fancybox_textarea"></textarea></td></tr>
            <?php                
            if($lwp_options['recaptcha_enabled'] == 1){			
                echo "<tr><td colspan='2'>" . __("reCAPTCHA", "listings") . ": <br><div id='email_fancybox_form_recaptcha' class='recaptcha_holder'></div></td></tr>";
            } ?>
            <tr><td colspan="2"><input type="submit" value="<?php _e("Submit", "listings"); ?>"></td></tr>
        </table>
    </form>
	<?php } else {
		echo do_shortcode($lwp_options['email_friend_form_shortcode']);
	} ?>
</div>

<div id="trade_fancybox_form" class="fancybox_form">
	<?php if(!isset($lwp_options['tradein_form_shortcode']) || empty($lwp_options['tradein_form_shortcode'])){ ?>
		<h3><?php _e("Trade-In", "listings"); ?></h3>

        <form name="trade_in" method="post" class="ajax_form">
            <table class="left_table">
                <tr>
                    <td colspan="2"><h4><?php _e("Contact Information", "listings"); ?></h4></td>
                </tr>
                <tr>
                    <td><?php _e("First Name", "listings"); ?><br><input type="text" name="first_name"></td>
                    <td><?php _e("Last Name", "listings"); ?><br><input type="text" name="last_name"></td>
                </tr>
                <tr>
                    <td><?php _e("Work Phone", "listings"); ?><br><input type="text" name="work_phone"></td>
                    <td><?php _e("Phone", "listings"); ?><br><input type="text" name="phone"></td>
                </tr>
                <tr>
                    <td><?php _e("Email", "listings"); ?><br><input type="text" name="email"></td>
                    <td><?php _e("Preferred Contact", "listings"); ?><br>  <input type="radio" name="contact_method" value="email" id="email"> <label for="email"><?php _e("Email", "listings"); ?></label>  <input type="radio" name="contact_method" value="phone" id="phone"> <label for="phone"><?php _e("Phone", "listings"); ?></label> </td>
                </tr>
                <tr>
                    <td colspan="2"><?php _e("Comments", "listings"); ?><br><textarea name="comments" style="width: 89%;" rows="5"></textarea></td>
                </tr>
            </table>
            
            <table class="right_table">
                <tr>
                    <td colspan="2"><h4><?php _e("Options", "listings"); ?></h4></td>
                </tr>

                <?php

                $options    = get_single_listing_category("options");
                $options    = $options['terms'];

                ?>
                <tr>
                	<td><select name="options" multiple style="height: 200px;"> 
	                	<?php
						
						if(empty($options)){
							echo "<option value='" . __("Not availiable", "listings") . "'>N/A</option>";
						} else {
							foreach($options as $option){
								echo "<option value='" . $option . "'>" . $option . "</option>";
							}
						}
						
						?>
					</select></td>

        		</tr>
            </table>
            
            <div style="clear:both;"></div>
            
            <table class="left_table">    
                <tr><td colspan="2"><h4><?php _e("Vehicle Information", "listings"); ?></h4></td></tr>
                
                <tr>
                    <td><?php _e("Year", "listings"); ?><br><input type="text" name="year"></td>
                    <td><?php _e("Make", "listings"); ?><br><input type="text" name="make"></td>
                </tr>
                <tr>
                    <td><?php _e("Model", "listings"); ?><br><input type="text" name="model"></td>
                    <td><?php _e("Exterior Colour", "listings"); ?><br><input type="text" name="exterior_colour"></td>
                </tr>
                <tr>
                    <td><?php _e("VIN", "listings"); ?><br><input type="text" name="vin"></td>
                    <td><?php _e("Kilometres", "listings"); ?><br><input type="text" name="kilometres"></td>
                </tr>
                <tr>
                    <td><?php _e("Engine", "listings"); ?><br><input type="text" name="engine"></td>
                    <td><?php _e("Doors", "listings"); ?><br><select name="doors" class="css-dropdowns"><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option></select></td>
                </tr>
                <tr>
                    <td><?php _e("Transmission", "listings"); ?><br><select name="transmission" class="css-dropdowns"><option value="Automatic"><?php _e("Automatic", "listings"); ?></option><option value="Manual"><?php _e("Manual", "listings"); ?></option></select></td>
                    <td><?php _e("Drivetrain", "listings"); ?><br><select name="drivetrain" class="css-dropdowns"><option value="2WD"><?php _e("2WD", "listings"); ?></option><option value="4WD"><?php _e("4WD", "listings"); ?></option><option value="AWD"><?php _e("AWD", "listings"); ?></option></select></td>
                </tr>
            
            </table>
               
            <table class="right_table">
                <tr><td colspan="2"><h4><?php _e("Vehicle Rating", "listings"); ?></h4></td></tr>
                
                <tr>
                    <td><?php _e("Body (dents, dings, rust, rot, damage)", "listings"); ?><br><select name="body_rating" class="css-dropdowns"><option value="10">10 - <?php _e("best", "listings"); ?></option><option value="9">9</option><option value="8">8</option><option value="7">7</option><option value="6">6</option><option value="5">5</option><option value="4">4</option><option value="3">3</option><option value="2">2</option><option value="1">1 - <?php _e("worst", "listings"); ?></option></select></td>
                    <td><?php _e("Tires (tread wear, mismatched)", "listings"); ?><br><select name="tire_rating" class="css-dropdowns"><option value="10">10 - <?php _e("best", "listings"); ?></option><option value="9">9</option><option value="8">8</option><option value="7">7</option><option value="6">6</option><option value="5">5</option><option value="4">4</option><option value="3">3</option><option value="2">2</option><option value="1">1 - <?php _e("worst", "listings"); ?></option></select></td>
                </tr>
                <tr>
                    <td><?php _e("Engine (running condition, burns oil, knocking)", "listings"); ?><br><select name="engine_rating" class="css-dropdowns"><option value="10">10 - <?php _e("best", "listings"); ?></option><option value="9">9</option><option value="8">8</option><option value="7">7</option><option value="6">6</option><option value="5">5</option><option value="4">4</option><option value="3">3</option><option value="2">2</option><option value="1">1 - <?php _e("worst", "listings"); ?></option></select></td>
                    <td><?php _e("Transmission / Clutch (slipping, hard shift, grinds)", "listings"); ?><br><select name="transmission_rating" class="css-dropdowns"><option value="10">10 - <?php _e("best", "listings"); ?></option><option value="9">9</option><option value="8">8</option><option value="7">7</option><option value="6">6</option><option value="5">5</option><option value="4">4</option><option value="3">3</option><option value="2">2</option><option value="1">1 - <?php _e("worst", "listings"); ?></option></select></td>
                </tr>
                <tr>
                    <td><?php _e("Glass (chips, scratches, cracks, pitted)", "listings"); ?><br><select name="glass_rating" class="css-dropdowns"><option value="10">10 - <?php _e("best", "listings"); ?></option><option value="9">9</option><option value="8">8</option><option value="7">7</option><option value="6">6</option><option value="5">5</option><option value="4">4</option><option value="3">3</option><option value="2">2</option><option value="1">1 - worst</option></select></td>
                    <td><?php _e("Interior (rips, tears, burns, faded/worn, stains)", "listings"); ?><br><select name="interior_rating" class="css-dropdowns"><option value="10">10 - <?php _e("best", "listings"); ?></option><option value="9">9</option><option value="8">8</option><option value="7">7</option><option value="6">6</option><option value="5">5</option><option value="4">4</option><option value="3">3</option><option value="2">2</option><option value="1">1 - <?php _e("worst", "listings"); ?></option></select></td>
                </tr>
                <tr>
                    <td colspan="2"><?php _e("Exhaust (rusted, leaking, noisy)", "listings"); ?><br><select name="exhaust_rating" class="css-dropdowns"><option value="10">10 - <?php _e("best", "listings"); ?></option><option value="9">9</option><option value="8">8</option><option value="7">7</option><option value="6">6</option><option value="5">5</option><option value="4">4</option><option value="3">3</option><option value="2">2</option><option value="1">1 - <?php _e("worst", "listings"); ?></option></select></td>
                </tr>
            </table>
            
            <div style="clear:both;"></div>
            
            <table class="left_table">
                <tr><td><h4><?php _e("Vehicle History", "listings"); ?></h4></td></tr>
                
                <tr>
                    <td><?php _e("Was it ever a lease or rental return?", "listings"); ?> <br><select name="rental_return" class="css-dropdowns"><option value="Yes"><?php _e("Yes", "listings"); ?></option><option value="No"><?php _e("No", "listings"); ?></option></select></td>
                </tr>
                <tr>
                    <td><?php _e("Is the odometer operational and accurate?", "listings"); ?> <br><select name="odometer_accurate" class="css-dropdowns"><option value="Yes"><?php _e("Yes", "listings"); ?></option><option value="No"><?php _e("No", "listings"); ?></option></select></td>
                </tr>
                <tr>
                    <td><?php _e("Detailed service records available?", "listings"); ?> <br><select name="service_records" class="css-dropdowns"><option value="Yes"><?php _e("Yes", "listings"); ?></option><option value="No"><?php _e("No", "listings"); ?></option></select></td>
                </tr>
            </table>
            
            <table class="right_table">
                <tr>
                    <td><h4><?php _e("Title History", "listings"); ?></h4></td>
                </tr>
                
                <tr>
                    <td><?php _e("Is there a lienholder?", "listings"); ?> <br><input type="text" name="lienholder"></td>
                </tr>
                <tr>
                    <td><?php _e("Who holds this title?", "listings"); ?> <br><input type="text" name="titleholder"></td>
                </tr>
            </table>
            
            <div style="clear:both;"></div>
                   
            <table style="width: 100%;">
                <tr><td colspan="2"><h4><?php _e("Vehicle Assessment", "listings"); ?></h4></td></tr>
                
                <tr>
                    <td><?php _e("Does all equipment and accessories work correctly?", "listings"); ?><br><textarea name="equipment" rows="5" style="width: 89%;"></textarea></td>
                    <td><?php _e("Did you buy the vehicle new?", "listings"); ?><br><textarea name="vehiclenew" rows="5" style="width: 89%;"></textarea></td>
                </tr>
                <tr>
                    <td><?php _e("Has the vehicle ever been in any accidents? Cost of repairs?", "listings"); ?><br><textarea name="accidents" rows="5" style="width: 89%;"></textarea></td>
                    <td><?php _e("Is there existing damage on the vehicle? Where?", "listings"); ?><br><textarea name="damage" rows="5" style="width: 89%;"></textarea></td>
                </tr>
                <tr>
                    <td><?php _e("Has the vehicle ever had paint work performed?", "listings"); ?><br><textarea name="paint" rows="5" style="width: 89%;"></textarea></td>
                    <td><?php _e("Is the title designated 'Salvage' or 'Reconstructed'? Any other?", "listings"); ?><br><textarea name="salvage" rows="5" style="width: 89%;"></textarea></td>
                </tr>
                <?php
                
                if($lwp_options['recaptcha_enabled'] == 1){			
                    echo "<tr><td colspan='2'>" . __("reCAPTCHA", "listings") . ": <br><div id='trade_fancybox_form_recaptcha' class='recaptcha_holder'></div></td></tr>";
                }
                
                ?>
                <tr><td colspan="2"><input type="submit" value="<?php _e("Submit", "listings"); ?>"></td></tr>
            </table>
                
        </form>
	<?php } else {
		echo do_shortcode($lwp_options['tradein_form_shortcode']);
	} ?>
</div>

<div id="offer_fancybox_form" class="fancybox_form">
	<?php if(!isset($lwp_options['make_offer_form_shortcode']) || empty($lwp_options['make_offer_form_shortcode'])){ ?>
		<h3><?php _e("Make an Offer", "listings"); ?></h3>

        <form name="make_offer" method="post" class="ajax_form">
            <table>
                <tr><td><?php _e("Name", "listings"); ?>: </td> <td> <input type="text" name="name"></td></tr>
                <tr><td><?php _e("Preferred Contact", "listings"); ?>:</td> <td> <input type="radio" name="contact_method" value="email" id="offer_email"><label for="offer_email"><?php _e("Email", "listings"); ?></label>  <input type="radio" name="contact_method" value="phone" id="offer_phone"> <label for="offer_phone"><?php _e("Phone", "listings"); ?></label></td></tr>
                <tr><td><?php _e("Email", "listings"); ?>: </td> <td> <input type="text" name="email"></td></tr>
                <tr><td><?php _e("Phone", "listings"); ?>: </td> <td> <input type="text" name="phone"></td></tr>
                <tr><td><?php _e("Offered Price", "listings"); ?>: </td> <td> <input type="text" name="offered_price"></td></tr>
                <tr><td><?php _e("Financing Required", "listings"); ?>: </td> <td> <select name="financing_required" class="css-dropdowns"><option value="yes"><?php _e("Yes", "listings"); ?></option><option value="no"><?php _e("No", "listings"); ?></option></select></td></tr>
                <tr><td colspan="2"><?php _e("Other Comments/Conditions", "listings"); ?>:<br>
                        <textarea name="other_comments" class="fancybox_textarea"></textarea></td></tr>
                <?php
                
                if($lwp_options['recaptcha_enabled'] == 1){			
                    echo "<tr><td colspan='2'>" . __("reCAPTCHA", "listings") . ": <br><div id='offer_fancybox_form_recaptcha' class='recaptcha_holder'></div></td></tr>";
                }
                
                ?>
                <tr><td colspan="2"><input type="submit" value="<?php _e("Submit", "listings"); ?>"></td></tr>
            </table>
        </form>
	<?php } else {
		echo do_shortcode($lwp_options['make_offer_form_shortcode']);
	} ?>
</div>

<div id="schedule_fancybox_form" class="fancybox_form">
	<?php if(!isset($lwp_options['schedule_test_drive_form_shortcode']) || empty($lwp_options['schedule_test_drive_form_shortcode'])){ ?>
		<h3><?php _e("Schedule Test Drive", "listings"); ?></h3>

        <form name="schedule" method="post" class="ajax_form">
            <table>
                <tr><td><?php _e("Name", "listings"); ?>: </td> <td> <input type="text" name="name"></td></tr>
                <tr><td><?php _e("Preferred Contact", "listings"); ?>:</td> <td> <input type="radio" name="contact_method" value="email" id="schedule_email"><label for="schedule_email"><?php _e("Email", "listings"); ?></label>  <input type="radio" name="contact_method" value="phone" id="schedule_phone"> <label for="schedule_phone"><?php _e("Phone", "listings"); ?></label></td></tr>
                <tr><td><?php _e("Email", "listings"); ?>: </td> <td> <input type="text" name="email"></td></tr>
                <tr><td><?php _e("Phone", "listings"); ?>: </td> <td> <input type="text" name="phone"></td></tr>
                <tr><td><?php _e("Best Day", "listings"); ?>: </td> <td> <input type="text" name="best_day"></td></tr>
                <tr><td><?php _e("Best Time", "listings"); ?>: </td> <td> <input type="text" name="best_time"></td></tr>
                <?php
                
                if($lwp_options['recaptcha_enabled'] == 1){			
                    echo "<tr><td colspan='2'>" . __("reCAPTCHA", "listings") . ": <br><div id='schedule_fancybox_form_recaptcha' class='recaptcha_holder'></div></td></tr>";
                }
                
                ?>
                <tr><td colspan="2"><input type="submit" value="<?php _e("Submit", "listings"); ?>"></td></tr>
            </table>
        </form>
	<?php } else {
		echo do_shortcode($lwp_options['schedule_test_drive_form_shortcode']);
	} ?>
</div>

<div id="request_fancybox_form" class="fancybox_form">
	<?php if(!isset($lwp_options['request_info_form_shortcode']) || empty($lwp_options['request_info_form_shortcode'])){ ?>
		<h3><?php _e("Request More Info", "listings"); ?></h3>

        <form name="request_info" method="post" class="ajax_form">
            <table>
                <tr><td><?php _e("Name", "listings"); ?>: </td> <td> <input type="text" name="name"></td></tr>
                <tr><td><?php _e("Preferred Contact", "listings"); ?>:</td> <td> <input type="radio" name="contact_method" value="email" id="request_more_email"><label for="request_more_email"><?php _e("Email", "listings"); ?></label>  <input type="radio" name="contact_method" value="phone" id="request_more_phone"> <label for="request_more_phone"><?php _e("Phone", "listings"); ?></label></td></tr>
                <tr><td><?php _e("Email", "listings"); ?>: </td> <td> <input type="text" name="email"></td></tr>
                <tr><td><?php _e("Phone", "listings"); ?>: </td> <td> <input type="text" name="phone"></td></tr>
                <?php
                
                if($lwp_options['recaptcha_enabled'] == 1){			
                    echo "<tr><td colspan='2'>" . __("reCAPTCHA", "listings") . ": <br><div id='request_fancybox_form_recaptcha' class='recaptcha_holder'></div></td></tr>";
                }
                
                ?>
                <tr><td colspan="2"><input type="submit" value="<?php _e("Submit", "listings"); ?>"></td></tr>
            </table>
        </form>
	<?php } else {
		echo do_shortcode($lwp_options['request_info_form_shortcode']);
	} ?>
</div> <?php
}


function listing_orderby(){
	$orderby = get_option("listing_orderby");

	if(isset($orderby) && !empty($orderby)){
		$category = get_single_listing_category($orderby[0]);

		$settings = array(
			"label" => $category['singular'],
			"key"   => $orderby[0],
			"type"  => $orderby[1]
		);

	 	return $settings;	
	} else {
		return array("label" => __("Configure in listing categories", "listings"), "key" => "", "type" => "");
	}
}

//********************************************
//	Generate Listing Args
//***********************************************************
function listing_args($get_or_post, $all = false, $ajax_array = false){
	global $lwp_options, $post;
	
	if(is_array($ajax_array)){
		$get_or_post = $ajax_array;
	}
	
	$paged      = (isset($_POST['page']) && !empty($_POST['page']) ? $_POST['page'] : (isset($_POST['paged']) && !empty($_POST['paged']) ? $_POST['paged'] : ""));
	$lwp_options['listings_amount'] = (isset($lwp_options['listings_amount']) && !empty($lwp_options['listings_amount']) ? $lwp_options['listings_amount'] : "");
	$sort_items = array();

	// order by
	$orderby = listing_orderby();
	
	$args = array(
			  'post_type' 	   => 'listings',
			  'meta_query'	   => array(),
			  'paged'      	   => (isset($paged) && !empty($paged) ? $paged : get_query_var('paged')),
			  'posts_per_page' => ($all == true ? -1 : $lwp_options['listings_amount']),
			  'order'          => (isset($get_or_post['order']) && !empty($get_or_post['order']) ? $get_or_post['order'] : "ASC"),
			);

	if(isset($orderby) && !empty($orderby)){
		$args['meta_key'] = $orderby['key'];
		$args['orderby']  = $orderby['type'];
	}

	// keywords
	if(isset($get_or_post['keywords']) && !empty($get_or_post['keywords'])){
		$args['s'] = sanitize_text_field($get_or_post['keywords']);
	}
			
	$data = array();
	
	$filterable_categories = get_filterable_listing_categories();

	foreach($filterable_categories as $filter){
		$singular = str_replace(" ", "_", strtolower($filter['singular']));

		$get_singular = str_replace(" ", "-", strtolower($filter['singular']));


		// year workaround, bad wordpress >:| ...
		if(strtolower($filter['singular']) == "year" && isset($get_or_post["yr"]) && !empty($get_or_post["yr"])){
			$get_singular = "yr";
		} elseif(strtolower($filter['singular']) == "year" && isset($get_or_post["year"]) && !empty($get_or_post["year"])){
			$get_singular = "year";
		}


		if(isset($get_or_post[$get_singular]) && !empty($get_or_post[$get_singular])){
			// min max values
			if(is_array($get_or_post[$get_singular]) && isset($get_or_post[$get_singular][0]) && !empty($get_or_post[$get_singular][0]) && isset($get_or_post[$get_singular][1]) && !empty($get_or_post[$get_singular][1])){
				$min = $get_or_post[$get_singular][0];
				$max = $get_or_post[$get_singular][1];


				$data[] = array(
					'key'     => str_replace(" ", "_", strtolower($filter['singular'])),
					'value'   => array($min, $max),
					'type'    => 'numeric',
					'compare' => 'BETWEEN'
				);
			} elseif(is_array($get_or_post[$get_singular]) && isset($get_or_post[$get_singular][0]) && !empty($get_or_post[$get_singular][0]) && empty($get_or_post[$get_singular][1])){

				// if one value of min and max
				$value        = str_replace("--", "-", $get_or_post[$get_singular][0]);
				$value        = str_replace("-", " ", $get_or_post[$get_singular][0]);
				$current_data = array("key" => str_replace(" ", "_", strtolower($filter['singular'])), "value" => $value);

				if(isset($filter['compare_value']) && $filter['compare_value'] != "="){
					$current_data['compare'] = html_entity_decode($filter['compare_value']);
					$current_data['type']    = "numeric";
				}

				//D($current_data);

				$data[] = $current_data;

			} else {
				// year workaround, bad wordpress >:| ...
				/*if(strtolower($filter['singular']) == "year"){

					if(isset($get_or_post["yr"]) && !empty($get_or_post["yr"])){
						$yr = $get_or_post['yr'];
					} elseif(isset($get_or_post["year"]) && !empty($get_or_post["year"])){
						$yr = $get_or_post['year'];
					}

					$value        = str_replace("-", " ", $yr);
					$current_data = array("key" => str_replace(" ", "_", strtolower($filter['singular'])), "value" => $value);
				} else {*/
					$value = $get_or_post[$get_singular];

					if(!isset($get_or_post['action']) && empty($get_or_post['action'])){
						$value        = str_replace(array("--", "-"), array("|||", " "), $value);
					}
					$value 		  = str_replace("|||", "-", $value);
					$current_data = array("key" => str_replace(" ", "_", strtolower($filter['singular'])), "value" => urldecode($value));
				//}

				if(isset($filter['compare_value']) && $filter['compare_value'] != "="){
					$current_data['compare'] = html_entity_decode($filter['compare_value']);
					$current_data['type']    = "numeric";
				}

				//D($current_data);

				$data[] = $current_data;
			}
		}
	}

	// filter params
	if(isset($get_or_post['filter_params']) && !empty($get_or_post['filter_params'])){
		$filter_params = json_decode(stripslashes($get_or_post['filter_params']));

		// no page id for me
		unset($filter_params->page_id);

		foreach($filter_params as $index => $param){
			unset($param->length);

			$min = $param->{0};
			$max = $param->{1};

			$data[] = array(
				'key'     => str_replace(" ", "_", strtolower($index)),
				'value'   => array($min, $max),
				'type'    => 'numeric',
				'compare' => 'BETWEEN'
			);
		}
	}

	// additional categories
	if(!empty($lwp_options['additional_categories']) && !empty($lwp_options['additional_categories'])){
		foreach($lwp_options['additional_categories'] as $additional_category){
			$check_handle = str_replace(" ", "_", strtolower($additional_category));

			// in url
			if(isset($get_or_post[$check_handle]) && !empty($get_or_post[$check_handle])){
				$data[] = array("key" => $check_handle, "value" => 1);
			}
		}
	}


	// order by
	if(isset($get_or_post['order_by']) && isset($get_or_post['order'])){
		$args['orderby'] = $get_or_post['order_by'];
		$args['order']   = $get_or_post['order'];
	}
	
	if(!empty($data)){
		$args['meta_query'] = $data;
	}
	
	//D($get_or_post);
	//D($args);
	
	return array($args);//, $sort_items);
}

if(!function_exists("D")){
	function D($var){
		echo "<pre>";
		print_r($var);
		echo "</pre>";
	}
}

//********************************************
//	Get Fontawesome Icons
//***********************************************************
if(!function_exists("get_fontawesome_icons")){
	function get_fontawesome_icons(){
		$pattern = '/\.(fa-(?:\w+(?:-)?)+):before\s+{\s*content:\s*"(.+)";\s+}/';
		$subject = @file_get_contents(LISTING_DIR . 'css/font-awesome.css');
		
		preg_match_all($pattern, $subject, $matches, PREG_SET_ORDER);
		
		$icons = array();
		
		foreach($matches as $match){
			$icons[$match[1]] = $match[2];
		}
		
		return $icons;
	}
}

//********************************************
//	Money Format
//***********************************************************
function format_currency($amount){
	global $lwp_options;
	
	$amount = preg_replace("/[^0-9]/", "", $amount);

	if(empty($amount)){
		return false;
	}
	
	$currency_symbol    = (isset($lwp_options['currency_symbol']) && !empty($lwp_options['currency_symbol']) ? $lwp_options['currency_symbol'] : "");
	$currency_separator = (isset($lwp_options['currency_separator']) && !empty($lwp_options['currency_separator']) ? $lwp_options['currency_separator'] : "");
	
	$return = (!empty($currency_separator) ? number_format($amount, 0, '.', $currency_separator) : $amount);

	$return = ($lwp_options['currency_placement'] ? $currency_symbol . $return : $return . $currency_symbol);

	return $return;
}

//********************************************
//	Pagination Boxes
//***********************************************************
if(!function_exists("page_of_box")){
	function page_of_box($load = false){
		global $lwp_options;

		$return = "";

		if($load != false && !empty($load)){	
			$paged = $load;
			$load_number = $load;

			$listing_args = listing_args($_POST);
			$args		  = $listing_args[0];
				
			$args['posts_per_page'] = -1;
			$matches       = query_posts( $args );	
			$load_number   = count($matches);
		} else {		
			$paged_var    = get_query_var('paged');
			$paged     	  = (isset($paged_var) && !empty($paged_var) ? $paged_var : 1);
			
			$listing_args = listing_args($_GET);
			$args		  = $listing_args[0];
				
			$args['posts_per_page'] = -1;
			$matches       = query_posts( $args );	
			$load_number   = count($matches);
		}
	
		$number = $load_number;
		$total  = ceil($number / (isset($lwp_options['listings_amount']) && !empty($lwp_options['listings_amount']) ? $lwp_options['listings_amount'] : 1));

        $return .= '<div class="controls full page_of" data-page="' . ($paged ? $paged : 1) . '"> 
        	<a href="#" class="left-arrow' . ($paged == 1 ? " disabled" : "") . '"><i class="fa fa-angle-left"></i></a> 
            <span>' . __("Page", "listings") . ' <span class="current_page">' . ($paged ? $paged : 1) . '</span> ' . __('of', 'listings') . ' <span class="total_pages">' . ($total == 0 ? 1 : $total) . '</span></span> 
            <a href="#" class="right-arrow'. ($paged == $total ? " disabled" : "") . '"><i class="fa fa-angle-right"></i></a> 
        </div>';

        return $return;
		
		wp_reset_postdata();
		wp_reset_query();
		if(isset($_POST['action']) && !empty($_POST['action'])){
			die;  
		}
	}
}

add_action('wp_ajax_load_page_of_box', 'page_of_box');
add_action('wp_ajax_nopriv_load_page_of_box', 'page_of_box');

if(!function_exists("bottom_page_box")){
	function bottom_page_box($layout = false, $load = false){
		global $lwp_options;

		$return = "";
	
		if($load != false && !empty($load)){	
			$paged = $load;
			$load_number = $load;

			$paged_var = get_query_var('paged');
			$paged     = (isset($paged_var) && !empty($paged_var) ? $paged_var : 1);
			
			$listing_args = listing_args($_POST);
			$args		  = $listing_args[0];
				
			$args['posts_per_page'] = -1;
			$matches       = query_posts( $args );	
			$load_number   = count($matches);
		} else {
			$paged_var = get_query_var('paged');
			$paged     = (isset($paged_var) && !empty($paged_var) ? $paged_var : 1);
			
			$listing_args = listing_args($_GET);
			$args		  = $listing_args[0];
				
			$args['posts_per_page'] = -1;
			$matches       = query_posts( $args );	
			$load_number   = count($matches);
			
			// if any special layouts			
			if($layout == "wide_left" || $layout == "boxed_left"){
				$additional_classes = "col-lg-offset-3";
				$cols = 9;
			} else {
				$cols = 12;
			}
			
			$return .= '<div class="col-lg-' . $cols . ' col-md-' . $cols . ' col-sm-12 col-xs-12 pagination_container' . (isset($additional_classes) && !empty($additional_classes) ? " " . $additional_classes : "") . '">';
		}
		
		$number = $load_number;
		$total = ceil($number / (isset($lwp_options['listings_amount']) && !empty($lwp_options['listings_amount']) ? $lwp_options['listings_amount'] : 1));
		
		$return .= '<ul class="pagination margin-bottom-none margin-top-25 md-margin-bottom-none bottom_pagination">';
			
		$return .= "<li data-page='previous' class='" . ($paged > 1 ? "" : "disabled") . " previous' style='margin-right:2px;'><a href='#'><i class='fa fa-angle-left'></i></a></li>";
		
		if($total == 0){
			$return .= "<li data-page='1' class='disabled number'><a href='#'>1</a></li>";
		} else {
			for($i = 1; $i <= $total; $i++){
				$return .= "<li data-page='" . $i . "' class='" . ($paged != $i ? "" : "disabled") . " number'><a href='#'>" . $i . "</a></li>";
			}
		}
		
		$return .= "<li data-page='next' class='" . ($paged < $total ? "" : "disabled") . " next'><a href='#'><i class='fa fa-angle-right'></i></a></li>";
		
		$return .= "</ul></div>";
		
		return $return;

		wp_reset_postdata();
		wp_reset_query();
	}
}

	

add_action('wp_ajax_load_bottom_page_box', 'bottom_page_box');
add_action('wp_ajax_nopriv_load_bottom_page_box', 'bottom_page_box');

if(!function_exists("get_total_meta")){
	function get_total_meta($meta_key, $meta_value){
		global $wpdb;
		
		$sql = $wpdb->prepare("SELECT count(DISTINCT pm.post_id)
			FROM $wpdb->postmeta pm
			JOIN $wpdb->posts p ON (p.ID = pm.post_id)
			WHERE pm.meta_key = %s
			AND pm.meta_value = %s
			AND p.post_type = 'listings'
			AND p.post_status = 'publish'
		", $meta_key, $meta_value);
		
		$count = $wpdb->get_var($sql);
		
		return $count;
	}
}

if(!function_exists("comp_thumb")){
	function comp_thumb($number, $dimension){
		switch($number){
			case 2:
				$return = ($dimension == "width" ? 562 : 292);
				break;
			
			case 3:
				$return = ($dimension == "width" ? 362 : 188);
				break;
				
			case 4:
				$return = ($dimension == "width" ? 262 : 136);
				break;
		}
		
		return $return;
	}
}

function remove_shortcode_extras($code){
	$return = preg_replace( '%<p>&nbsp;\s*</p>%', '', $code );
	$return = preg_replace( '%<p>\s*</p>%', '', $code );
	$old    = array( '<br />', '<br>' );
	$new    = array( '', '' );
	$return = str_replace( $old, $new, $return );
	
	return $return;
}

//********************************************
//	Plugin Modifications
//***********************************************************

if(!function_exists("ksort_deep")){
	function ksort_deep(&$array){
		ksort($array);
		foreach($array as $value)
			if(is_array($value))
				ksort_deep($value);
	}
}

//********************************************
//	Get All Post Meta
//***********************************************************
if( !function_exists("get_post_meta_all") ){
	function get_post_meta_all($post_id){
		global $wpdb;
		$data = array();
		$wpdb->query( "
			SELECT `meta_key`, `meta_value`
			FROM $wpdb->postmeta
			WHERE `post_id` = $post_id");

		foreach($wpdb->last_result as $k => $v){
			$data[$v->meta_key] =   $v->meta_value;
		};
		return $data;
	}
}

//********************************************
//	Listing Video
//***********************************************************
if( !function_exists("listing_video") ){
	function listing_video($url){
		if (strpos($url, 'youtube') > 0) {
			parse_str( parse_url( $url, PHP_URL_QUERY ), $query_string );
			
			$return['id']      = $query_string['v'];  
			$return['service'] = 'youtube';
		} elseif (strpos($url, 'vimeo') > 0) {
			$return['id']      = (int)substr(parse_url($url, PHP_URL_PATH), 1);
			$return['service'] = 'vimeo';
		} else {
			$return['service'] = 'unknown';
		}
		
		return $return;
	}
}


//********************************************
//	Shortcode / Widget Functions
//***********************************************************
function testimonial_slider($slide, $speed, $pager, $content, $widget = false){
	// remove br
	$content = str_replace("<br />", "", $content);
	
	/*$return  = "<script type=\"text/javascript\">";
	$return .= "jQuery(document).ready(function ($) { ";      
		$return .= "$('.testimonials').bxSlider({";
			$return .= "mode: '" . $slide . "',";
			$return .= "slideMargin: 3,";
			$return .= "auto: true,";
			$return .= "autoHover: true,";
			$return .= "speed:" . $speed . ",";
			$return .= "pager: " . $pager . ",";
			$return .= "controls: false";
		$return .= "});";       
	$return .= "});";
	$return .= "</script>";*/
	
	$return  = "<!--Testimonials Start-->";
	$return .= "<div class='testimonial'>";
	$return .= "<ul class=\"testimonial_slider\">";	
		if($widget === false){	
			$return .= do_shortcode($content);
		} else {
			
			foreach($widget as $fields){
				$return .= testimonial_slider_quote($fields['name'], $fields['content']);
			}
		}
	$return .= "</ul>";
	$return .= "</div>";
	$return .= "<!--Testimonials End-->";
	
	$return = remove_shortcode_extras($return);
	
	return $return;
}

function testimonial_slider_quote($name, $content){
	$return  = "<li><blockquote class='style1'><span>" . $content;
	$return .= "</span><strong>" . $name . "</strong> ";
	$return .= "</blockquote></li>";	
	
    return $return;
}

if(!function_exists("random_string")){
	function random_string($length = 10) {
		$characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$randomString = '';
		for ($i = 0; $i < $length; $i++) {
			$randomString .= $characters[rand(0, strlen($characters) - 1)];
		}
		return $randomString;
	}
}

function vehicle_scroller($title = "Recent Vehicles", $description = "Browse through the vast selection of vehicles that have been added to our inventory", $sort = null, $listings = null){ 
	$args = array("post_type"  => "listings");
	switch($sort){			
		case "newest":
			$args  = array("post_type"      => "listings",
						   "posts_per_page" => -1,
						   "orderby"        => "date",
						   "order"          => "DESC"
						  );
			break;
			
		case "oldest":
			$args  = array("post_type"      => "listings",
						   "posts_per_page" => -1,
						   "orderby"        => "date",
						   "order"          => "ASC"
						  );
			break;
			
		default:			
			$query = "";
			break;
	}
	
	if(isset($listings) && !empty($listings)){
		$listing_ids = explode(",", $listings);
		$args['post__in'] = $listing_ids;
	}
	
	$query = new WP_Query( $args );
	
	ob_start(); ?>
	
    <div class="recent-vehicles-wrap">
		<div class="row">
            <div class="col-lg-2 col-md-2 col-sm-4 col-xs-12 recent-vehicles padding-left-none xs-padding-bottom-20">
    			<h5 class="margin-top-none"><?php echo $title; ?></h5>
                <p><?php echo $description; ?></p>
                
                <div class="arrow3 clearfix" id="slideControls3"><span class="prev-btn"></span><span class="next-btn"></span></div>
    		</div>
   			<div class="col-md-10 col-sm-8 padding-right-none sm-padding-left-none xs-padding-left-none">
				<div class="carasouel-slider3">
					<?php		
                    while ( $query->have_posts() ) : $query->the_post();
                        $post_meta       = get_post_meta_all(get_the_ID());
                        $listing_options = unserialize(unserialize($post_meta['listing_options']));
                        $gallery_images  = unserialize($post_meta['gallery_images']); 
										
						echo "<div class=\"slide\">";
                            echo "<div class=\"car-block\">";
                                echo "<div class=\"img-flex\">";
								echo "<a href=\"" . get_permalink(get_the_ID()) . "\"><span class=\"align-center\"><i class=\"fa fa-3x fa-plus-square-o\"></i></span></a> <img src=\"" . auto_image($gallery_images[0], "auto_thumb", true) . "\" alt=\"\" class=\"img-responsive no_border\"> </div>";
                                echo "<div class=\"car-block-bottom\">";
                                    echo "<h6><strong>" . get_the_title() . "</strong></h6>";
                                    echo "<h6>" . (isset($listing_options['short_desc']) && !empty($listing_options['short_desc']) ? $listing_options['short_desc'] : "") . "</h6>";
                                    echo (isset($listing_options['price']['value']) && !empty($listing_options['price']['value']) ? "<h5>" . format_currency($listing_options['price']['value']) . "</h5>" : "");
                                echo "</div>";
                            echo "</div>";
                        echo "</div>";
                    endwhile; ?>
                </div>
    		</div>
            
            <div class="clear"></div>
		</div>
    </div>
<?php

return ob_get_clean();

}

//********************************************
//	Filter Listings
//***********************************************************
function filter_listing_results($var) {	
	global $lwp_options, $filterable;
		
	$listing_args = listing_args($_POST);
	$args		  = $listing_args[0];
	
	//D($listing_args);

	// meta query with dashes
	if(!empty($args['meta_query'])){
		foreach($args['meta_query'] as $key => $meta){
			$args['meta_query'][$key]['value'] = str_replace("%2D", "-", $meta['value']);
		}
	}
	
	$posts = query_posts($args);
	
	//D($posts);
	
	$return = '';
	foreach($posts as $post){
		$return .= (isset($_POST['layout']) && !empty($_POST['layout']) ? inventory_listing($post->ID, $_POST['layout']) : inventory_listing($post->ID));
	}
	
	$args['posts_per_page'] = -1;
	
	$total_matches = count(query_posts($args));
	$return = ($total_matches == 0 ? "<div class=\"alert alert-error\">" . __("No listings found", "listings") . "..</div>" : $return);
	
	$paged = (get_query_var('paged') ? get_query_var('paged') : false);

	// generate filter parameters

	if(isset($_POST['filter_params']) && !empty($_POST['filter_params'])){

		$filter     = array();
		$categories = json_decode(stripslashes($_POST['filter_params']), true);

		//{"body-style":"sports-utility-vehicle","model":"cayenne"}
		foreach($categories as $category => $value){
			$singular = get_single_listing_category(str_replace("-", "_", $category));

			if(is_array($value)){
				$filter[$category] = array("value"    => $value,
										   "singular" => $singular['singular']
									);
			} else {
				$filter[$category] = array("value"    => get_category_correct_case($category, $value),
										   "singular" => $singular['singular']
									);
			}
		}

	}

	$return_array = array( "content"     => $return,
						   "number"      => $total_matches,
						   "top_page"    => page_of_box($paged),
						   "bottom_page" => bottom_page_box(false, $paged),
						   "args"		 => $args
				   );

	// filter
	if(isset($filter) && !empty($filter)){
		$return_array['filter'] = $filter;
	}

	if($var === true){
		return json_encode( $return_array );
	} else {		
		echo json_encode( $return_array );
	}
	
   	die();
}

add_action("wp_ajax_filter_listing", "filter_listing_results");
add_action("wp_ajax_nopriv_filter_listing", "filter_listing_results");

//********************************************
//	Get single permalink
//***********************************************************
add_action('wp_ajax_get_single_permalink', 'get_single_permalink');
add_action('wp_ajax_nopriv_get_single_permalink', 'get_single_permalink');

function get_single_permalink(){
	echo get_permalink(intval($_REQUEST['id']));
	die();
}

if(!function_exists("car_comparison")){
	function car_comparison($car, $class){
		ob_start();
		
		$all_post_meta   = get_post_meta_all($car);
		$listing_options = unserialize(unserialize($all_post_meta['listing_options']));		
		$gallery_images  = unserialize($all_post_meta['gallery_images']); ?>
        <div class='col-lg-<?php echo $class; ?>'>
            <div class="porche margin-bottom-25">
                <div class="porche-header"> <span><?php echo get_the_title($car); ?></span> <strong><?php echo format_currency($listing_options['price']['value']); ?></strong> </div>
                <?php $img = (!empty($gallery_images) ? auto_image($gallery_images[0], "auto_slider", true) : "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"); ?>
                <div class="porche-img"> <img src="<?php echo $img; ?>" alt="" class="no_border"></div>
                <div class="car-detail clearfix">
                    <div class="table-responsive">
                        <table class="table comparison">
                            <tbody>
                            	<?php
                            		$listing_categories = get_listing_categories();
									
									foreach($listing_categories as $category){
										$safe_handle = str_replace(" ", "_", strtolower($category['singular']));
										$value       = (isset($all_post_meta[$safe_handle]) && !empty($all_post_meta[$safe_handle]) ? $all_post_meta[$safe_handle] : "");

										if(isset($category['currency']) && $category['currency'] == 1){
											$value = format_currency($value);
										}

										echo "<tr><td>" . $category['singular'] . ": </td><td>" . $value . "</td></tr>";
									} ?>
                                <tr>
                                    <td><?php _e("OPTIONS", "listings"); ?>:</td>
                                    <td></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="option-tick-list clearfix">
                        <div class="row">
                            <div class="col-lg-12">
                                <?php
								$multi_options = unserialize((isset($all_post_meta['multi_options']) && !empty($all_post_meta['multi_options']) ? $all_post_meta['multi_options'] : ""));
								
								if(isset($multi_options) && !empty($multi_options)){
									
									switch($class){
										case 6:
											$columns = 3;
											$column_class = 4;
											break;
										
										case 4:
											$columns = 2;
											$column_class = 6;
											break;
											
										case 3:
											$columns = 1;
											$column_class = 12;
											break;
									}
									
									$amount = ceil(count($multi_options) / $columns); 
									$new    = array_chunk($multi_options, $amount);
									
									echo "<div class='row'>";
									foreach($new as $section){
										echo "<ul class='options col-lg-" . $column_class . "'>";
										foreach($section as $option){
											echo "<li>" . $option . "</li>";
										}
										echo "</ul>";
									}
									echo "</div>";
								} else {
									echo "<ul class='empty'><li>" . __("No options yet", "listings") . "</li></ul>";
								} ?>
                            </div>
                        </div>
                    </div>
                    <div class="porche-footer margin-top-25 padding-top-20 padding-bottom-15">
                        <form method="post" action="<?php echo get_permalink($car); ?>">
                            <input type="submit" value="<?php _e("View Listing", "listings"); ?>">
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
        <?php
		
		return ob_get_clean();
	}
}

function is_edit_page($new_edit = null){
    global $pagenow;
    //make sure we are on the backend
    if (!is_admin()) return false;


    if($new_edit == "edit")
        return in_array( $pagenow, array( 'post.php',  ) );
    elseif($new_edit == "new") //check for new post page
        return in_array( $pagenow, array( 'post-new.php' ) );
    else //check for either new or edit
        return in_array( $pagenow, array( 'post.php', 'post-new.php' ) );
}

//********************************************
//	Show Social Icons
//***********************************************************
if( !function_exists("show_social_icons") ) {
	function show_social_icons() {
		if ( has_post_thumbnail() ) {
		 	$image = wp_get_attachment_image_src(get_the_post_thumbnail());
		} elseif(is_singular('listings')) {
			$saved_images   = get_post_meta(get_queried_object_id(), "gallery_images");
			$gallery_images = unserialize($saved_images[0]);

			$image = (isset($gallery_images[0]) && !empty($gallery_images[0]) ? $gallery_images[0] : "");
		} else {
			$image = '';
		}
		?>
		<ul class="social-likes" data-url="<?php echo get_permalink(); ?>" data-title="<?php echo get_the_title(); ?>">
            <li class="facebook" title="<?php _e("Share link on Facebook", "listings"); ?>"></li>
            <li class="plusone" title="<?php _e("Share link on Google+", "listings"); ?>"></li>
            <li class="pinterest" title="<?php _e("Share image on Pinterest", "listings"); ?>" data-media="<?php echo $image; ?>"></li>
            <li class="twitter" title="<?php _e("Share link on Twitter", "listings"); ?>"></li>
        </ul>
	<?php    
	}
}


if(!function_exists("is_ajax")){
	function is_ajax(){
		if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
			return true; 
		} else {
			return false;
		}
	}
}

function column_maker(){ ?>
	<div id='full_column' class='column_display_container' data-number='0'>
        <div class='empty one'></div>
        <div class='empty one'></div>
        <div class='empty one'></div>
        <div class='empty one'></div>
        <div class='empty one'></div>
        <div class='empty one'></div>
        <div class='empty one'></div>
        <div class='empty one'></div>
        <div class='empty one'></div>
        <div class='empty one'></div>
        <div class='empty one'></div>
        <div class='empty one'></div>
    </div>
    
    <br />
    
    <div class='generate_columns button'><?php _e("Generate Columns", "listings"); ?></div>
    
    <?php
	$i     = 1;
	$width = 31;
	
	while($i <= 12){
		echo "<div class='column_display_container insert' data-number='" . $i . "'><span class='label'>" . $i . ($i != 1 ? " / 12" : "") . "</span> <div class='full twelve' style='width: " . ($i * $width) . "px;'></div></div><br />";
		$i++;
	}
	
	die;	
}
add_action('wp_ajax_column_maker', 'column_maker');
add_action('wp_ajax_nopriv_column_maker', 'column_maker');

if(!function_exists("is_edit_page")){
	function is_edit_page($new_edit = null){
		global $pagenow;
		
		if (!is_admin()) return false;
	
	
		if($new_edit == "edit"){
			return in_array( $pagenow, array( 'post.php',  ) );
		} elseif($new_edit == "new") {
			return in_array( $pagenow, array( 'post-new.php' ) );
		} else {
			return in_array( $pagenow, array( 'post.php', 'post-new.php' ) );
		}
	}
}


if(!function_exists("remove_editor")){
	function remove_editor() {
	  remove_post_type_support('listings', 'editor');
	}
}
add_action('admin_init', 'remove_editor');


if(!function_exists("youtube_video_id")){
	function youtube_video_id($url) {
		if(is_youtube($url)) {
			$pattern = '/^.*((youtu.be\/)|(v\/)|(\/u\/\w\/)|(embed\/)|(watch\?))\??v?=?([^#\&\?]*).*/';
			preg_match($pattern, $url, $matches);
			if (count($matches) && strlen($matches[7]) == 11) {
				return $matches[7];
			}
		}
	   
		return '';
	}
}

if(!function_exists("is_youtube")){
	function is_youtube($url) {
		return (preg_match('/youtu\.be/i', $url) || preg_match('/youtube\.com\/watch/i', $url));
	}
}


if(!function_exists("get_all_media_images")){
	function get_all_media_images(){
		$query_images_args = array(
			'post_type' => 'attachment', 'post_mime_type' =>'image', 'post_status' => 'inherit', 'posts_per_page' => -1,
		);
		
		$query_images = new WP_Query( $query_images_args );
		$images = array();
		
		foreach ( $query_images->posts as $image) {
			$images[]= wp_get_attachment_url( $image->ID );
		}
		
		return $images;
	}
}

//********************************************
//	Single Listing Template
//***********************************************************
add_filter( 'template_include', 'my_plugin_templates' );
function my_plugin_templates( $template ) {
    $post_types = array(  );

    if ( is_singular( 'listings' ) && ! file_exists( get_stylesheet_directory() . '/single-listings.php' ) ){
        $template = LISTING_HOME . 'single-listings.php';
	} elseif( is_singular( 'listings_portfolio' ) && ! file_exists( get_stylesheet_directory() . '/single-portfolio.php' ) ){
		$template = LISTING_HOME . 'single-portfolio.php';
	}
		
    return $template;
}

/* Form */
function listing_form(){
	global $lwp_options;

	$_POST  = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
	$form   = $_POST['form'];
	$errors = array();
			
	// email headers
	$headers  = "From: " . $_POST['email'] . "\r\n";
	$headers .= "Reply-To: ". $_POST['email'] . "\r\n";
	$headers .= "MIME-Version: 1.0\r\n";
	$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";

	$subject  = ucwords(str_replace("_", " ", $_POST['form']));

	if($form == "email_friend"){
		
		// validate email
		if(!filter_var($_POST['friends_email'], FILTER_VALIDATE_EMAIL) && !filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)){
			$errors[] = "Not a valid email";
		} else {
			$post_meta = get_post_meta_all($_POST['id']);

			$listing_options = unserialize(unserialize($post_meta['listing_options']));
			$gallery_images  = unserialize($post_meta['gallery_images']);

			$name    = (isset($_POST['name']) && !empty($_POST['name']) ? sanitize_text_field($_POST['name']) : "");
			$from    = (isset($_POST['email']) && !empty($_POST['email']) ? sanitize_text_field($_POST['email']) : "");
			$friend  = (isset($_POST['friends_email']) && !empty($_POST['friends_email']) ? sanitize_text_field($_POST['friends_email']) : "");
			$message = (isset($_POST['message']) && !empty($_POST['message']) ? sanitize_text_field($_POST['message']) : "");

			$thumbnail  = auto_image($gallery_images[0], "auto_thumb", true);//$gallery_images[0]['thumb']['url'];

			$categories = get_listing_categories();

			$table   = "<table width='100%' border='0' cellspacing='0' cellpadding='2'><tbody>";

			$table  .= "<tr>
				<td><img src='" . $thumbnail . "'></td>
				<td style='font-weight:bold;color:#000;'>" . get_the_title($_POST['id']) . "</td>
				<td></td>
				<td>" . $listing_options['price']['text'] . ": " . format_currency($listing_options['price']['value']) . "</td>
			</tr>";

			foreach($categories as $category){
				$safe_handle = str_replace(" ", "_", strtolower($category['singular']));
				$table .= "<tr><td>" . $category['singular'] . ": </td><td> " . (isset($post_meta[$safe_handle]) && !empty($post_meta[$safe_handle]) ? $post_meta[$safe_handle] : __("N/A", "listings")) . "</td></tr>";
			}

			$table  .= "<tr>
							<td>&nbsp;</td>
							<td align='center' style='background-color:#000;font-weight:bold'><a href='" . get_permalink($_POST['id']) . "' style='color:#fff;text-decoration:none' target='_blank'>" . __('Click for more details', 'listings') . "</a></td>
						</tr>";

			$table  .= "</tbody></table>";

			$search  = array('{table}', '{message}', '{name}');
			$replace = array($table, $message, $name);
			
			$subject      = str_replace("{name}", $name, $lwp_options['friend_subject']);
			$send_message = str_replace($search, $replace, $lwp_options['friend_layout']);

			$mail         = @mail($friend, $subject, $send_message, $headers);
		}
	} else {
		
		// validate email
		if(!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)){
			$errors[] = __("Not a valid email", "listings");
		} else {

			switch ($form) {
				case 'request_info':
					$to      = ($lwp_options['info_to'] ? $lwp_options['info_to'] : get_bloginfo('admin_email'));
					$subject = $lwp_options['info_subject'];

					$name           = (isset($_POST['name']) && !empty($_POST['name']) ? sanitize_text_field($_POST['name']) : "");
					$contact_method = (isset($_POST['contact_method']) && !empty($_POST['contact_method']) ? sanitize_text_field($_POST['contact_method']) : "");
					$email          = (isset($_POST['email']) && !empty($_POST['email']) ? sanitize_text_field($_POST['email']) : "");
					$phone          = (isset($_POST['phone']) && !empty($_POST['phone']) ? sanitize_text_field($_POST['phone']) : "");
						
					$table   = "<table border='0'>";
					$table  .= "<tr><td>" . __("First Name", "listings") . ": </td><td> " . $name . "</td></tr>";
					$table  .= "<tr><td>" . __("Contact Method", "listings") . ": </td><td> " . $contact_method . "</td></tr>";
					$table  .= "<tr><td>" . __("Phone", "listings") . ": </td><td> " . $phone . "</td></tr>";
					$table  .= "<tr><td>" . __("Email", "listings") . ": </td><td> " . $email . "</td></tr>";
					$table  .= "</table>";
					
					$link    = get_permalink($_POST['id']);
					
					$search  = array("{name}", "{contact_method}", "{email}", "{phone}", "{table}", "{link}");
					$replace = array($name, $contact_method, $email, $phone, $table, $link);

					$message = str_replace($search, $replace, $lwp_options['info_layout']);
				break;
				
				case 'schedule':
					$to      = ($lwp_options['drive_to'] ? $lwp_options['drive_to'] : get_bloginfo('admin_email'));
					$subject = $lwp_options['drive_subject'];

					$name           = (isset($_POST['name']) && !empty($_POST['name']) ? sanitize_text_field($_POST['name']) : "");
					$contact_method = (isset($_POST['contact_method']) && !empty($_POST['contact_method']) ? sanitize_text_field($_POST['contact_method']) : "");
					$email          = (isset($_POST['email']) && !empty($_POST['email']) ? sanitize_text_field($_POST['email']) : "");
					$phone          = (isset($_POST['phone']) && !empty($_POST['phone']) ? sanitize_text_field($_POST['phone']) : "");
					$best_day       = (isset($_POST['best_day']) && !empty($_POST['best_day']) ? sanitize_text_field($_POST['best_day']) : "");
					$best_time      = (isset($_POST['best_time']) && !empty($_POST['best_time']) ? sanitize_text_field($_POST['best_time']) : "");

					$table   = "<table border='0'>";
					$table  .= "<tr><td>" . __("Name", "listings") . ": </td><td> " . $name . "</td></tr>";
					$table  .= "<tr><td>" . __("Contact Method", "listings") . ": </td><td> " . $contact_method . "</td></tr>";
					$table  .= "<tr><td>" . __("Phone", "listings") . ": </td><td> " . $phone . "</td></tr>";
					$table  .= "<tr><td>" . __("Email", "listings") . ": </td><td> " . $email . "</td></tr>";
					$table  .= "<tr><td>" . __("Best Date", "listings") . ": </td><td> " . $best_day . " " . $best_time . "</td></tr>";
					$table  .= "</table>";

					$link    = get_permalink($_POST['id']);

					$search  = array("{name}", "{contact_method}", "{email}", "{phone}", "{best_day}", "{best_time}", "{table}", "{link}");
					$replace = array($name, $contact_method, $email, $phone, $best_day, $best_time, $table, $link);

					$message = str_replace($search, $replace, $lwp_options['drive_layout']);
				break;

				case 'make_offer':
					$to      = ($lwp_options['offer_to'] ? $lwp_options['offer_to'] : get_bloginfo('admin_email'));
					$subject = $lwp_options['offer_subject'];


					$name 				= (isset($_POST['name']) && !empty($_POST['name']) ? sanitize_text_field($_POST['name']) : "");
					$contact_method 	= (isset($_POST['contact_method']) && !empty($_POST['contact_method']) ? sanitize_text_field($_POST['contact_method']) : "");
					$email 				= (isset($_POST['email']) && !empty($_POST['email']) ? sanitize_text_field($_POST['email']) : "");
					$phone 				= (isset($_POST['phone']) && !empty($_POST['phone']) ? sanitize_text_field($_POST['phone']) : "");
					$offered_price 		= (isset($_POST['offered_price']) && !empty($_POST['offered_price']) ? sanitize_text_field($_POST['offered_price']) : "");
					$financing_required = (isset($_POST['financing_required']) && !empty($_POST['financing_required']) ? sanitize_text_field($_POST['financing_required']) : "");
					$other_comments 	= (isset($_POST['other_comments']) && !empty($_POST['other_comments']) ? sanitize_text_field($_POST['other_comments']) : "");


					$table   = "<table border='0'>";
					$table  .= "<tr><td>" . __("Name", "listings") . ": </td><td> " . $name . "</td></tr>";
					$table  .= "<tr><td>" . __("Contact Method", "listings") . ": </td><td> " . $contact_method . "</td></tr>";
					$table  .= "<tr><td>" . __("Phone", "listings") . ": </td><td> " . $phone . "</td></tr>";
					$table  .= "<tr><td>" . __("Email", "listings") . ": </td><td> " . $email . "</td></tr>";
					$table  .= "<tr><td>" . __("Offered Price", "listings") . ": </td><td> " . $offered_price . "</td></tr>";
					$table  .= "<tr><td>" . __("Financing Required", "listings") . ": </td><td> " . $financing_required . "</td></tr>";
					$table  .= "<tr><td>" . __("Other Comments", "listings") . ": </td><td> " . $other_comments . "</td></tr>";
					$table  .= "</table>";

					$link   = get_permalink($_POST['id']);
						
					$search  = array("{name}", "{contact_method}", "{email}", "{phone}", "{offered_price}", "{financing_required}", "{other_comments}", "{table}", "{link}");
					$replace = array($name, $contact_method, $email, $phone, $offered_price, $financing_required, $other_comments, $table, $link);

					$message = str_replace($search, $replace, $lwp_options['offer_layout']);
				break;

				case 'trade_in':
					$to      = ($lwp_options['trade_to'] ? $lwp_options['trade_to'] : get_bloginfo('admin_email'));
					$subject = $lwp_options['trade_subject'];

					$form_items = array("first_name", "last_name", "work_phone", "phone", "email", "contact_method", "comments", "options", "year", "make", "model", "exterior_colour", "vin", "kilometres", "engine", "doors", "transmission", "drivetrain", "body_rating", "tire_rating", "engine_rating", "transmission_rating", "glass_rating", "interior_rating", "exhaust_rating", "rental_rating", "odometer_accurate", "service_records", "lienholder", "titleholder", "equipment", "vehiclenew", "accidents", "damage", "paint", "salvage");
					
					$table  = "<table border='0'>";
					foreach($form_items as $key => $single){
						$table .= "<tr><td>" . ucwords(str_replace("_", " ", $key)) . ": </td><td> " . (isset($single) && !empty($single) ? $single : "") . "</td></tr>";
					}
					$table .= "</table>";
					
					$link   = get_permalink($_POST['id']);
					
					$search   = array("{table}", "{link}");
					$replace  = array($table, $link);
				break;
			} 

			$mail = @mail($to, $subject, $message, $headers);
		}
	}

	if($mail && empty($errors)){
		echo __("Sent Successfully", "listings");
	} else {
		echo "<ul class='error_list'>";
		foreach($errors as $error){
			echo "<li>" . $error . "</li>";
		}
		echo "</ul>";
	}

	die;
}
add_action("wp_ajax_listing_form", "listing_form");
add_action("wp_ajax_nopriv_listing_form", "listing_form");

function get_first_post_image($post) {
	//global $post, $posts;
	$first_img = false;
	ob_start();
	ob_end_clean();
	$output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
	$first_img = (isset($matches[1][0]) && !empty($matches[1][0]) ? $matches[1][0] : "");

	return $first_img;
}



function url_origin($s, $use_forwarded_host=false){
    $ssl = (!empty($s['HTTPS']) && $s['HTTPS'] == 'on') ? true:false;
    $sp = strtolower($s['SERVER_PROTOCOL']);
    $protocol = substr($sp, 0, strpos($sp, '/')) . (($ssl) ? 's' : '');
    $port = $s['SERVER_PORT'];
    $port = ((!$ssl && $port=='80') || ($ssl && $port=='443')) ? '' : ':'.$port;
    $host = ($use_forwarded_host && isset($s['HTTP_X_FORWARDED_HOST'])) ? $s['HTTP_X_FORWARDED_HOST'] : (isset($s['HTTP_HOST']) ? $s['HTTP_HOST'] : null);
    $host = isset($host) ? $host : $s['SERVER_NAME'] . $port;
    return $protocol . '://' . $host;
}

function full_url($s, $use_forwarded_host=false){
    return url_origin($s, $use_forwarded_host) . $s['REQUEST_URI'];
}

function recaptcha_check(){
	global $lwp_options;

	require_once(LISTING_HOME . 'recaptchalib.php');

	$resp = recaptcha_check_answer($lwp_options['recaptcha_private_key'],
								  $_SERVER["REMOTE_ADDR"],
								  $_POST["recaptcha_challenge_field"],
								  $_POST["recaptcha_response_field"]);

	if (!$resp->is_valid) {
	  	echo __("The reCAPTCHA wasn't entered correctly. Go back and try it again.", "listings");// ."(reCAPTCHA said: " . $resp->error . ")");
	} else {
		echo __("success", "listings");
	}

	die;
}
add_action("wp_ajax_recaptcha_check", "recaptcha_check");
add_action("wp_ajax_nopriv_recaptcha_check", "recaptcha_check");

function recursive_get_parent($object_id){

}

function get_all_parent_menu_items(/*$item*/){
	global $lwp_options; 

	$return = $parent_items = array();

	$first_parent = "";

	$inventory_id = (isset($lwp_options['inventory_page']) && !empty($lwp_options['inventory_page']) ? $lwp_options['inventory_page'] : "");
	$menu_name    = 'header-menu';

    if ( ( $locations = get_nav_menu_locations() ) && isset( $locations[ $menu_name ] ) ) {
		$menu       = wp_get_nav_menu_object($locations[ $menu_name ]);
		$menu_items = wp_get_nav_menu_items($menu->term_id);

		$readable_array = array();

		foreach($menu_items as $key => $item){
			$readable_array[($item->object_id != $item->ID ? $item->db_id : $item->object_id)] = $item;

			// get first parent
			if($item->object_id == $inventory_id && $item->menu_item_parent != 0){
				$first_parent = $item->menu_item_parent;
			}
		}

		$parent_items   = array();
		$still_checking = true;
		$check_item     = (isset($first_parent) && !empty($first_parent) ? $first_parent : "");

		while($still_checking){
			// stop, reached the end of the parent ladder
			if($check_item == 0){
				$still_checking = false;
			} else {
			// keep on truckin
				$parent_items[] = $check_item;
				$check_item = $readable_array[$check_item]->menu_item_parent;
			}
		}
    }

	return $parent_items;
}

function generate_inventory_ids(){
	update_option("inventory_menu_ids", get_all_parent_menu_items());
}
add_action("init", "generate_inventory_ids");


function inventory_menu_highlight($classes, $item){
	global $lwp_options;

	$inventory_id = (isset($lwp_options['inventory_page']) && !empty($lwp_options['inventory_page']) ? $lwp_options['inventory_page'] : "");

	$inventory_menu_ids = get_option("inventory_menu_ids");

	if(is_singular('listings') &&  ((isset($inventory_id) && $item->object_id == $inventory_id) || (in_array(($item->object_id != $item->ID ? $item->db_id : $item->object_id), $inventory_menu_ids)))){
		$classes[] = "active";
	}

	return $classes;
}
add_filter('nav_menu_css_class', 'inventory_menu_highlight', 10, 2);


// listing categories import
function import_listing_categories(){
	$demo_content = unserialize('a:18:{s:4:"year";a:6:{s:8:"singular";s:4:"Year";s:6:"plural";s:5:"Years";s:10:"filterable";s:1:"1";s:14:"use_on_listing";i:0;s:13:"compare_value";s:1:"=";s:5:"terms";a:6:{i:0;s:4:"2014";i:1;s:4:"2013";i:2;s:4:"2012";i:3;s:4:"2010";i:4;s:4:"2009";i:5;s:4:"2015";}}s:4:"make";a:6:{s:8:"singular";s:4:"Make";s:6:"plural";s:5:"Makes";s:10:"filterable";s:1:"1";s:14:"use_on_listing";i:0;s:13:"compare_value";s:1:"=";s:5:"terms";a:1:{i:0;s:7:"Porsche";}}s:5:"model";a:6:{s:8:"singular";s:5:"Model";s:6:"plural";s:6:"Models";s:10:"filterable";s:1:"1";s:14:"use_on_listing";i:0;s:13:"compare_value";s:1:"=";s:5:"terms";a:5:{i:0;s:7:"Carrera";i:1;s:3:"GTS";i:2;s:7:"Cayenne";i:3;s:7:"Boxster";i:4;s:5:"Macan";}}s:10:"body_style";a:6:{s:8:"singular";s:10:"Body Style";s:6:"plural";s:11:"Body Styles";s:10:"filterable";s:1:"1";s:14:"use_on_listing";s:1:"1";s:13:"compare_value";s:1:"=";s:5:"terms";a:3:{i:0;s:11:"Convertible";i:1;s:5:"Sedan";i:2;s:22:"Sports Utility Vehicle";}}s:7:"mileage";a:6:{s:8:"singular";s:7:"Mileage";s:6:"plural";s:8:"Mileages";s:10:"filterable";s:1:"1";s:14:"use_on_listing";s:1:"1";s:13:"compare_value";s:4:"&lt;";s:5:"terms";a:10:{i:0;s:5:"10000";i:1;s:5:"20000";i:2;s:5:"30000";i:3;s:5:"40000";i:4;s:5:"50000";i:5;s:5:"60000";i:6;s:5:"70000";i:7;s:5:"80000";i:8;s:5:"90000";i:9;s:6:"100000";}}s:12:"transmission";a:6:{s:8:"singular";s:12:"Transmission";s:6:"plural";s:13:"Transmissions";s:10:"filterable";s:1:"1";s:14:"use_on_listing";s:1:"1";s:13:"compare_value";s:1:"=";s:5:"terms";a:8:{i:0;s:14:"6-Speed Manual";i:1;s:17:"5-Speed Automatic";i:2;s:17:"8-Speed Automatic";i:3;s:17:"6-Speed Semi-Auto";i:4;s:17:"6-Speed Automatic";i:5;s:14:"5-Speed Manual";i:6;s:17:"8-Speed Tiptronic";i:7;s:11:"7-Speed PDK";}}s:12:"fuel_economy";a:6:{s:8:"singular";s:12:"Fuel Economy";s:6:"plural";s:14:"Fuel Economies";s:10:"filterable";s:1:"1";s:14:"use_on_listing";i:0;s:13:"compare_value";s:4:"&lt;";s:5:"terms";a:6:{i:0;s:2:"10";i:1;s:2:"20";i:2;s:2:"30";i:3;s:2:"40";i:4;s:2:"50";i:5;s:2:"50";}}s:9:"condition";a:6:{s:8:"singular";s:9:"Condition";s:6:"plural";s:10:"Conditions";s:10:"filterable";s:1:"1";s:14:"use_on_listing";i:0;s:13:"compare_value";s:1:"=";s:5:"terms";a:3:{i:0;s:9:"Brand New";i:1;s:13:"Slightly Used";i:2;s:4:"Used";}}s:8:"location";a:6:{s:8:"singular";s:8:"Location";s:6:"plural";s:9:"Locations";s:10:"filterable";s:1:"1";s:14:"use_on_listing";i:0;s:13:"compare_value";s:1:"=";s:5:"terms";a:1:{i:0;s:7:"Toronto";}}s:5:"price";a:8:{s:8:"singular";s:5:"Price";s:6:"plural";s:6:"Prices";s:10:"filterable";s:1:"1";s:14:"use_on_listing";i:0;s:13:"compare_value";s:4:"&lt;";s:8:"currency";s:1:"1";s:10:"link_value";s:5:"price";s:5:"terms";a:10:{i:0;s:5:"10000";i:1;s:5:"20000";i:2;s:5:"30000";i:3;s:5:"40000";i:4;s:5:"50000";i:5;s:5:"60000";i:6;s:5:"70000";i:7;s:5:"80000";i:8;s:5:"90000";i:9;s:6:"100000";}}s:10:"drivetrain";a:6:{s:8:"singular";s:10:"Drivetrain";s:6:"plural";s:11:"Drivetrains";s:10:"filterable";i:0;s:14:"use_on_listing";s:1:"1";s:13:"compare_value";s:1:"=";s:5:"terms";a:4:{i:0;s:3:"AWD";i:1;s:3:"RWD";i:2;s:3:"4WD";i:3;s:14:"Drivetrain RWD";}}s:6:"engine";a:6:{s:8:"singular";s:6:"Engine";s:6:"plural";s:7:"Engines";s:10:"filterable";i:0;s:14:"use_on_listing";s:1:"1";s:13:"compare_value";s:1:"=";s:5:"terms";a:9:{i:0;s:7:"3.6L V6";i:1;s:17:"4.8L V8 Automatic";i:2;s:13:"4.8L V8 Turbo";i:3;s:7:"4.8L V8";i:4;s:7:"3.8L V6";i:5;s:18:"2.9L Mid-Engine V6";i:6;s:18:"3.4L Mid-Engine V6";i:7;s:14:"3.0L V6 Diesel";i:8;s:13:"3.0L V6 Turbo";}}s:14:"exterior_color";a:6:{s:8:"singular";s:14:"Exterior Color";s:6:"plural";s:15:"Exterior Colors";s:10:"filterable";i:0;s:14:"use_on_listing";s:1:"1";s:13:"compare_value";s:1:"=";s:5:"terms";a:10:{i:0;s:13:"Racing Yellow";i:1;s:23:"Rhodium Silver Metallic";i:2;s:16:"Peridot Metallic";i:3;s:17:"Ruby Red Metallic";i:4;s:5:"White";i:5;s:18:"Aqua Blue Metallic";i:6;s:23:"Chestnut Brown Metallic";i:7;s:10:"Guards Red";i:8;s:18:"Dark Blue Metallic";i:9;s:18:"Lime Gold Metallic";}}s:14:"interior_color";a:6:{s:8:"singular";s:14:"Interior Color";s:6:"plural";s:15:"Interior Colors";s:10:"filterable";i:0;s:14:"use_on_listing";s:1:"1";s:13:"compare_value";s:1:"=";s:5:"terms";a:10:{i:0;s:14:"Interior Color";i:1;s:10:"Agate Grey";i:2;s:15:"Alcantara Black";i:3;s:11:"Marsala Red";i:4;s:5:"Black";i:5;s:13:"Platinum Grey";i:6;s:11:"Luxor Beige";i:7;s:13:"Platinum Grey";i:8;s:21:"Black / Titanium Blue";i:9;s:10:"Agate Grey";}}s:3:"mpg";a:7:{s:8:"singular";s:3:"MPG";s:6:"plural";s:3:"MPG";s:10:"filterable";i:0;s:14:"use_on_listing";s:1:"1";s:13:"compare_value";s:1:"=";s:10:"link_value";s:3:"mpg";s:5:"terms";a:9:{i:0;s:16:"19 city / 27 hwy";i:1;s:16:"16 city / 24 hwy";i:2;s:15:"15 city /21 hwy";i:3;s:16:"15 city / 21 hwy";i:4;s:16:"18 city / 26 hwy";i:5;s:16:"16 city / 24 hwy";i:6;s:16:"20 city / 30 hwy";i:7;s:16:"20 City / 28 Hwy";i:8;s:16:"19 city / 29 hwy";}}s:12:"stock_number";a:6:{s:8:"singular";s:12:"Stock Number";s:6:"plural";s:13:"Stock Numbers";s:10:"filterable";i:0;s:14:"use_on_listing";s:1:"1";s:13:"compare_value";s:1:"=";s:5:"terms";a:12:{i:0;s:6:"590388";i:1;s:6:"590524";i:2;s:6:"590512";i:3;s:6:"590499";i:4;s:6:"590435";i:5;s:6:"590421";i:6;s:6:"590476";i:7;s:6:"590271";i:8;s:6:"590497";i:9;s:5:"16115";i:10;s:6:"590124";i:11;s:6:"590562";}}s:10:"vin_number";a:6:{s:8:"singular";s:10:"VIN Number";s:6:"plural";s:11:"VIN Numbers";s:10:"filterable";i:0;s:14:"use_on_listing";s:1:"1";s:13:"compare_value";s:1:"=";s:5:"terms";a:12:{i:0;s:17:"WP0CB2A92CS376450";i:1;s:17:"WP0AB2A74AL092462";i:2;s:17:"WP1AD29P09LA73659";i:3;s:17:"WP0AB2A74AL079264";i:4;s:17:"WP0CB2A92CS754706";i:5;s:17:"WP0CA2A96AS740274";i:6;s:17:"WP0AB2A74AL060306";i:7;s:17:"WP0AB2A74AL060306";i:8;s:17:"WP1AD29P09LA65818";i:9;s:17:"WP0AB2E81EK190171";i:10;s:17:"WP0CB2A92CS377324";i:11;s:17:"WP0CT2A92CS326491";}}s:7:"options";a:1:{s:5:"terms";a:40:{i:0;s:23:"Adaptive Cruise Control";i:1;s:7:"Airbags";i:2;s:16:"Air Conditioning";i:3;s:12:"Alarm System";i:4;s:21:"Anti-theft Protection";i:5;s:15:"Audio Interface";i:6;s:25:"Automatic Climate Control";i:7;s:20:"Automatic Headlights";i:8;s:15:"Auto Start/Stop";i:9;s:19:"Bi-Xenon Headlights";i:10;s:19:"Bluetooth® Handset";i:11;s:21:"BOSE® Surround Sound";i:12;s:26:"Burmester® Surround Sound";i:13;s:18:"CD/DVD Autochanger";i:14;s:9:"CDR Audio";i:15;s:14:"Cruise Control";i:16;s:21:"Direct Fuel Injection";i:17;s:22:"Electric Parking Brake";i:18;s:10:"Floor Mats";i:19;s:18:"Garage Door Opener";i:20;s:15:"Leather Package";i:21;s:25:"Locking Rear Differential";i:22;s:20:"Luggage Compartments";i:23;s:19:"Manual Transmission";i:24;s:17:"Navigation Module";i:25;s:15:"Online Services";i:26;s:10:"ParkAssist";i:27;s:21:"Porsche Communication";i:28;s:14:"Power Steering";i:29;s:16:"Reversing Camera";i:30;s:20:"Roll-over Protection";i:31;s:12:"Seat Heating";i:32;s:16:"Seat Ventilation";i:33;s:18:"Sound Package Plus";i:34;s:20:"Sport Chrono Package";i:35;s:22:"Steering Wheel Heating";i:36;s:24:"Tire Pressure Monitoring";i:37;s:25:"Universal Audio Interface";i:38;s:20:"Voice Control System";i:39;s:14:"Wind Deflector";}}}');

	$update = update_option("listing_categories", $demo_content);

	if($update){
		update_option("show_listing_categories", "hide");
		_e("The listing categories have been imported.", "listings");
	} else {
		_e("There was an error importing the listing categories, please try again later.", "listings");
	}

	die;
}

add_action("wp_ajax_import_listing_categories", "import_listing_categories");
add_action("wp_ajax_noprive_import_listing_categories", "import_listing_categories");


function hide_import_listing_categories(){
	update_option("show_listing_categories", "hide");

	die;
}

add_action("wp_ajax_hide_import_listing_categories", "hide_import_listing_categories");
add_action("wp_ajax_noprive_hide_import_listing_categories", "hide_import_listing_categories");

// gget_child_categories
function get_child_categories(){
	//echo $_POST['name'] . "<br>" . $_POST['value'];

	$return = array();

	$category        = get_single_listing_category($_POST['name']);
	$load_options    = ($category['dependancies'][$_POST['key']]);
	$second_category = get_single_listing_category($_POST['name']);

	if(isset($second_category['dependancies'][$_POST['key']]) && !empty($second_category['dependancies'][$_POST['key']])){
		// foreach option
		foreach($second_category['dependancies'][$_POST['key']] as $key){
			$return[] = $category['terms'][$key];
		}
	}

	echo json_encode($return);

	die;
}

add_action("wp_ajax_get_child_categories", "get_child_categories");
add_action("wp_ajax_nopriv_get_child_categories", "get_child_categories");
?>